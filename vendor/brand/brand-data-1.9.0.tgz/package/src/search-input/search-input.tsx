import { useId, type InputHTMLAttributes } from "react";
import { Input } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { SearchIcon } from "@brand/icons";

export interface SearchInputProps extends Omit<
  InputHTMLAttributes<HTMLInputElement>,
  "onChange" | "value"
> {
  value: string;
  onValueChange: (value: string) => void;
  /** Visually-hidden accessible label. Defaults to "Search". */
  label?: string;
  containerClassName?: string;
}

/** Search field with a leading icon and a clear button. Controlled. */
export function SearchInput({
  value,
  onValueChange,
  label = "Search",
  placeholder = "Search…",
  className,
  containerClassName,
  ...props
}: SearchInputProps) {
  const id = useId();
  return (
    <div className={cn("relative w-full max-w-xs", containerClassName)}>
      <label htmlFor={id} className="sr-only">
        {label}
      </label>
      <SearchIcon
        size={16}
        className="pointer-events-none absolute start-2.5 top-1/2 -translate-y-1/2 text-muted-foreground"
      />
      <Input
        id={id}
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        placeholder={placeholder}
        className={cn("ps-8", value && "pe-8", className)}
        {...props}
      />
      {value ? (
        <button
          type="button"
          onClick={() => onValueChange("")}
          aria-label="Clear search"
          className="absolute end-2 top-1/2 -translate-y-1/2 rounded-sm p-0.5 text-muted-foreground transition-colors duration-fast ease-standard hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring animate-in fade-in zoom-in-95 duration-fast ease-entrance"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>
      ) : null}
    </div>
  );
}
