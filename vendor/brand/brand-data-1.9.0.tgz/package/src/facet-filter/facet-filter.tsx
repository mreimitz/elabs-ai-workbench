import {
  Badge,
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@brand/ui";

export interface FacetOption {
  label: string;
  value: string;
}

export interface FacetFilterProps {
  title: string;
  options: FacetOption[];
  /** Currently selected values (controlled). */
  selected: string[];
  onSelectedChange: (values: string[]) => void;
}

/** Multi-select faceted filter rendered as a dropdown of toggles. */
export function FacetFilter({ title, options, selected, onSelectedChange }: FacetFilterProps) {
  const selectedSet = new Set(selected);
  const toggle = (value: string) => {
    const next = new Set(selectedSet);
    if (next.has(value)) next.delete(value);
    else next.add(value);
    onSelectedChange([...next]);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="border-dashed">
          {title}
          {selected.length > 0 ? (
            <Badge
              variant="secondary"
              className="ms-1 rounded px-1.5 animate-in fade-in zoom-in-95 duration-fast ease-entrance"
            >
              {selected.length}
            </Badge>
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="min-w-[12rem]">
        <DropdownMenuLabel>{title}</DropdownMenuLabel>
        {options.map((opt) => {
          const checked = selectedSet.has(opt.value);
          return (
            <DropdownMenuItem
              key={opt.value}
              onSelect={(e) => {
                e.preventDefault();
                toggle(opt.value);
              }}
            >
              <span
                aria-hidden="true"
                className={
                  "flex size-4 items-center justify-center rounded border transition-colors duration-fast ease-standard " +
                  (checked ? "border-primary bg-primary text-primary-foreground" : "border-input")
                }
              >
                {checked ? "✓" : ""}
              </span>
              {opt.label}
            </DropdownMenuItem>
          );
        })}
        {selected.length > 0 ? (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => onSelectedChange([])}>Clear filters</DropdownMenuItem>
          </>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
