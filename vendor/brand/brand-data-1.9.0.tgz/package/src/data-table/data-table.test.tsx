import { createRef } from "react";
import { describe, expect, it, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import type {
  ColumnDef,
  SortingState,
  ColumnFiltersState,
  VisibilityState,
} from "@tanstack/react-table";
import { DataTable } from "./data-table";
import type { DataTableServerArgs } from "./data-table";

// ─── Shared fixtures ─────────────────────────────────────────────────────────

interface Row {
  name: string;
  value: number;
}

const columns: ColumnDef<Row>[] = [
  { accessorKey: "name", header: "Name", enableSorting: true },
  { accessorKey: "value", header: "Value", enableSorting: true },
];

const data: Row[] = [
  { name: "Alpha", value: 3 },
  { name: "Beta", value: 1 },
  { name: "Gamma", value: 2 },
];

// ─── Original smoke tests (must remain green) ─────────────────────────────────

describe("DataTable — original smoke tests", () => {
  it("renders rows", () => {
    render(
      <DataTable
        columns={columns}
        data={[
          { name: "Alpha", value: 1 },
          { name: "Beta", value: 2 },
        ]}
      />,
    );
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.getByText("Beta")).toBeInTheDocument();
  });

  it("shows empty message when no data", () => {
    render(<DataTable columns={columns} data={[]} emptyMessage="Nothing here" />);
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
  });
});

// ─── B: Controlled slices ─────────────────────────────────────────────────────

describe("DataTable — controlled sorting", () => {
  it("reflects controlled sorting prop in state", () => {
    const sorting: SortingState = [{ id: "name", desc: false }];
    render(<DataTable columns={columns} data={data} sorting={sorting} onSortingChange={vi.fn()} />);
    // With ascending sort, Alpha < Beta < Gamma — first row should be Alpha
    const cells = screen.getAllByRole("cell");
    // First data cell = "Alpha"
    expect(cells[0]).toHaveTextContent("Alpha");
  });

  it("calls onSortingChange when user clicks a sortable header", () => {
    const onSortingChange = vi.fn();
    render(
      <DataTable columns={columns} data={data} sorting={[]} onSortingChange={onSortingChange} />,
    );
    // Click the "Name" sort button
    fireEvent.click(screen.getByText("Name"));
    expect(onSortingChange).toHaveBeenCalled();
  });
});

describe("DataTable — controlled columnVisibility", () => {
  it("hides a column when columnVisibility says false", () => {
    const columnVisibility: VisibilityState = { value: false };
    render(
      <DataTable
        columns={columns}
        data={data}
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={vi.fn()}
      />,
    );
    // "Value" header should not appear
    expect(screen.queryByText("Value")).toBeNull();
    // "Name" header should still appear
    expect(screen.getByText("Name")).toBeInTheDocument();
  });

  it("calls onColumnVisibilityChange when ColumnPicker toggles a column", () => {
    // We verify that the callback prop is wired by confirming it's referenced
    // (a full ColumnPicker integration test is in the stories). Here we just
    // confirm the prop type is accepted and renders without error.
    const onColumnVisibilityChange = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        columnVisibility={{}}
        onColumnVisibilityChange={onColumnVisibilityChange}
      />,
    );
    expect(screen.getByText("Name")).toBeInTheDocument();
  });

  it("empty-state cell spans only VISIBLE columns when a column is hidden", () => {
    // colSpan derives from getVisibleLeafColumns() so spacer/empty/skeleton cells
    // match the cell count of real data rows (getVisibleCells()) — not getAllColumns().
    render(
      <DataTable
        columns={columns}
        data={[]}
        columnVisibility={{ value: false }}
        onColumnVisibilityChange={vi.fn()}
        emptyMessage="None"
      />,
    );
    const emptyCell = screen.getByText("None").closest("td");
    // Only "name" remains visible → colSpan must be 1, not 2.
    expect(emptyCell).toHaveAttribute("colspan", "1");
  });
});

describe("DataTable — controlled columnFilters", () => {
  it("reflects controlled columnFilters in the rendered rows (local filtering)", () => {
    // manualFiltering is NOT set → local filtering is active
    const columnFilters: ColumnFiltersState = [{ id: "name", value: "Alpha" }];
    render(
      <DataTable
        columns={columns}
        data={data}
        columnFilters={columnFilters}
        onColumnFiltersChange={vi.fn()}
        // manualFiltering omitted → false (local)
      />,
    );
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.queryByText("Beta")).toBeNull();
    expect(screen.queryByText("Gamma")).toBeNull();
  });

  it("controlled-but-not-manual columnFilters STILL filters locally", () => {
    // Explicit regression: controlled ≠ manual; local getFilteredRowModel must run.
    // Filter on the "name" string column (default includesString filter works on strings).
    const columnFilters: ColumnFiltersState = [{ id: "name", value: "Beta" }];
    render(
      <DataTable
        columns={columns}
        data={data}
        columnFilters={columnFilters}
        onColumnFiltersChange={vi.fn()}
        manualFiltering={false} // explicit no-manual
      />,
    );
    // Only Beta should be visible — client filtering ran despite controlled prop
    expect(screen.getByText("Beta")).toBeInTheDocument();
    expect(screen.queryByText("Alpha")).toBeNull();
    expect(screen.queryByText("Gamma")).toBeNull();
  });
});

// ─── B: Server-side (manual) mode ────────────────────────────────────────────

describe("DataTable — manual/server-side mode", () => {
  it("calls onServerChange when manualSorting is true and sort changes", () => {
    const onServerChange = vi.fn<(args: DataTableServerArgs) => void>();
    render(
      <DataTable
        columns={columns}
        data={data}
        sorting={[]}
        onSortingChange={vi.fn()}
        manualSorting
        onServerChange={onServerChange}
      />,
    );
    fireEvent.click(screen.getByText("Name"));
    expect(onServerChange).toHaveBeenCalled();
    const args = onServerChange.mock.calls[0]![0];
    expect(args).toHaveProperty("sorting");
    expect(args).toHaveProperty("pagination");
    expect(args).toHaveProperty("columnFilters");
    expect(args).toHaveProperty("globalFilter");
    // Payload must carry the NEW slice value (post-update), not just the key —
    // a clicked "Name" header toggles to ascending. This locks fireServerChange
    // reading the post-update ref rather than a stale closure.
    expect(args.sorting).toEqual([{ id: "name", desc: false }]);
  });

  it("does NOT locally re-sort rows when manualSorting is true", () => {
    // With manualSorting the component delegates sorting to the server;
    // data prop order is preserved in the DOM.
    const onServerChange = vi.fn();
    const sortedData = [
      { name: "Gamma", value: 2 },
      { name: "Alpha", value: 3 },
      { name: "Beta", value: 1 },
    ];
    render(
      <DataTable
        columns={columns}
        data={sortedData}
        sorting={[{ id: "name", desc: false }]}
        onSortingChange={vi.fn()}
        manualSorting
        onServerChange={onServerChange}
      />,
    );
    // Row order should match the data prop (server-controlled), not alphabetical
    const cells = screen.getAllByRole("cell");
    expect(cells[0]).toHaveTextContent("Gamma");
  });

  it("does NOT locally re-filter when manualFiltering is true", () => {
    const onServerChange = vi.fn();
    // All 3 rows supplied — manual means server already filtered; table shows all
    render(
      <DataTable
        columns={columns}
        data={data}
        columnFilters={[{ id: "name", value: "Alpha" }]}
        onColumnFiltersChange={vi.fn()}
        manualFiltering
        onServerChange={onServerChange}
      />,
    );
    // Without client filtering all rows remain visible
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.getByText("Beta")).toBeInTheDocument();
    expect(screen.getByText("Gamma")).toBeInTheDocument();
  });

  it("calls onServerChange when manualFiltering and columnFilters change", () => {
    const onServerChange = vi.fn<(args: DataTableServerArgs) => void>();
    // We simulate an external filter change by re-rendering with new columnFilters
    const { rerender } = render(
      <DataTable
        columns={columns}
        data={data}
        columnFilters={[]}
        onColumnFiltersChange={vi.fn()}
        manualFiltering
        onServerChange={onServerChange}
      />,
    );
    // Re-render with updated filters — in real usage the controlled prop changes
    rerender(
      <DataTable
        columns={columns}
        data={data}
        columnFilters={[{ id: "name", value: "Beta" }]}
        onColumnFiltersChange={vi.fn()}
        manualFiltering
        onServerChange={onServerChange}
      />,
    );
    // onServerChange is fired inside the TanStack updater callbacks.
    // Because we changed the *controlled* prop externally (no TanStack updater fires),
    // onServerChange is NOT called — the app owns the fetch. Confirm no spurious call.
    // This is correct: the app changed the prop → it already knows to re-fetch.
    expect(onServerChange).not.toHaveBeenCalled();
  });

  it("calls onServerChange with the new pageIndex when manualPagination and Next is clicked", () => {
    // Server pagination is the headline use case of the server model; lock its callback.
    const onServerChange = vi.fn<(args: DataTableServerArgs) => void>();
    render(
      <DataTable
        columns={columns}
        data={data}
        enablePagination
        manualPagination
        rowCount={20}
        pagination={{ pageIndex: 0, pageSize: 5 }}
        onPaginationChange={vi.fn()}
        onServerChange={onServerChange}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: /Next/i }));
    expect(onServerChange).toHaveBeenCalled();
    const args = onServerChange.mock.calls.at(-1)![0];
    expect(args.pagination.pageIndex).toBe(1);
  });

  it("calls onServerChange with the new globalFilter when manualFiltering and the filter changes", () => {
    const onServerChange = vi.fn<(args: DataTableServerArgs) => void>();
    render(
      <DataTable
        columns={columns}
        data={data}
        manualFiltering
        globalFilter=""
        onGlobalFilterChange={vi.fn()}
        onServerChange={onServerChange}
        toolbar={(t) => (
          <button type="button" onClick={() => t.setGlobalFilter("beta")}>
            apply-filter
          </button>
        )}
      />,
    );
    fireEvent.click(screen.getByText("apply-filter"));
    expect(onServerChange).toHaveBeenCalled();
    const args = onServerChange.mock.calls.at(-1)![0];
    expect(args.globalFilter).toBe("beta");
  });
});

// ─── B: Saved-view serialize/rehydrate ───────────────────────────────────────

describe("DataTable — saved-view round-trip via initialView", () => {
  it("rehydrates uncontrolled slices from initialView and renders the same state", () => {
    // Capture a view snapshot
    const savedView = {
      sorting: [{ id: "name", desc: true }] as SortingState,
      columnVisibility: { value: false } as VisibilityState,
      columnFilters: [] as ColumnFiltersState,
      globalFilter: "",
    };

    // Serialize and parse (proving it's a plain serializable object)
    const serialized = JSON.stringify(savedView);
    const deserialized = JSON.parse(serialized);

    render(<DataTable columns={columns} data={data} initialView={deserialized} />);

    // desc:true sort on name → Gamma > Beta > Alpha (descending)
    const cells = screen.getAllByRole("cell");
    expect(cells[0]).toHaveTextContent("Gamma");

    // "value" column hidden
    expect(screen.queryByText("Value")).toBeNull();
  });
});

// ─── B: Loading state ─────────────────────────────────────────────────────────

describe("DataTable — loading state", () => {
  it("shows skeleton rows (not empty message) when loading and no data", () => {
    render(<DataTable columns={columns} data={[]} loading emptyMessage="No results." />);
    expect(screen.queryByText("No results.")).toBeNull();
    // Skeleton divs rendered (aria-hidden, so query by class presence via container)
    // Skeletons are <div aria-hidden="true" class="... animate-pulse ...">
    // We verify by checking the table still renders without empty state
    expect(screen.queryByRole("status")).toBeNull(); // spinner only with rows present
  });

  it("shows overlay spinner when loading with existing rows", () => {
    render(<DataTable columns={columns} data={data} loading />);
    // Spinner has role="status" via the aria-live="polite" attribute in the DOM
    // and the Spinner component itself has role="status"
    const status = screen.queryByRole("status");
    expect(status).toBeInTheDocument();
  });

  it("shows empty message when not loading and no rows", () => {
    render(<DataTable columns={columns} data={[]} loading={false} emptyMessage="Nothing here" />);
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
  });
});

// ─── D: forwardRef + prop-spread + aria-busy + loadingRows ───────────────────

describe("DataTable — forwardRef, prop-spread, aria-busy, loadingRows", () => {
  it("forwards a ref to the outermost wrapper <div>", () => {
    const ref = createRef<HTMLDivElement>();
    const { container } = render(<DataTable columns={columns} data={data} ref={ref} />);
    // The ref should point to the first div child of the container
    expect(ref.current).not.toBeNull();
    expect(ref.current).toBe(container.firstChild);
  });

  it("spreads an id onto the root element", () => {
    const { container } = render(<DataTable columns={columns} data={data} id="my-table" />);
    expect(container.firstChild).toHaveAttribute("id", "my-table");
  });

  it("spreads a data-* attribute onto the root element", () => {
    const { container } = render(<DataTable columns={columns} data={data} data-testid="dt-root" />);
    expect(container.firstChild).toHaveAttribute("data-testid", "dt-root");
  });

  it("merges a caller className onto the root element", () => {
    const { container } = render(
      <DataTable columns={columns} data={data} className="extra-class" />,
    );
    expect(container.firstChild).toHaveClass("extra-class");
    // Base class must also be present
    expect(container.firstChild).toHaveClass("space-y-3");
  });

  it("sets aria-busy on the inner scroll container while loading with existing rows", () => {
    const { container } = render(<DataTable columns={columns} data={data} loading />);
    // The inner div wrapping the <table> carries aria-busy (not the root wrapper)
    const busyEl = container.querySelector("[aria-busy='true']");
    expect(busyEl).toBeInTheDocument();
  });

  it("sets aria-busy on the inner scroll container while loading with no data (skeleton mode)", () => {
    const { container } = render(<DataTable columns={columns} data={[]} loading />);
    const busyEl = container.querySelector("[aria-busy='true']");
    expect(busyEl).toBeInTheDocument();
  });

  it("does NOT set aria-busy when not loading", () => {
    const { container } = render(<DataTable columns={columns} data={data} loading={false} />);
    expect(container.querySelector("[aria-busy='true']")).toBeNull();
  });

  it("renders exactly loadingRows skeleton rows when specified", () => {
    const { container } = render(<DataTable columns={columns} data={[]} loading loadingRows={3} />);
    // Each skeleton row is a <tr> in the tbody
    const tbodyRows = container.querySelectorAll("tbody tr");
    expect(tbodyRows.length).toBe(3);
  });

  it("renders pageSize skeleton rows by default (no loadingRows prop)", () => {
    // Default pageSize is 10
    const { container } = render(<DataTable columns={columns} data={[]} loading />);
    const tbodyRows = container.querySelectorAll("tbody tr");
    expect(tbodyRows.length).toBe(10);
  });

  it("skeleton cells are aria-hidden (decorative)", () => {
    const { container } = render(<DataTable columns={columns} data={[]} loading loadingRows={2} />);
    // Skeleton component always renders aria-hidden="true" on its root div
    const skeletonDivs = container.querySelectorAll("[aria-hidden='true']");
    // 2 rows × 2 columns = 4 skeleton divs (each Skeleton sets aria-hidden)
    expect(skeletonDivs.length).toBeGreaterThanOrEqual(4);
  });

  it("marks skeleton placeholder rows aria-hidden so AT skips them", () => {
    // The loading state is announced via aria-busy; the skeleton <tr>s are a pure
    // visual affordance and must not be read as empty data rows.
    const { container } = render(<DataTable columns={columns} data={[]} loading loadingRows={2} />);
    const hiddenRows = container.querySelectorAll('tbody tr[aria-hidden="true"]');
    expect(hiddenRows.length).toBe(2);
  });

  it("shows real rows after transitioning from loading to loaded", () => {
    const { rerender } = render(<DataTable columns={columns} data={[]} loading />);
    // Loading: no real data rows
    expect(screen.queryByText("Alpha")).toBeNull();
    // Loaded: real data arrives
    rerender(<DataTable columns={columns} data={data} loading={false} />);
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.getByText("Beta")).toBeInTheDocument();
  });
});

// ─── C: Row virtualization DOM proof ─────────────────────────────────────────

describe("DataTable — row virtualization", () => {
  it("renders far fewer than 10 000 DOM rows when enableRowVirtualization is true", () => {
    // jsdom has no layout engine, so the virtualizer measures nothing and
    // renders zero virtual items. The count will be 0 (spacers only) — but
    // that is STILL far fewer than 10 000, which proves windowing is active.
    // Real smoothness with actual scrolling is verified in Storybook
    // (Virtualized10k story) because jsdom cannot simulate scroll/layout.
    const bigData: Row[] = Array.from({ length: 10_000 }, (_, i) => ({
      name: `Row ${i}`,
      value: i,
    }));

    const { container } = render(
      <DataTable
        columns={columns}
        data={bigData}
        enableRowVirtualization
        estimateRowHeight={40}
        overscan={8}
        maxBodyHeight="32rem"
      />,
    );

    const tbodyRows = container.querySelectorAll("tbody tr");
    // Must be MUCH less than 10 000 — proves windowing, not full render.
    // In jsdom it will be 0 real rows + at most 2 spacers = ≤ 2.
    // We assert < 100 to be robust against any jsdom partial layout.
    expect(tbodyRows.length).toBeLessThan(100);
    // And definitely not all 10k
    expect(tbodyRows.length).not.toBe(10_000);
  });

  it("renders normally (non-virtualized) without enableRowVirtualization", () => {
    // Baseline: 3 rows → 3 tr elements in tbody
    const { container } = render(<DataTable columns={columns} data={data} />);
    const tbodyRows = container.querySelectorAll("tbody tr");
    expect(tbodyRows.length).toBe(3);
  });
});

// ─── C: Virtualized a11y + composability (issue-01 hardening) ─────────────────

describe("DataTable — virtualized a11y + composability", () => {
  const bigData: Row[] = Array.from({ length: 100 }, (_, i) => ({
    name: `Row ${i}`,
    value: i,
  }));

  it("sets aria-rowcount (data + header rows) on the virtualized table so AT sees the true size", () => {
    const { container } = render(
      <DataTable columns={columns} data={bigData} enableRowVirtualization />,
    );
    // 100 data rows + 1 header row
    expect(container.querySelector("table")).toHaveAttribute(
      "aria-rowcount",
      String(bigData.length + 1),
    );
  });

  it("does NOT set aria-rowcount on the non-virtualized table (the DOM already reflects every row)", () => {
    const { container } = render(<DataTable columns={columns} data={data} />);
    expect(container.querySelector("table")).not.toHaveAttribute("aria-rowcount");
  });

  it("sets aria-rowindex=1 on the virtualized header row", () => {
    const { container } = render(
      <DataTable columns={columns} data={bigData} enableRowVirtualization />,
    );
    expect(container.querySelector("thead tr")).toHaveAttribute("aria-rowindex", "1");
  });

  it("mounts only a small window of indexed data rows (≪ the full dataset)", () => {
    // jsdom has no layout engine, so the virtualizer mounts ~0 data rows; the point is
    // that the windowed count is far below the total while aria-rowcount reports the total.
    const { container } = render(
      <DataTable columns={columns} data={bigData} enableRowVirtualization />,
    );
    const indexedRows = container.querySelectorAll("tbody tr[aria-rowindex]");
    expect(indexedRows.length).toBeLessThan(bigData.length);
  });

  it("makes the virtualized scroll region keyboard-focusable with a visible focus ring", () => {
    const { container } = render(
      <DataTable columns={columns} data={bigData} enableRowVirtualization />,
    );
    const scroll = container.querySelector(".overflow-auto");
    expect(scroll).toHaveAttribute("tabindex", "0");
    expect(scroll?.className).toMatch(/focus-visible:ring-2/);
    // A focusable element must have an accessible name (WCAG 4.1.2).
    expect(scroll).toHaveAttribute("aria-label");
  });

  it("forwards ref + spreads id/data-* + merges className + sets aria-busy on the virtualized branch", () => {
    const ref = createRef<HTMLDivElement>();
    const { container } = render(
      <DataTable
        columns={columns}
        data={bigData}
        enableRowVirtualization
        loading
        ref={ref}
        id="virt-table"
        data-testid="virt-root"
        className="virt-extra"
      />,
    );
    expect(ref.current).toBe(container.firstChild);
    expect(container.firstChild).toHaveAttribute("id", "virt-table");
    expect(container.firstChild).toHaveAttribute("data-testid", "virt-root");
    expect(container.firstChild).toHaveClass("virt-extra");
    expect(container.querySelector("[aria-busy='true']")).toBeInTheDocument();
  });

  it("suppresses pagination controls when virtualization and pagination are both enabled (virtualization wins)", () => {
    render(
      <DataTable
        columns={columns}
        data={bigData}
        enableRowVirtualization
        enablePagination
        pageSize={5}
      />,
    );
    expect(screen.queryByRole("button", { name: /Next/i })).toBeNull();
    expect(screen.queryByRole("button", { name: /Previous/i })).toBeNull();
  });
});

// ─── Zebra striping (default) vs line dividers ────────────────────────────────

describe("DataTable — zebra striping (default) vs lines", () => {
  it("stripes alternate rows and draws no divider by default (zebra on)", () => {
    const { container } = render(<DataTable columns={columns} data={data} />);
    const rows = container.querySelectorAll("tbody tr");
    expect(rows.length).toBe(3);
    // 2nd row (index 1) is striped; 1st/3rd are not — the stripe is the cue.
    expect(rows[0]?.className).not.toContain("bg-foreground/5");
    expect(rows[1]?.className).toContain("bg-foreground/5");
    expect(rows[2]?.className).not.toContain("bg-foreground/5");
    // No row carries a divider (a border on a striped region would be redundant).
    rows.forEach((r) => expect(r.className).not.toContain("border-b"));
  });

  it("draws border-strong dividers and no stripes when zebra is disabled", () => {
    const { container } = render(<DataTable columns={columns} data={data} zebra={false} />);
    const rows = container.querySelectorAll("tbody tr");
    rows.forEach((r) => {
      expect(r.className).toContain("border-b");
      expect(r.className).toContain("border-border-strong");
      expect(r.className).not.toContain("bg-foreground/5");
    });
    // Last row drops its divider so it doesn't double with the container border.
    expect(rows[rows.length - 1]?.className).toContain("last:border-b-0");
  });

  it("#229 — row hover transition uses gated motion tokens (duration-fast / ease-standard), not the bare default", () => {
    const { container } = render(<DataTable columns={columns} data={data} />);
    const rows = container.querySelectorAll("tbody tr");
    rows.forEach((r) => {
      expect(r.className).toContain("transition-colors");
      expect(r.className).toContain("duration-fast");
      expect(r.className).toContain("ease-standard");
    });
  });
});

// ─── #228: onGlobalFilterChange resolves against the ref, not the closure ────

describe("DataTable — #228 global-filter functional updater resolves against the ref", () => {
  it("resolves a functional globalFilter updater against the latest ref value across two synchronous calls in one handler", () => {
    // Two functional updates fired synchronously in the SAME event handler —
    // before React re-renders, the render-closure `globalFilter` variable is
    // stale for the second call; only `globalFilterRef.current` is guaranteed
    // fresh. This is the regression the fix (resolveGlobalFilter) locks:
    // buggy code resolves both calls against the same stale "" and reports
    // "a" twice; the fix reports "a" then "aa".
    const onGlobalFilterChange = vi.fn<(value: string) => void>();
    render(
      <DataTable
        columns={columns}
        data={data}
        manualFiltering
        onGlobalFilterChange={onGlobalFilterChange}
        toolbar={(t) => (
          <button
            type="button"
            onClick={() => {
              t.setGlobalFilter((prev: string) => `${prev ?? ""}a`);
              t.setGlobalFilter((prev: string) => `${prev ?? ""}a`);
            }}
          >
            apply-filter
          </button>
        )}
      />,
    );
    fireEvent.click(screen.getByText("apply-filter"));
    expect(onGlobalFilterChange).toHaveBeenCalledTimes(2);
    expect(onGlobalFilterChange.mock.calls[0]?.[0]).toBe("a");
    // The second call must resolve against the just-updated ref ("a" + "a"),
    // not the stale render-closure value ("" + "a" = "a").
    expect(onGlobalFilterChange.mock.calls[1]?.[0]).toBe("aa");
  });
});

// ─── #227: manualPagination without rowCount/pageCount warns once (dev) ─────

describe("DataTable — #227 manualPagination without rowCount/pageCount dev warning", () => {
  it("warns once when manualPagination is true and neither rowCount nor pageCount is supplied", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const { rerender } = render(
        <DataTable columns={columns} data={data} enablePagination manualPagination />,
      );
      expect(warnSpy).toHaveBeenCalledTimes(1);
      expect(warnSpy.mock.calls[0]?.[0]).toMatch(/manualPagination.*rowCount.*pageCount/is);

      // Re-rendering (e.g. a parent re-render) must NOT warn again — "once" holds.
      rerender(<DataTable columns={columns} data={data} enablePagination manualPagination />);
      expect(warnSpy).toHaveBeenCalledTimes(1);
    } finally {
      warnSpy.mockRestore();
    }
  });

  it("does NOT warn when rowCount is supplied", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      render(
        <DataTable columns={columns} data={data} enablePagination manualPagination rowCount={20} />,
      );
      expect(warnSpy).not.toHaveBeenCalled();
    } finally {
      warnSpy.mockRestore();
    }
  });

  it("does NOT warn when pageCount is supplied", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      render(
        <DataTable columns={columns} data={data} enablePagination manualPagination pageCount={4} />,
      );
      expect(warnSpy).not.toHaveBeenCalled();
    } finally {
      warnSpy.mockRestore();
    }
  });

  it("does NOT warn when manualPagination is false", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      render(<DataTable columns={columns} data={data} enablePagination />);
      expect(warnSpy).not.toHaveBeenCalled();
    } finally {
      warnSpy.mockRestore();
    }
  });
});

// ─── #230: sort header uses Lucide icons + a directional accessible name ────

describe("DataTable — #230 sort header icon + accessible name", () => {
  it("gives the sort button an accessible name that changes with sort state", () => {
    const { rerender } = render(
      <DataTable columns={columns} data={data} sorting={[]} onSortingChange={vi.fn()} />,
    );
    expect(screen.getByRole("button", { name: "Sort by Name, not sorted" })).toBeInTheDocument();

    rerender(
      <DataTable
        columns={columns}
        data={data}
        sorting={[{ id: "name", desc: false }]}
        onSortingChange={vi.fn()}
      />,
    );
    expect(screen.getByRole("button", { name: "Sort by Name, ascending" })).toBeInTheDocument();

    rerender(
      <DataTable
        columns={columns}
        data={data}
        sorting={[{ id: "name", desc: true }]}
        onSortingChange={vi.fn()}
      />,
    );
    expect(screen.getByRole("button", { name: "Sort by Name, descending" })).toBeInTheDocument();
  });

  it("falls back to the column id for the accessible name when the header is a non-text ReactNode", () => {
    const iconHeaderColumns: ColumnDef<Row>[] = [
      {
        accessorKey: "name",
        id: "name",
        header: () => <span aria-hidden="true">🔤</span>,
        enableSorting: true,
      },
      { accessorKey: "value", header: "Value", enableSorting: true },
    ];
    render(<DataTable columns={iconHeaderColumns} data={data} />);
    // Non-text header → falls back to the column id ("name") so the button
    // still has a real accessible name (WCAG 4.1.2), not an empty one.
    expect(screen.getByRole("button", { name: "Sort by name, not sorted" })).toBeInTheDocument();
  });

  it("renders a Lucide sort-direction icon (svg), not the raw ▲/▼/↕ glyphs", () => {
    render(<DataTable columns={columns} data={data} sorting={[]} onSortingChange={vi.fn()} />);
    const sortButton = screen.getByRole("button", { name: "Sort by Name, not sorted" });
    expect(sortButton.querySelector("svg")).toBeInTheDocument();
    expect(sortButton.textContent).not.toMatch(/[▲▼↕]/);
  });
});
