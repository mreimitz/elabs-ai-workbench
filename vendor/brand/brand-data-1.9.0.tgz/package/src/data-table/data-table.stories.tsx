import { useEffect, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, waitFor } from "storybook/test";
import { Badge, Button } from "@brand/ui";
import type {
  ColumnDef,
  SortingState,
  ColumnFiltersState,
  VisibilityState,
} from "@tanstack/react-table";
import { DataTable } from "./data-table";
import type { DataTableServerArgs, DataTableViewState } from "./data-table";
import { FilterBar } from "../filter-bar";
import { SearchInput } from "../search-input";
import { FacetFilter } from "../facet-filter";
import { ColumnPicker } from "../column-picker";

// ─── Shared data fixtures ─────────────────────────────────────────────────────

interface Deployment {
  service: string;
  env: "prod" | "staging" | "dev";
  status: "healthy" | "degraded" | "down";
  latencyMs: number;
}

const rows: Deployment[] = [
  { service: "api-gateway", env: "prod", status: "healthy", latencyMs: 82 },
  { service: "billing", env: "prod", status: "degraded", latencyMs: 240 },
  { service: "search", env: "staging", status: "healthy", latencyMs: 120 },
  { service: "notifications", env: "dev", status: "down", latencyMs: 0 },
  { service: "auth", env: "prod", status: "healthy", latencyMs: 64 },
];

const statusVariant = { healthy: "success", degraded: "warning", down: "destructive" } as const;

const columns: ColumnDef<Deployment>[] = [
  { accessorKey: "service", header: "Service" },
  { accessorKey: "env", header: "Environment" },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const s = row.original.status;
      return <Badge variant={statusVariant[s]}>{s}</Badge>;
    },
  },
  { accessorKey: "latencyMs", header: "Latency (ms)" },
];

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta = {
  title: "Data/DataTable",
  component: DataTable,
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "The full data grid (TanStack Table): sorting, filtering, pagination, virtualization, row " +
          "selection and column management. For a simple static table with no interaction, the lighter " +
          "Table primitive (see Data/Table, @brand/ui) is enough.",
      },
    },
  },
  tags: ["autodocs"],
} satisfies Meta<typeof DataTable<Deployment, unknown>>;
export default meta;
type Story = StoryObj<typeof meta>;

// ─── Default ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  render: () => <DataTable columns={columns} data={rows} />,
};

// ─── Lines (zebra opt-out) ──────────────────────────────────────────────────

/**
 * `zebra={false}` opts out of the default gentle zebra striping in favour of the
 * classic line model — a `border-border-strong` divider between rows.
 */
export const Lines: Story = {
  render: () => <DataTable columns={columns} data={rows} zebra={false} />,
};

// ─── Sorted ───────────────────────────────────────────────────────────────────

export const Sorted: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [sorting, setSorting] = useState<SortingState>([{ id: "latencyMs", desc: true }]);
    return (
      <DataTable
        columns={columns}
        data={rows}
        sorting={sorting}
        onSortingChange={(updater) =>
          setSorting(typeof updater === "function" ? updater(sorting) : updater)
        }
      />
    );
  },
};

// ─── Filtered (with toolbar SearchInput + FacetFilter) ────────────────────────

export const Filtered: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [search, setSearch] = useState("");
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [envs, setEnvs] = useState<string[]>([]);
    const filtered = rows.filter((r) => (envs.length ? envs.includes(r.env) : true));
    return (
      <DataTable
        columns={columns}
        data={filtered}
        globalFilter={search}
        onGlobalFilterChange={setSearch}
        toolbar={(table) => (
          <FilterBar actions={<ColumnPicker table={table} />}>
            <SearchInput value={search} onValueChange={setSearch} placeholder="Filter services…" />
            <FacetFilter
              title="Environment"
              selected={envs}
              onSelectedChange={setEnvs}
              options={[
                { label: "Production", value: "prod" },
                { label: "Staging", value: "staging" },
                { label: "Dev", value: "dev" },
              ]}
            />
          </FilterBar>
        )}
      />
    );
  },
};

// ─── WithToolbar (retained from original — the interaction-tested story) ──────

export const WithToolbar: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [search, setSearch] = useState("");
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [envs, setEnvs] = useState<string[]>([]);
    const filtered = rows.filter((r) => (envs.length ? envs.includes(r.env) : true));
    return (
      <DataTable
        columns={columns}
        data={filtered}
        enablePagination
        pageSize={5}
        globalFilter={search}
        onGlobalFilterChange={setSearch}
        toolbar={(table) => (
          <FilterBar actions={<ColumnPicker table={table} />}>
            <SearchInput value={search} onValueChange={setSearch} placeholder="Filter services…" />
            <FacetFilter
              title="Environment"
              selected={envs}
              onSelectedChange={setEnvs}
              options={[
                { label: "Production", value: "prod" },
                { label: "Staging", value: "staging" },
                { label: "Dev", value: "dev" },
              ]}
            />
          </FilterBar>
        )}
      />
    );
  },
  // Typing in the toolbar SearchInput drives the table's global filter: only the
  // matching row should survive. Proves the render-prop toolbar and table share
  // one filter state.
  play: async ({ canvas, userEvent }) => {
    await expect(canvas.getByText("api-gateway")).toBeVisible();
    await userEvent.type(canvas.getByPlaceholderText(/Filter services/), "billing");
    await waitFor(() => expect(canvas.queryByText("api-gateway")).toBeNull());
    await expect(canvas.getByText("billing")).toBeVisible();
  },
};

// ─── Paginated ────────────────────────────────────────────────────────────────

export const Paginated: Story = {
  render: () => (
    <DataTable
      columns={columns}
      data={[...rows, ...rows, ...rows]} // 15 rows
      enablePagination
      pageSize={5}
    />
  ),
};

// ─── Loading ──────────────────────────────────────────────────────────────────

/** Shows a spinner overlay when rows are present + loading. */
export const Loading: Story = {
  render: () => <DataTable columns={columns} data={rows} loading />,
};

/** Shows skeleton placeholder rows when data is empty + loading (initial load). */
export const LoadingEmpty: Story = {
  render: () => <DataTable columns={columns} data={[]} loading />,
};

/**
 * Toggle between loading (skeleton) and loaded (real data) to verify there is
 * no layout jump when real rows arrive.
 */
export const LoadingToLoaded: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [loading, setLoading] = useState(true);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [tableData, setTableData] = useState<Deployment[]>([]);

    return (
      <div className="space-y-3">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              setLoading(true);
              setTableData([]);
              setTimeout(() => {
                setTableData(rows);
                setLoading(false);
              }, 800);
            }}
            className="rounded border px-3 py-1 text-body"
          >
            {loading ? "Loading…" : "Reload (simulate fetch)"}
          </button>
        </div>
        <DataTable
          columns={columns}
          data={tableData}
          loading={loading}
          loadingRows={5}
          id="loading-to-loaded-table"
          data-testid="loading-demo"
        />
      </div>
    );
  },
};

// ─── Empty ────────────────────────────────────────────────────────────────────

export const Empty: Story = {
  render: () => <DataTable columns={columns} data={[]} emptyMessage="No deployments found." />,
};

// ─── Virtualized10k ───────────────────────────────────────────────────────────

/**
 * 10 000 generated rows with row virtualization enabled.
 * Only a small window of rows is rendered in the DOM at any time.
 * Scroll the container to verify smooth windowing.
 * (Real perf/smoothness cannot be measured in jsdom — use this story in a browser.)
 */
export const Virtualized10k: Story = {
  render: () => {
    const bigData = Array.from({ length: 10_000 }, (_, i) => ({
      service: `service-${i}`,
      env: (["prod", "staging", "dev"] as const)[i % 3],
      status: (["healthy", "degraded", "down"] as const)[i % 3],
      latencyMs: (i * 7) % 500,
    }));

    return (
      <DataTable
        columns={columns}
        data={bigData}
        enableRowVirtualization
        estimateRowHeight={40}
        overscan={8}
        maxBodyHeight="32rem"
      />
    );
  },
};

// ─── ServerSide ───────────────────────────────────────────────────────────────

/**
 * Documented server-side example.
 *
 * Demonstrates the manual* + onServerChange pattern:
 * - `manualPagination`, `manualSorting`, `manualFiltering` are all true.
 * - The component never fetches. `onServerChange` fires when any slice changes.
 * - The story simulates a remote fetch with a setTimeout and updates `data`.
 * - `pageCount` / `rowCount` are passed so TanStack can compute page boundaries.
 *
 * In a real app, replace the setTimeout with your data-fetching hook (e.g. SWR,
 * React Query, or a server action) and remove the simulated data generation.
 */
export const ServerSide: Story = {
  render: () => {
    // Total "server-side" dataset — in reality this lives on the server.
    const TOTAL_ROWS = 47;
    const PAGE_SIZE = 5;

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [serverArgs, setServerArgs] = useState<DataTableServerArgs>({
      pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
      sorting: [],
      columnFilters: [],
      globalFilter: "",
    });

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [loading, setLoading] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [pageData, setPageData] = useState<Deployment[]>([]);

    // Controlled slices — the app owns them; DataTable drives them via callbacks.
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [sorting, setSorting] = useState<SortingState>([]);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: PAGE_SIZE });

    // Simulate a server fetch whenever serverArgs change.
    // Replace this with a real data-fetching call (SWR, React Query, etc.).
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useEffect(() => {
      setLoading(true);
      const timer = setTimeout(() => {
        // Generate a page of fake data based on pagination
        const start = serverArgs.pagination.pageIndex * serverArgs.pagination.pageSize;
        const slice = Array.from(
          { length: Math.min(serverArgs.pagination.pageSize, TOTAL_ROWS - start) },
          (_, i) => {
            const idx = start + i;
            return {
              service: `service-${idx}`,
              env: (["prod", "staging", "dev"] as const)[idx % 3],
              status: (["healthy", "degraded", "down"] as const)[idx % 3],
              latencyMs: (idx * 13) % 500,
            };
          },
        );
        setPageData(slice);
        setLoading(false);
      }, 300); // simulated 300 ms network latency
      return () => clearTimeout(timer);
    }, [serverArgs]);

    return (
      <DataTable
        columns={columns}
        data={pageData}
        loading={loading}
        enablePagination
        pageSize={PAGE_SIZE}
        // Server-side model flags
        manualPagination
        manualSorting
        manualFiltering
        // Let TanStack know total rows so it can compute page count
        rowCount={TOTAL_ROWS}
        // Controlled slices (the app holds state; DataTable reports changes)
        sorting={sorting}
        onSortingChange={(u) => setSorting(typeof u === "function" ? u(sorting) : u)}
        columnFilters={columnFilters}
        onColumnFiltersChange={(u) =>
          setColumnFilters(typeof u === "function" ? u(columnFilters) : u)
        }
        pagination={pagination}
        onPaginationChange={(u) => setPagination(typeof u === "function" ? u(pagination) : u)}
        // onServerChange — trigger the re-fetch
        onServerChange={setServerArgs}
      />
    );
  },
};

// ─── SavedViewRoundTrip ───────────────────────────────────────────────────────

/**
 * Demonstrates saved-view serialize → parse → rehydrate.
 *
 * The user configures sorting + column visibility, clicks "Save view", and the
 * state is JSON-serialized. On remount (simulated by toggling the key), the
 * same state is rehydrated via `initialView` and the table looks identical.
 */
export const SavedViewRoundTrip: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [savedView, setSavedView] = useState<Partial<DataTableViewState> | null>(null);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [mountKey, setMountKey] = useState(0);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [sorting, setSorting] = useState<SortingState>([]);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);

    function handleSave() {
      const view: Partial<DataTableViewState> = {
        sorting,
        columnVisibility,
        columnFilters,
        globalFilter: "",
      };
      // Serialize → parse (proves it survives JSON round-trip)
      const serialized = JSON.stringify(view);
      const parsed = JSON.parse(serialized) as Partial<DataTableViewState>;
      setSavedView(parsed);
      // Remount with a new key to simulate re-entering the page
      setMountKey((k) => k + 1);
    }

    return (
      <div className="space-y-4">
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setSorting([{ id: "latencyMs", desc: true }])}
          >
            Sort by Latency ↓
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setColumnVisibility({ latencyMs: false })}
          >
            Hide Latency column
          </Button>
          <Button type="button" size="sm" onClick={handleSave}>
            Save view &amp; remount
          </Button>
        </div>

        {savedView && (
          <p className="text-meta text-muted-foreground">
            Saved: <code>{JSON.stringify(savedView)}</code>
          </p>
        )}

        {/* key forces a remount so initialView takes effect as one-shot rehydration */}
        <DataTable
          key={mountKey}
          columns={columns}
          data={rows}
          initialView={savedView ?? undefined}
          sorting={savedView ? undefined : sorting}
          onSortingChange={(u) => setSorting(typeof u === "function" ? u(sorting) : u)}
          columnVisibility={savedView ? undefined : columnVisibility}
          onColumnVisibilityChange={(u) =>
            setColumnVisibility(typeof u === "function" ? u(columnVisibility) : u)
          }
          columnFilters={savedView ? undefined : columnFilters}
          onColumnFiltersChange={(u) =>
            setColumnFilters(typeof u === "function" ? u(columnFilters) : u)
          }
        />
      </div>
    );
  },
};
