import { forwardRef, useEffect, useRef, useState, type ReactNode } from "react";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type ColumnFiltersState,
  type OnChangeFn,
  type PaginationState,
  type SortingState,
  type Table as TanstackTable,
  type VisibilityState,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { ArrowDown, ArrowUp, ArrowUpDown } from "lucide-react";
import { Button, Skeleton, Spinner } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";

// ─── Public types ─────────────────────────────────────────────────────────────

/** Snapshot of table slice state — used for saved-view serialise/rehydrate. */
export interface DataTableViewState {
  sorting: SortingState;
  columnVisibility: VisibilityState;
  columnFilters: ColumnFiltersState;
  globalFilter?: string;
  pagination?: PaginationState;
}

/**
 * Argument object fired by `onServerChange` whenever a manual slice changes.
 * The consuming app should re-fetch with these params and update `data`.
 */
export interface DataTableServerArgs {
  pagination: PaginationState;
  sorting: SortingState;
  columnFilters: ColumnFiltersState;
  globalFilter: string;
}

// ─── Props ────────────────────────────────────────────────────────────────────

export interface DataTableProps<TData, TValue> extends Omit<
  React.HTMLAttributes<HTMLDivElement>,
  "children"
> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  /** Render a toolbar above the table; receives the table instance. */
  toolbar?: (table: TanstackTable<TData>) => ReactNode;
  /** Enable client-side pagination. */
  enablePagination?: boolean;
  pageSize?: number;

  /**
   * Controlled global filter value. When provided, the table reflects this
   * value and the component manages no internal filter state. Keep the source
   * of truth in the app and pass it down — never mutate the filter during
   * render (e.g. `table.setGlobalFilter()` in `toolbar`), which loops.
   */
  globalFilter?: string;
  /** Fires when the table requests a global-filter change (e.g. from typeahead). */
  onGlobalFilterChange?: (value: string) => void;

  // ── Controlled slices for saved views ─────────────────────────────────────
  /** Controlled sorting state. When provided the component is sorted-controlled. */
  sorting?: SortingState;
  onSortingChange?: OnChangeFn<SortingState>;

  /** Controlled column-visibility state. */
  columnVisibility?: VisibilityState;
  onColumnVisibilityChange?: OnChangeFn<VisibilityState>;

  /** Controlled column-filters state. */
  columnFilters?: ColumnFiltersState;
  onColumnFiltersChange?: OnChangeFn<ColumnFiltersState>;

  /** Controlled pagination state. */
  pagination?: PaginationState;
  onPaginationChange?: OnChangeFn<PaginationState>;

  /**
   * One-shot rehydrate for uncontrolled slices only (ignored for any slice
   * whose corresponding controlled prop is set). Maps to `useReactTable`'s
   * `initialState`.
   */
  initialView?: Partial<DataTableViewState>;

  // ── Server-side data model ──────────────────────────────────────────────────
  /**
   * When true, sorting is handled by the server. Pass `sorting` (controlled)
   * and handle `onServerChange` to re-fetch with the new sort params.
   * NOTE: controlled ≠ manual — a controlled `sorting` with `manualSorting:false`
   * still sorts locally.
   */
  manualSorting?: boolean;
  /**
   * When true, filtering is handled by the server.
   * NOTE: a controlled `columnFilters` with `manualFiltering:false` still
   * filters locally.
   */
  manualFiltering?: boolean;
  /** When true, pagination is handled by the server. */
  manualPagination?: boolean;

  /**
   * Total row count — used by the server model so TanStack can derive
   * page count. Required when `manualPagination` is true and `pageCount` is
   * not provided.
   */
  rowCount?: number;
  /**
   * Total page count — alternative to `rowCount` for server pagination. When
   * both are provided, `pageCount` wins.
   */
  pageCount?: number;

  /**
   * Fired after any manual-slice change with the current {pagination, sorting,
   * columnFilters, globalFilter}. The component never fetches; the app must
   * re-fetch and update `data`.
   */
  onServerChange?: (args: DataTableServerArgs) => void;

  /** When true: overlay spinner; on empty+loading show skeleton rows instead of empty message. */
  loading?: boolean;

  // ── Virtualization ─────────────────────────────────────────────────────────
  /**
   * Opt-in to row virtualization (for very large lists). Mutually exclusive
   * with enablePagination in practice — if both are set, virtualization wins
   * and pagination is silently ignored.
   */
  enableRowVirtualization?: boolean;
  /** Estimated row height in px (used by the virtualizer). Default: 40. */
  estimateRowHeight?: number;
  /** Virtualizer overscan (rows rendered above/below the visible window). Default: 8. */
  overscan?: number;
  /** CSS max-height of the scroll container in virtualized mode. Default: "32rem". */
  maxBodyHeight?: string;

  /**
   * Number of skeleton placeholder rows to render while loading.
   * Defaults to `pageSize` (non-virtualized) or `min(10, pageSize)` (virtualized).
   */
  loadingRows?: number;

  /**
   * Gentle alternating row stripes ("zebra") as the row-separation cue, instead
   * of a hairline divider between every row. Default `true` — the stripe is the
   * single separation gesture, so rows carry no divider (a divider on a striped
   * row would be a redundant boundary). Set `false` for the classic line model
   * (a `border-border-strong` divider between rows, no stripes).
   */
  zebra?: boolean;

  /** Message shown when there are no rows and not loading. */
  emptyMessage?: ReactNode;
  className?: string;
}

// ─── Component (inner, generic) ───────────────────────────────────────────────

/**
 * Branded TanStack Table wrapper with sorting, global filtering, column
 * visibility and optional pagination. The toolbar render-prop hands you the
 * table instance so SearchInput / FacetFilter / ColumnPicker can drive it.
 *
 * Every slice (sorting / columnVisibility / columnFilters / pagination) is
 * independently controllable. Uncontrolled slices are managed internally.
 * Pass `manualSorting` / `manualFiltering` / `manualPagination` to opt into
 * server-driven data; `onServerChange` fires after each slice change so the
 * app can re-fetch.
 *
 * Accepts a forwarded `ref` to the outermost wrapper `<div>` and spreads any
 * additional HTML div props (e.g. `id`, `aria-*`, `data-*`) onto that element.
 */
function DataTableInner<TData, TValue>(
  {
    columns,
    data,
    toolbar,
    enablePagination = false,
    pageSize = 10,

    // Global filter
    globalFilter: globalFilterProp,
    onGlobalFilterChange,

    // Controlled slices
    sorting: sortingProp,
    onSortingChange: onSortingChangeProp,
    columnVisibility: columnVisibilityProp,
    onColumnVisibilityChange: onColumnVisibilityChangeProp,
    columnFilters: columnFiltersProp,
    onColumnFiltersChange: onColumnFiltersChangeProp,
    pagination: paginationProp,
    onPaginationChange: onPaginationChangeProp,

    // Saved views rehydration
    initialView,

    // Server-side model
    manualSorting = false,
    manualFiltering = false,
    manualPagination = false,
    rowCount,
    pageCount,
    onServerChange,

    // Loading
    loading = false,
    loadingRows,

    // Virtualization
    enableRowVirtualization = false,
    estimateRowHeight = 40,
    overscan = 8,
    maxBodyHeight = "32rem",

    zebra = true,
    emptyMessage = "No results.",
    className,
    ...rest
  }: DataTableProps<TData, TValue>,
  ref: React.Ref<HTMLDivElement>,
) {
  // ── Controlled/uncontrolled detection ────────────────────────────────────
  const isSortingControlled = sortingProp !== undefined;
  const isColumnVisibilityControlled = columnVisibilityProp !== undefined;
  const isColumnFiltersControlled = columnFiltersProp !== undefined;
  const isPaginationControlled = paginationProp !== undefined;
  const isFilterControlled = globalFilterProp !== undefined;

  // ── Internal state (only drives a slice when uncontrolled) ───────────────
  const [internalSorting, setInternalSorting] = useState<SortingState>(
    () => initialView?.sorting ?? [],
  );
  const [internalColumnVisibility, setInternalColumnVisibility] = useState<VisibilityState>(
    () => initialView?.columnVisibility ?? {},
  );
  const [internalColumnFilters, setInternalColumnFilters] = useState<ColumnFiltersState>(
    () => initialView?.columnFilters ?? [],
  );
  const [internalPagination, setInternalPagination] = useState<PaginationState>(
    () =>
      initialView?.pagination ?? {
        pageIndex: 0,
        pageSize,
      },
  );
  const [internalGlobalFilter, setInternalGlobalFilter] = useState<string>(
    () => initialView?.globalFilter ?? "",
  );

  // ── Resolved state (controlled wins over internal) ───────────────────────
  const sorting = isSortingControlled ? sortingProp : internalSorting;
  const columnVisibility = isColumnVisibilityControlled
    ? columnVisibilityProp
    : internalColumnVisibility;
  const columnFilters = isColumnFiltersControlled ? columnFiltersProp : internalColumnFilters;
  const pagination = isPaginationControlled ? paginationProp : internalPagination;
  const globalFilter = isFilterControlled ? globalFilterProp : internalGlobalFilter;

  // ── Refs for post-change server callback ─────────────────────────────────
  // We need the current values of ALL slices when any one fires; use refs to
  // avoid stale closures without adding them as deps.
  const sortingRef = useRef(sorting);
  sortingRef.current = sorting;
  const columnFiltersRef = useRef(columnFilters);
  columnFiltersRef.current = columnFilters;
  const paginationRef = useRef(pagination);
  paginationRef.current = pagination;
  const globalFilterRef = useRef(globalFilter);
  globalFilterRef.current = globalFilter;
  const columnVisibilityRef = useRef(columnVisibility);
  columnVisibilityRef.current = columnVisibility;

  // ── Dev-only guard: manualPagination needs a total to compute page count ──
  // Without `rowCount` (or `pageCount`), TanStack's `getPageCount()` falls back
  // to the CURRENT PAGE's row count (manual mode has no full row model), so the
  // pager silently reads "Page 1 of 1" with Next permanently disabled. Warn
  // once per mount so the missing prop is diagnosable instead of silent (#227).
  const warnedMissingRowCountRef = useRef(false);
  useEffect(() => {
    if (
      process.env.NODE_ENV !== "production" &&
      manualPagination &&
      rowCount === undefined &&
      pageCount === undefined &&
      !warnedMissingRowCountRef.current
    ) {
      warnedMissingRowCountRef.current = true;
      console.warn(
        "[DataTable] `manualPagination` is true but neither `rowCount` nor `pageCount` was " +
          'provided — the pager will appear stuck ("Page 1 of 1", Next disabled). Pass ' +
          "`rowCount` (or `pageCount`) so the pager can compute the total.",
      );
    }
  }, [manualPagination, rowCount, pageCount]);

  /** Fire onServerChange with the LATEST slice values (post-update). */
  function fireServerChange(overrides: Partial<DataTableServerArgs> = {}) {
    if (!onServerChange) return;
    onServerChange({
      pagination: paginationRef.current,
      sorting: sortingRef.current,
      columnFilters: columnFiltersRef.current,
      globalFilter: globalFilterRef.current,
      ...overrides,
    });
  }

  // ── Updater helpers — all five slices resolve a functional updater against
  // their *Ref.current (the post-update value), never the render-closure
  // variable, so the resolution stays correct once these callbacks are
  // memoized (a useCallback wrap or the React Compiler) ──────────────────────
  function resolveSorting(updater: Parameters<OnChangeFn<SortingState>>[0]): SortingState {
    return typeof updater === "function" ? updater(sortingRef.current) : updater;
  }
  function resolveColumnVisibility(
    updater: Parameters<OnChangeFn<VisibilityState>>[0],
  ): VisibilityState {
    return typeof updater === "function" ? updater(columnVisibilityRef.current) : updater;
  }
  function resolveColumnFilters(
    updater: Parameters<OnChangeFn<ColumnFiltersState>>[0],
  ): ColumnFiltersState {
    return typeof updater === "function" ? updater(columnFiltersRef.current) : updater;
  }
  function resolvePagination(updater: Parameters<OnChangeFn<PaginationState>>[0]): PaginationState {
    return typeof updater === "function" ? updater(paginationRef.current) : updater;
  }
  function resolveGlobalFilter(updater: Parameters<OnChangeFn<string>>[0]): string {
    return typeof updater === "function" ? updater(globalFilterRef.current) : updater;
  }

  // ── Row models — omit client model for manual slices ─────────────────────
  const sortedRowModel = manualSorting ? {} : { getSortedRowModel: getSortedRowModel() };
  const filteredRowModel = manualFiltering ? {} : { getFilteredRowModel: getFilteredRowModel() };
  // Only attach the client pagination row model when we actually paginate locally.
  // Under `manualPagination`, TanStack ignores a supplied `getPaginationRowModel`
  // (it returns the pre-pagination rows — i.e. the page the app already fetched),
  // so attaching it there is dead per-render work. `(A && !B) || B === A || B`,
  // but the honest single-branch form documents that manual mode needs no model.
  const paginationRowModel =
    enablePagination && !manualPagination ? { getPaginationRowModel: getPaginationRowModel() } : {};

  // ── Table instance ────────────────────────────────────────────────────────
  const table = useReactTable({
    data,
    columns,
    state: { sorting, columnVisibility, columnFilters, globalFilter, pagination },

    // Sorting
    onSortingChange: (updater) => {
      const next = resolveSorting(updater);
      if (!isSortingControlled) setInternalSorting(next);
      onSortingChangeProp?.(updater);
      if (manualSorting) {
        sortingRef.current = next;
        fireServerChange({ sorting: next });
      }
    },

    // Column visibility
    onColumnVisibilityChange: (updater) => {
      const next = resolveColumnVisibility(updater);
      if (!isColumnVisibilityControlled) setInternalColumnVisibility(next);
      onColumnVisibilityChangeProp?.(updater);
      // column visibility is never a "manual" server concern
    },

    // Column filters
    onColumnFiltersChange: (updater) => {
      const next = resolveColumnFilters(updater);
      if (!isColumnFiltersControlled) setInternalColumnFilters(next);
      onColumnFiltersChangeProp?.(updater);
      if (manualFiltering) {
        columnFiltersRef.current = next;
        fireServerChange({ columnFilters: next });
      }
    },

    // Global filter
    onGlobalFilterChange: (updater) => {
      const next = resolveGlobalFilter(updater);
      if (!isFilterControlled) setInternalGlobalFilter(next);
      onGlobalFilterChange?.(next);
      if (manualFiltering) {
        globalFilterRef.current = next;
        fireServerChange({ globalFilter: next });
      }
    },

    // Pagination
    onPaginationChange: (updater) => {
      const next = resolvePagination(updater);
      if (!isPaginationControlled) setInternalPagination(next);
      onPaginationChangeProp?.(updater);
      if (manualPagination) {
        paginationRef.current = next;
        fireServerChange({ pagination: next });
      }
    },

    getCoreRowModel: getCoreRowModel(),
    ...sortedRowModel,
    ...filteredRowModel,
    ...paginationRowModel,

    // Server-side options
    manualSorting,
    manualFiltering,
    manualPagination,
    ...(rowCount !== undefined ? { rowCount } : {}),
    ...(pageCount !== undefined ? { pageCount } : {}),
    // No `initialState`: every slice is driven explicitly via `state` above
    // (internal slices are seeded from `initialView` at useState init), so a
    // TanStack `initialState` would be dead/misleading.
  });

  const rows = table.getRowModel().rows;
  // colSpan for spacer / empty / skeleton cells must match the number of cells a
  // real data row renders (`row.getVisibleCells()`) — use VISIBLE leaf columns so a
  // hidden column (a first-class slice here via columnVisibility + ColumnPicker)
  // doesn't make those rows over-span.
  const colCount = table.getVisibleLeafColumns().length;
  // Virtualized-table ARIA: only a window of rows is mounted, so assistive tech
  // can't infer the true size from the DOM. aria-rowcount counts the header row(s)
  // plus every data row; rendered data rows carry an absolute 1-based aria-rowindex
  // (header rows occupy 1..headerRowCount). Falls back to rows.length for the
  // client path; uses the server `rowCount` total when provided.
  const headerRowCount = table.getHeaderGroups().length;
  const ariaRowCount = (rowCount ?? rows.length) + headerRowCount;

  // ── Scroll container ref for virtualizer ─────────────────────────────────
  const scrollRef = useRef<HTMLDivElement>(null);

  // ── Virtualizer (only active in virtualized branch) ───────────────────────
  const virtualizer = useVirtualizer({
    count: enableRowVirtualization ? rows.length : 0,
    getScrollElement: () => (enableRowVirtualization ? scrollRef.current : null),
    estimateSize: () => estimateRowHeight,
    overscan,
    enabled: enableRowVirtualization,
  });

  const virtualItems = enableRowVirtualization ? virtualizer.getVirtualItems() : [];
  const totalSize = enableRowVirtualization ? virtualizer.getTotalSize() : 0;
  const paddingTop = virtualItems.length > 0 ? (virtualItems[0]?.start ?? 0) : 0;
  const paddingBottom =
    totalSize > 0 ? totalSize - (virtualItems[virtualItems.length - 1]?.end ?? 0) : 0;

  // ─── Empty / loading state ───────────────────────────────────────────────
  const showEmpty = !loading && rows.length === 0;
  const showSkeletons = loading && rows.length === 0;

  // Number of skeleton rows to show — caller can override via `loadingRows`.
  const skeletonRowCount = loadingRows ?? pageSize;

  // ─── Render helpers ───────────────────────────────────────────────────────

  /**
   * thead — sticky in virtualized mode, normal otherwise.
   * `withRowIndex` (virtualized only) sets the header row's `aria-rowindex` so the
   * windowed `aria-rowcount` on the table stays internally consistent with the
   * absolute indices on the data rows.
   */
  function renderThead(sticky: boolean, withRowIndex = false) {
    return (
      <thead
        className={cn(
          // #173: header bottom is the only cue between header and first data row → border-strong
          "border-b border-border-strong",
          // A sticky header scrolls OVER the body, so its fill must be opaque or data
          // rows bleed through the labels; the non-sticky header keeps the /60 wash.
          sticky ? "sticky top-0 z-10 bg-surface-muted" : "bg-surface-muted/60",
        )}
      >
        {table.getHeaderGroups().map((headerGroup, groupIndex) => (
          <tr key={headerGroup.id} aria-rowindex={withRowIndex ? groupIndex + 1 : undefined}>
            {headerGroup.headers.map((header) => {
              const canSort = header.column.getCanSort();
              const sorted = header.column.getIsSorted();
              // String-header fallback (`column.id`) so an icon-only / non-text
              // header still yields a named button (#230).
              const headerLabel =
                typeof header.column.columnDef.header === "string"
                  ? header.column.columnDef.header
                  : header.column.id;
              const sortStateLabel =
                sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : "not sorted";
              const SortIcon =
                sorted === "asc" ? ArrowUp : sorted === "desc" ? ArrowDown : ArrowUpDown;
              return (
                <th
                  key={header.id}
                  aria-sort={
                    canSort
                      ? sorted === "asc"
                        ? "ascending"
                        : sorted === "desc"
                          ? "descending"
                          : "none"
                      : undefined
                  }
                  className="h-10 px-3 text-start align-middle font-medium text-muted-foreground"
                >
                  {header.isPlaceholder ? null : canSort ? (
                    <button
                      type="button"
                      onClick={header.column.getToggleSortingHandler()}
                      aria-label={`Sort by ${headerLabel}, ${sortStateLabel}`}
                      className="inline-flex items-center gap-1 rounded-sm transition-colors duration-fast ease-standard hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      <SortIcon
                        aria-hidden="true"
                        className="size-3 shrink-0 transition-colors duration-fast ease-standard"
                      />
                    </button>
                  ) : (
                    flexRender(header.column.columnDef.header, header.getContext())
                  )}
                </th>
              );
            })}
          </tr>
        ))}
      </thead>
    );
  }

  /**
   * Row separation cue, keyed off the absolute row index so it stays stable
   * under virtualization (a CSS `even:`/`odd:` variant would "swim" as the
   * windowed `<tr>`s recycle).
   *
   * - zebra (default): a gentle `foreground/5` wash on alternate rows is the ONE
   *   separation gesture; rows carry NO divider (#173's strong divider was the cue
   *   only because nothing else was — the stripe replaces it, so a border would now
   *   be redundant per the surface-separation rule).
   * - lines (`zebra={false}`): the classic `border-border-strong` divider between
   *   rows; `last:border-b-0` so the final divider doesn't double with the
   *   container's own bottom border (which reads as a heavy edge / shadow).
   */
  function rowSeparationClass(rowIndex: number): string {
    if (!zebra) return "border-b border-border-strong last:border-b-0";
    return rowIndex % 2 === 1 ? "bg-foreground/5" : "";
  }

  /** A single data row */
  function renderRow(
    row: (typeof rows)[number],
    rowIndex: number,
    extras?: React.HTMLAttributes<HTMLTableRowElement>,
  ) {
    return (
      <tr
        key={row.id}
        data-state={row.getIsSelected() ? "selected" : undefined}
        // Hover/selected are foreground-tint washes so they read more prominent than
        // the zebra stripe in the SAME direction across light/dark themes (the old
        // surface-muted/50 hover went the wrong way over a striped row).
        className={cn(
          // Color-only feedback (no transform/movement) → per
          // docs/MOTION_GUIDELINES.md item 3 this stays under OS reduced-motion
          // (only movement is neutralized); the gated duration-fast/ease-standard
          // pair already collapses toward ~0ms via --motion-factor when the user
          // or OS asks for reduced motion, matching the header sort button.
          "transition-colors duration-fast ease-standard hover:bg-foreground/10 data-[state=selected]:bg-accent",
          rowSeparationClass(rowIndex),
        )}
        {...extras}
      >
        {row.getVisibleCells().map((cell) => (
          <td key={cell.id} className="px-3 py-2 align-middle">
            {flexRender(cell.column.columnDef.cell, cell.getContext())}
          </td>
        ))}
      </tr>
    );
  }

  /**
   * Skeleton placeholder `<tr>`s — shared by the normal and virtualized tbody
   * renderers so a markup/token/a11y fix only needs to be made once (#231).
   */
  function renderSkeletonBody(count: number) {
    return Array.from({ length: count }).map((_, i) => (
      <tr key={`skeleton-${i}`} aria-hidden="true" className={rowSeparationClass(i)}>
        {Array.from({ length: colCount }).map((_, j) => (
          <td key={j} className="px-3 py-2 align-middle">
            <Skeleton className="h-4 w-full" />
          </td>
        ))}
      </tr>
    ));
  }

  /**
   * Empty-state `<tr>` — shared by the normal and virtualized tbody renderers
   * (#231).
   */
  function renderEmptyBody() {
    return (
      <tr>
        <td colSpan={colCount} className="h-24 px-3 text-center text-muted-foreground">
          {emptyMessage}
        </td>
      </tr>
    );
  }

  // ─── Non-virtualized tbody ────────────────────────────────────────────────
  function renderTbodyNormal() {
    if (showSkeletons) {
      return <tbody>{renderSkeletonBody(skeletonRowCount)}</tbody>;
    }

    return <tbody>{showEmpty ? renderEmptyBody() : rows.map((row, i) => renderRow(row, i))}</tbody>;
  }

  // ─── Virtualized tbody ────────────────────────────────────────────────────
  function renderTbodyVirtualized() {
    if (showSkeletons) {
      // For virtualized mode, cap the visible skeleton rows at 10 unless caller
      // has explicitly set loadingRows.
      const virtualSkeletonCount = loadingRows ?? Math.min(10, pageSize);
      return <tbody>{renderSkeletonBody(virtualSkeletonCount)}</tbody>;
    }

    return (
      <tbody>
        {showEmpty ? (
          renderEmptyBody()
        ) : (
          <>
            {/* Top spacer — real <tr> so table layout is preserved */}
            {paddingTop > 0 && (
              <tr aria-hidden="true">
                <td style={{ height: paddingTop }} colSpan={colCount} />
              </tr>
            )}
            {virtualItems.map((virtualRow) => {
              const row = rows[virtualRow.index];
              // row is guaranteed present because virtualizer.count === rows.length,
              // but TypeScript doesn't know array indexing is safe here.
              if (!row) return null;
              return renderRow(row, virtualRow.index, {
                ref: virtualizer.measureElement as React.Ref<HTMLTableRowElement>,
                "data-index": virtualRow.index,
                // Absolute 1-based row position; header row(s) occupy 1..headerRowCount.
                "aria-rowindex": headerRowCount + virtualRow.index + 1,
              } as React.HTMLAttributes<HTMLTableRowElement>);
            })}
            {/* Bottom spacer */}
            {paddingBottom > 0 && (
              <tr aria-hidden="true">
                <td style={{ height: paddingBottom }} colSpan={colCount} />
              </tr>
            )}
          </>
        )}
      </tbody>
    );
  }

  // ─── Pagination controls ──────────────────────────────────────────────────
  function renderPagination() {
    // Virtualization wins over pagination per spec — don't render controls
    if (enableRowVirtualization) return null;
    if (!enablePagination && !manualPagination) return null;

    return (
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount() || 1}
        </p>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            Next
          </Button>
        </div>
      </div>
    );
  }

  // ─── Render ───────────────────────────────────────────────────────────────

  if (enableRowVirtualization) {
    // Virtualized branch: scroll container wraps the whole table
    // If both enablePagination and enableRowVirtualization are set,
    // virtualization wins; pagination controls are silently suppressed.
    return (
      <div ref={ref} className={cn("space-y-3", className)} {...rest}>
        {toolbar ? toolbar(table) : null}
        {/* Outer border is redundant (surface change) → plain border per #173 spec.
            tabIndex={0} makes the windowed scroll region keyboard-operable — the rows
            themselves aren't focusable, so without it the off-screen rows are
            unreachable by keyboard (WCAG 2.1.1 / axe `scrollable-region-focusable`). */}
        <div
          ref={scrollRef}
          tabIndex={0}
          // Names the focus stop (WCAG 4.1.2) without a landmark role — a `role="region"`
          // here would add a redundant landmark over the inner real <table>.
          aria-label="Table contents, scrollable"
          aria-busy={loading || undefined}
          className="relative overflow-auto rounded-lg border bg-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          style={{ maxHeight: maxBodyHeight }}
        >
          {/* Loading overlay */}
          {loading && rows.length > 0 && (
            <div
              role="status"
              aria-live="polite"
              className="absolute inset-0 z-20 flex items-center justify-center rounded-lg bg-card/80"
            >
              <Spinner aria-hidden="true" className="text-foreground" />
              <span className="sr-only">Loading table data…</span>
            </div>
          )}
          <table
            aria-busy={loading || undefined}
            aria-rowcount={ariaRowCount}
            className="w-full caption-bottom text-sm"
          >
            {renderThead(true, true)}
            {renderTbodyVirtualized()}
          </table>
        </div>
      </div>
    );
  }

  // Non-virtualized branch — byte-equivalent behavior to the original
  return (
    <div ref={ref} className={cn("space-y-3", className)} {...rest}>
      {toolbar ? toolbar(table) : null}
      {/* Outer border is redundant (surface change) → plain border per #173 spec */}
      <div
        aria-busy={loading || undefined}
        className="relative overflow-hidden rounded-lg border bg-card"
      >
        {/* Loading overlay */}
        {loading && rows.length > 0 && (
          <div
            role="status"
            aria-live="polite"
            className="absolute inset-0 z-20 flex items-center justify-center rounded-lg bg-card/80"
          >
            <Spinner aria-hidden="true" className="text-foreground" />
            <span className="sr-only">Loading table data…</span>
          </div>
        )}
        <table aria-busy={loading || undefined} className="w-full caption-bottom text-sm">
          {renderThead(false)}
          {renderTbodyNormal()}
        </table>
      </div>

      {renderPagination()}
    </div>
  );
}

// ─── Public export with forwardRef + generic cast ─────────────────────────────
//
// React.forwardRef strips the generic parameter. The cast below restores it so
// callers get full type inference on `columns` / `data` while still being able
// to forward a ref to the root <div>.
//
// The ref prop is already declared in DataTableProps (optional) so existing
// consumers are backward-compatible; the forwardRef call means passing a ref
// object also works.

const DataTableWithRef = forwardRef(DataTableInner) as <TData, TValue>(
  props: DataTableProps<TData, TValue> & { ref?: React.Ref<HTMLDivElement> },
) => React.ReactElement | null;

export { DataTableWithRef as DataTable };
