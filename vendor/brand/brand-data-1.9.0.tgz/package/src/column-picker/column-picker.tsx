import { type Table } from "@tanstack/react-table";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@brand/ui";

export interface ColumnPickerProps<TData> {
  table: Table<TData>;
  /** Trigger label. Defaults to "Columns". */
  label?: string;
}

/** Toggle column visibility for a TanStack table instance. */
export function ColumnPicker<TData>({ table, label = "Columns" }: ColumnPickerProps<TData>) {
  const columns = table.getAllColumns().filter((c) => c.getCanHide());
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          {label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[12rem]">
        <DropdownMenuLabel>Toggle columns</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {columns.map((column) => (
          <DropdownMenuItem
            key={column.id}
            onSelect={(e) => {
              e.preventDefault();
              column.toggleVisibility(!column.getIsVisible());
            }}
          >
            <span
              aria-hidden="true"
              className={
                "flex size-4 items-center justify-center rounded border transition-colors duration-fast ease-standard " +
                (column.getIsVisible()
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-input")
              }
            >
              {column.getIsVisible() ? "✓" : ""}
            </span>
            <span className="capitalize">{column.id}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
