import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

// @xyflow/react requires real layout/measurement — mock the engine and assert
// the brand component's own output. Real rendering + a11y are covered by
// Storybook interaction tests.
vi.mock("@xyflow/react", () => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports -- a vi.mock factory is hoisted above imports; a lazy require avoids the TDZ a top-level import would hit
  const React = require("react");
  return {
    Handle: ({
      type,
      position,
      className,
    }: {
      type: string;
      position: string;
      className?: string;
    }) =>
      React.createElement("div", {
        "data-testid": `handle-${type}`,
        "data-position": position,
        className,
      }),
    Position: { Top: "top", Bottom: "bottom", Left: "left", Right: "right" },
  };
});

import { FlowNode, type BrandFlowNode } from "./flow-node";
import type { NodeProps } from "@xyflow/react";

afterEach(cleanup);

/** Minimal NodeProps factory for FlowNode (BrandFlowNode). */
function makeProps(
  data: BrandFlowNode["data"],
  overrides: Partial<NodeProps<BrandFlowNode>> = {},
): NodeProps<BrandFlowNode> {
  return {
    id: "test-node",
    data,
    selected: false,
    dragging: false,
    zIndex: 0,
    isConnectable: true,
    draggable: true,
    deletable: true,
    selectable: true,
    positionAbsoluteX: 0,
    positionAbsoluteY: 0,
    width: 160,
    height: 48,
    type: "brand",
    ...overrides,
  };
}

describe("FlowNode", () => {
  it("renders the title", () => {
    render(<FlowNode {...makeProps({ title: "My Node" })} />);
    expect(screen.getByText("My Node")).toBeInTheDocument();
  });

  it("renders the subtitle when provided", () => {
    render(<FlowNode {...makeProps({ title: "Node", subtitle: "sub detail" })} />);
    expect(screen.getByText("sub detail")).toBeInTheDocument();
  });

  it("renders the kind eyebrow when provided", () => {
    render(<FlowNode {...makeProps({ title: "Transform", kind: "Source" })} />);
    expect(screen.getByText("Source")).toBeInTheDocument();
  });

  it("renders source and target handles", () => {
    render(<FlowNode {...makeProps({ title: "Node" })} />);
    expect(screen.getByTestId("handle-target")).toBeInTheDocument();
    expect(screen.getByTestId("handle-source")).toBeInTheDocument();
  });

  it("renders an icon when provided", () => {
    render(
      <FlowNode
        {...makeProps({ title: "Node", icon: <svg data-testid="node-icon" aria-hidden="true" /> })}
      />,
    );
    expect(screen.getByTestId("node-icon")).toBeInTheDocument();
  });

  it("omits the subtitle when not provided", () => {
    render(<FlowNode {...makeProps({ title: "Node" })} />);
    // Only the title text should be present
    expect(screen.queryByText("sub detail")).not.toBeInTheDocument();
  });
});
