// eslint-disable-next-line @typescript-eslint/triple-slash-reference -- carry the `*?worker` ambient type into any program that imports this module (apps' tsc).
/// <reference path="../monaco-workers.d.ts" />
/**
 * Monaco web-worker wiring for Vite apps.
 *
 * Monaco runs language intelligence (TS/JS diagnostics, JSON schema, CSS/HTML
 * services) in web workers. This module registers a `MonacoEnvironment.getWorker`
 * factory using Vite's `?worker` import suffix, which makes Vite bundle each
 * worker entry. Import it ONCE at the app entry, before any editor mounts:
 *
 *   import "@brand/editor/monaco-environment";
 *
 * Without this, the editor still renders + highlights, but completions,
 * diagnostics and hovers are unavailable.
 *
 * NOTE: `?worker` is a Vite-only transform. Non-Vite consumers must provide
 * their own `self.MonacoEnvironment.getWorker(Url)` — see the package README.
 */
import type { Environment } from "monaco-editor";
import EditorWorker from "monaco-editor/esm/vs/editor/editor.worker?worker";
import JsonWorker from "monaco-editor/esm/vs/language/json/json.worker?worker";
import CssWorker from "monaco-editor/esm/vs/language/css/css.worker?worker";
import HtmlWorker from "monaco-editor/esm/vs/language/html/html.worker?worker";
import TsWorker from "monaco-editor/esm/vs/language/typescript/ts.worker?worker";

const monacoEnvironment: Environment = {
  getWorker(_workerId: string, label: string): Worker {
    switch (label) {
      case "json":
        return new JsonWorker();
      case "css":
      case "scss":
      case "less":
        return new CssWorker();
      case "html":
      case "handlebars":
      case "razor":
        return new HtmlWorker();
      case "typescript":
      case "javascript":
        return new TsWorker();
      default:
        return new EditorWorker();
    }
  },
};

(globalThis as unknown as { MonacoEnvironment: Environment }).MonacoEnvironment = monacoEnvironment;
