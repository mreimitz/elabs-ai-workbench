"use client";

import { Button } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { CheckIcon, CopyIcon } from "lucide-react";
import { useCallback, useState, type ComponentProps } from "react";

export interface CopyButtonProps extends Omit<ComponentProps<typeof Button>, "value"> {
  /** Text written to the clipboard on click. */
  value: string;
  /** Show the "Copy" / "Copied" label next to the icon. Defaults to true. */
  label?: boolean;
}

/**
 * Brand-ui copy-to-clipboard button with a transient "Copied" state. Shared by
 * the editor toolbar and workspace so the copy affordance is defined once.
 */
export function CopyButton({ value, label = true, className, ...props }: CopyButtonProps) {
  const [copied, setCopied] = useState(false);

  const onClick = useCallback(() => {
    if (typeof navigator === "undefined" || !navigator.clipboard) return;
    void navigator.clipboard.writeText(value).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    });
  }, [value]);

  return (
    <Button
      variant="ghost"
      size="sm"
      {...props}
      type="button"
      className={cn("h-7 gap-1.5", className)}
      onClick={onClick}
      aria-label={copied ? "Copied" : "Copy"}
    >
      {copied ? (
        <CheckIcon
          key={String(copied)}
          className="size-4 text-success animate-in fade-in zoom-in-95 duration-fast ease-entrance"
          aria-hidden="true"
        />
      ) : (
        <CopyIcon className="size-4" aria-hidden="true" />
      )}
      {label ? <span className="text-xs">{copied ? "Copied" : "Copy"}</span> : null}
    </Button>
  );
}
