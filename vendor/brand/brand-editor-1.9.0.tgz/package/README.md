# @brand/editor

A token-themed [Monaco Editor](https://github.com/microsoft/monaco-editor) (the
editor that powers VS Code) wrapped as brand-ui components.

## What this is (and isn't)

Monaco is a **monolithic, self-rendering editor engine** — it mounts into one DOM
node and draws all of its own widgets (autocomplete, find/replace, context menu,
hovers, minimap). Those widgets **cannot** be swapped for brand-ui React
components without forking VS Code. So this package does the two things that
actually make Monaco "fit" the design system:

1. **Themes the inside** via Monaco's theming API — the editor surface _and_ its
   widgets are recolored from the active `data-theme` across all six brand themes
   (the oklch→hex bridge in `lib/monaco-theme-bridge.ts`).
2. **Wraps it in brand-ui chrome** — `EditorToolbar`, `CodeWorkspace` tabs and the
   copy button are brand-ui (`Button`, `Select`, `Tabs`).

This mirrors how `@brand/flow` wraps React Flow and `@brand/data` wraps TanStack:
a powerful third-party engine behind a token-driven brand API. It is intentionally
**not** "source-owned" the way primitives in `@brand/ui` are.

## Components

| Component       | Purpose                                                 |
| --------------- | ------------------------------------------------------- |
| `CodeEditor`    | Single editable Monaco editor (controlled/uncontrolled) |
| `DiffEditor`    | Side-by-side / inline diff (original ↔ modified)        |
| `CodeWorkspace` | Multi-file shell — brand-ui `Tabs` over one editor      |
| `EditorToolbar` | Filename + language `Select` + copy `Button` chrome     |

For **read-only** syntax-highlighted display (not editing), use `CodeBlock` from
`@brand/ai` (Shiki) instead.

## Workers (required for IntelliSense)

Monaco runs language services in web workers. Import the worker setup **once** at
your app entry (Vite):

```ts
import "@brand/editor/monaco-environment";
```

Without it the editor still renders and highlights, but completions/diagnostics
are unavailable. `?worker` is a Vite-only transform — non-Vite bundlers must set
`self.MonacoEnvironment.getWorker(Url)` themselves.

## Usage

```tsx
import { CodeEditor } from "@brand/editor";

<div className="h-[420px]">
  <CodeEditor language="typescript" defaultValue="const a = 1;" onChange={setValue} />
</div>;
```

The editor reads the active theme from `data-theme` (set by `ThemeProvider`) and
re-themes automatically on change — no extra wiring.

## SSR

Components are `"use client"`. `monaco-editor` references browser globals at import
time, so in RSC/SSR apps load the editor in a client-only boundary (e.g. a dynamic
import with SSR disabled).
