import type { Meta, StoryObj } from "@storybook/react-vite";
import { DecorationProvider, type DecorationLevel } from "@brand/tokens";
import { Button } from "./components/button";
import { Card, CardContent, CardHeader, CardTitle } from "./components/card";
import { Badge } from "./components/badge";
import { Input } from "./components/input";

/**
 * Foundation/Decoration — the decoration DIAL (`--decoration`, 0–10), orthogonal
 * to color. The SAME real `@brand/ui` components are rendered across the ramp:
 * 0 = plain themed UI; mid = a gentle graph-paper + hatch texture (fills/shadows
 * stay); 10 = full reprographic drafting (drawn-not-filled, squared, shadowless).
 *
 * It is hue-INDEPENDENT — flip the **theme** toolbar to see the dial on green,
 * navy, light paper, etc. Any story can be swept via the **Decoration** toolbar
 * global (or `globals=decoration:<0..10>`); `blueprint` ships at decoration 10.
 * Set it in code via `<DecorationProvider level={n}>`, a `data-decoration="n"`
 * attribute, or `ThemeProvider`/`useDecoration` (document-level).
 */
const meta = {
  title: "Foundations/Decoration",
  tags: ["autodocs"],
  parameters: { layout: "padded" },
} satisfies Meta;
export default meta;

type Story = StoryObj<typeof meta>;

function Sample() {
  return (
    <Card className="w-64">
      <CardHeader>
        <CardTitle>Revenue</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-display font-semibold tracking-tight text-foreground">$48.2M</p>
        <div className="flex gap-2">
          <Badge>healthy</Badge>
          <Badge variant="warning">degraded</Badge>
        </div>
        <Input placeholder="Filter services…" />
        <div className="flex gap-2">
          <Button>Save</Button>
          <Button variant="outline">Cancel</Button>
        </div>
      </CardContent>
    </Card>
  );
}

const LEVELS: DecorationLevel[] = [0, 4, 8, 10];

export const Dial: Story = {
  render: () => (
    <div className="flex flex-wrap items-start gap-8">
      {LEVELS.map((level) => (
        <div key={level} className="space-y-2">
          <p className="font-mono text-meta uppercase tracking-wider text-muted-foreground">
            decoration {level}
          </p>
          <DecorationProvider level={level}>
            <Sample />
          </DecorationProvider>
        </div>
      ))}
    </div>
  ),
};
