/**
 * sidebar-02 — team switcher.
 * Re-exports the shared `TeamSwitcher` primitive from `@brand/ui` so this block
 * no longer maintains its own copy (issue #99).
 */
export { TeamSwitcher } from "@brand/ui";
export type { TeamSwitcherProps, TeamSwitcherTeam } from "@brand/ui";
