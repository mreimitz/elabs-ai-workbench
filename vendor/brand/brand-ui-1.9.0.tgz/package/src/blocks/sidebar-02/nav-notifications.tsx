/**
 * sidebar-02 — notifications popover.
 * Re-exports the shared `NavNotifications` primitive from `@brand/ui` so this
 * block no longer maintains its own copy (issue #99).
 */
export { NavNotifications as NotificationsPopover } from "@brand/ui";
export type { NavNotificationsProps, NavNotification } from "@brand/ui";
