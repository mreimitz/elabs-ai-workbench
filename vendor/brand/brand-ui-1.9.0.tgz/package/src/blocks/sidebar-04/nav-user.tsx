/**
 * sidebar-04 — account menu. The shared `NavUser` nav primitive lives in
 * `@brand/ui` (#99); this block re-exports it rather than forking a local copy
 * (which drifts). The block's `app-sidebar.tsx` already imports it from `@brand/ui`.
 */
export { NavUser } from "@brand/ui";
