import { type HTMLAttributes, type ReactNode, forwardRef } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Card, CardContent } from "../card";
import { cn } from "../../lib/cn";

/*
 * `emphasis` — size/weight/space ONLY, no new hue (research 11 §B.5 KPI-1/5):
 * `headline` is the answer-leading rung (`text-kpi`, ~32px); `default` stays
 * calm on the intermediate 1.5rem reading rung (the pre-#188 step between
 * `title` and `kpi` — no app role exists there, same precedent as the prose
 * h1/h3 rungs; baselined in the text-scale ratchet).
 */
const metricValueVariants = cva("tabular-nums text-foreground", {
  variants: {
    emphasis: {
      default: "text-2xl font-semibold tracking-tight",
      headline: "text-kpi",
    },
  },
  defaultVariants: { emphasis: "default" },
});

const metricContentVariants = cva("space-y-2", {
  variants: {
    emphasis: {
      default: "p-5",
      headline: "p-6",
    },
  },
  defaultVariants: { emphasis: "default" },
});

export type MetricCardEmphasis = NonNullable<VariantProps<typeof metricValueVariants>["emphasis"]>;

export interface MetricCardProps
  extends HTMLAttributes<HTMLDivElement>, VariantProps<typeof metricValueVariants> {
  label: ReactNode;
  value: ReactNode;
  /** Secondary line under the value — sublabel / context. */
  description?: ReactNode;
  /** Signed change, e.g. "+12.4%". Direction colors it. */
  delta?: string;
  deltaDirection?: "up" | "down" | "neutral";
  /** Whether "up" is good (green) — flip for metrics where down is good. */
  positiveIsGood?: boolean;
  icon?: ReactNode;
  /** Optional inline visual (e.g. a sparkline) shown under the value/description. */
  visual?: ReactNode;
  /**
   * Optional grounding footer (research 11 §B.5 KPI-3) — connects a cited
   * figure to its source (e.g. an `EvidenceChip` from `@brand/ai`). Rendered
   * subdued (`text-meta text-muted-foreground`) under the tile body.
   */
  evidence?: ReactNode;
}

/** Compact KPI tile for dashboards. */
export const MetricCard = forwardRef<HTMLDivElement, MetricCardProps>(function MetricCard(
  {
    label,
    value,
    description,
    delta,
    deltaDirection = "neutral",
    positiveIsGood = true,
    icon,
    visual,
    evidence,
    emphasis,
    className,
    ...props
  },
  ref,
) {
  const good =
    deltaDirection === "up" ? positiveIsGood : deltaDirection === "down" ? !positiveIsGood : null;
  const deltaColor =
    good === null ? "text-muted-foreground" : good ? "text-success-text" : "text-destructive-text";
  // Stable, theme-agnostic polarity hook. The blueprint theme reveals a non-color
  // polarity glyph from this attribute (decoration.css); chromatic themes ignore it
  // and use color. Issue #162.
  const polarity = good === null ? "neutral" : good ? "good" : "bad";
  const arrow = deltaDirection === "up" ? "↑" : deltaDirection === "down" ? "↓" : "";
  // Direction is conveyed visually by the arrow glyph + color; give AT a single
  // unambiguous name ("up 12.4%, favorable") since neither the glyph nor color is a
  // reliable signal (blueprint/high-contrast collapse the hue) — and good/bad
  // polarity is otherwise invisible to AT. See accessibility.md, #162.
  const directionLabel = deltaDirection === "up" ? "up" : deltaDirection === "down" ? "down" : "";
  const polarityLabel = good === null ? "" : good ? ", favorable" : ", unfavorable";

  return (
    <Card ref={ref} className={cn("overflow-hidden", className)} {...props}>
      <CardContent className={metricContentVariants({ emphasis })}>
        <div className="flex items-center justify-between">
          <span className="text-body font-medium text-muted-foreground">{label}</span>
          {icon ? <span className="text-muted-foreground [&_svg]:size-4">{icon}</span> : null}
        </div>
        <div className="flex items-baseline gap-2">
          <span className={metricValueVariants({ emphasis })}>{value}</span>
          {delta ? (
            <span
              data-polarity={polarity}
              className={cn("text-meta tabular-nums", deltaColor)}
              aria-label={directionLabel ? `${directionLabel} ${delta}${polarityLabel}` : undefined}
            >
              {arrow ? <span aria-hidden="true">{arrow} </span> : null}
              {delta}
            </span>
          ) : null}
        </div>
        {description ? (
          <p className="text-meta font-normal text-muted-foreground">{description}</p>
        ) : null}
        {visual ? <div className="pt-1">{visual}</div> : null}
        {evidence ? (
          <div className="pt-1 text-meta font-normal text-muted-foreground">{evidence}</div>
        ) : null}
      </CardContent>
    </Card>
  );
});
