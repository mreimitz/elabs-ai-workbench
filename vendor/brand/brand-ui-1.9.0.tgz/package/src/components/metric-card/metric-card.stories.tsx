import type { Meta, StoryObj } from "@storybook/react-vite";
import { MetricCard } from "./metric-card";

const meta = {
  title: "Core/MetricCard",
  component: MetricCard,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "The canonical KPI tile, owned by @brand/ui (ADR 0012). @brand/charts re-exports this exact " +
          "component as Charts/MetricCard — they are the same component, so import from @brand/ui for app " +
          "UI, or from @brand/charts when already in a charts context. Don't fork a second KPI tile.",
      },
    },
  },
  argTypes: {
    label: {
      description: "Tile label — the metric name shown above the value.",
      control: "text",
      table: { category: "Content" },
    },
    value: {
      description: "Primary metric value (string or ReactNode).",
      control: "text",
      table: { category: "Content" },
    },
    description: {
      description: "Secondary context line under the value.",
      control: "text",
      table: { category: "Content" },
    },
    delta: {
      description: 'Signed change string, e.g. "+12.4%". Direction colors it.',
      control: "text",
      table: { category: "Content" },
    },
    deltaDirection: {
      description: "Direction of the delta — drives the arrow glyph and polarity color.",
      control: { type: "radio" },
      options: ["up", "down", "neutral"],
      table: { category: "State" },
    },
    positiveIsGood: {
      description: "Flip to false for metrics where increase is unfavorable (e.g. churn).",
      control: "boolean",
      table: { category: "Behavior" },
    },
    emphasis: {
      description:
        "`headline` uses the larger kpi text rung; `default` is the calm intermediate rung.",
      control: { type: "radio" },
      options: ["default", "headline"],
      table: { category: "Appearance" },
    },
    icon: {
      description: "Optional icon node shown to the right of the label.",
      control: false,
      table: { category: "Content" },
    },
    visual: {
      description: "Optional inline visual (e.g. sparkline) shown under value/description.",
      control: false,
      table: { category: "Content" },
    },
    evidence: {
      description:
        "Optional grounding footer — connects a figure to its source (e.g. EvidenceChip).",
      control: false,
      table: { category: "Content" },
    },
  },
} satisfies Meta<typeof MetricCard>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    label: "Active users",
    value: "24,512",
    delta: "12.4%",
    deltaDirection: "up",
  },
};

export const WithDescription: Story = {
  args: {
    label: "Monthly Revenue",
    value: "$84.2k",
    description: "vs $80.9k last month",
    delta: "4.1%",
    deltaDirection: "up",
  },
};

export const DeltaDown: Story = {
  args: {
    label: "Churn Rate",
    value: "1.8%",
    description: "0.3 pp worse than target",
    delta: "0.3%",
    deltaDirection: "down",
    positiveIsGood: false,
  },
};

export const DeltaUnfavorable: Story = {
  args: {
    label: "Open tickets",
    value: "37",
    description: "15 unassigned",
    delta: "+9",
    deltaDirection: "up",
    positiveIsGood: false,
  },
};

export const Neutral: Story = {
  args: {
    label: "Sessions",
    value: "100",
    delta: "0%",
    deltaDirection: "neutral",
  },
};

export const NoMetrics: Story = {
  args: {
    label: "Open gaps",
    value: "2",
    description: "in progress",
  },
};

// emphasis="headline" — the answer-leading KPI rung (#191, research 11 §B.5):
// size/weight/space only, the polarity color system is unchanged.
export const Headline: Story = {
  args: {
    emphasis: "headline",
    label: "Net revenue retention",
    value: "118%",
    delta: "+4.2pp",
    deltaDirection: "up",
  },
};

export const WithEvidence: Story = {
  args: {
    label: "Enterprise churn",
    value: "1.8%",
    delta: "0.4pp",
    deltaDirection: "down",
    positiveIsGood: false,
    evidence: <span>Grounded in 3 sources</span>,
  },
};
