import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { MetricCard } from "./metric-card";

describe("MetricCard", () => {
  it("renders label and value", () => {
    render(<MetricCard label="Revenue" value="$42,000" />);
    expect(screen.getByText("Revenue")).toBeInTheDocument();
    expect(screen.getByText("$42,000")).toBeInTheDocument();
  });

  it("renders description when passed", () => {
    render(<MetricCard label="Revenue" value="$42,000" description="vs $40k last month" />);
    expect(screen.getByText("vs $40k last month")).toBeInTheDocument();
  });

  it("does not render description when omitted", () => {
    render(<MetricCard label="Revenue" value="$42,000" />);
    expect(screen.queryByRole("paragraph")).not.toBeInTheDocument();
  });

  it("renders delta text when provided", () => {
    render(<MetricCard label="Users" value="1,234" delta="+12.4%" deltaDirection="up" />);
    expect(screen.getByText(/12\.4%/)).toBeInTheDocument();
  });

  it("renders an optional visual slot", () => {
    render(<MetricCard label="Sales" value="99" visual={<div data-testid="sparkline" />} />);
    expect(screen.getByTestId("sparkline")).toBeInTheDocument();
  });

  it("renders an optional icon slot", () => {
    render(
      <MetricCard label="Orders" value="7" icon={<svg data-testid="icon" aria-hidden="true" />} />,
    );
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  // Polarity (good/bad) must survive monochrome themes via a non-color channel:
  // a stable data-polarity hook + AT aria-label.
  it("marks a favorable delta with data-polarity=good and a favorable AT label", () => {
    render(
      <MetricCard label="Revenue" value="$1M" delta="+12.4%" deltaDirection="up" positiveIsGood />,
    );
    const el = screen.getByLabelText("up +12.4%, favorable");
    expect(el).toHaveAttribute("data-polarity", "good");
  });

  it("marks an unfavorable delta with data-polarity=bad and an unfavorable AT label", () => {
    render(
      <MetricCard
        label="Open tickets"
        value="42"
        delta="+5"
        deltaDirection="up"
        positiveIsGood={false}
      />,
    );
    const el = screen.getByLabelText("up +5, unfavorable");
    expect(el).toHaveAttribute("data-polarity", "bad");
  });

  it("marks a neutral delta with data-polarity=neutral", () => {
    render(<MetricCard label="Sessions" value="100" delta="0%" deltaDirection="neutral" />);
    const el = screen.getByText(/0%/).closest("[data-polarity]");
    expect(el).toHaveAttribute("data-polarity", "neutral");
  });

  // emphasis axis (#191, research 11 §B.5 KPI-1): size/weight/space only — the
  // headline rung is text-kpi; default stays on the calm intermediate rung.
  it("renders the calm default value rung by default", () => {
    render(<MetricCard label="Revenue" value="$1M" />);
    const value = screen.getByText("$1M");
    expect(value.className).toContain("text-2xl");
    expect(value.className).not.toContain("text-kpi");
  });

  it("renders the headline kpi rung for emphasis=headline", () => {
    render(<MetricCard emphasis="headline" label="Revenue" value="$1M" />);
    const value = screen.getByText("$1M");
    expect(value.className).toContain("text-kpi");
    expect(value.className).not.toContain("text-2xl");
  });

  it("renders an optional evidence footer slot (#191, KPI-3)", () => {
    render(
      <MetricCard
        label="Revenue"
        value="$1M"
        evidence={<span data-testid="evidence">3 sources</span>}
      />,
    );
    expect(screen.getByTestId("evidence")).toBeInTheDocument();
  });
});
