import type { Meta, StoryObj } from "@storybook/react-vite";
import { MatchHighlight } from "./match-highlight";

const meta = {
  title: "Typography/MatchHighlight",
  component: MatchHighlight,
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "Wraps query matches inside a string in real `<mark>` elements, styled with the semantic `--highlight` token pair (AA-legible ink in every theme). Presentation-only — pass `query` (case-insensitive by default) or precomputed `ranges` from your own fuzzy matcher.",
      },
    },
  },
  argTypes: {
    text: { control: "text" },
    query: { control: "text" },
    caseSensitive: { control: "boolean" },
  },
} satisfies Meta<typeof MatchHighlight>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { text: "My Notes note", query: "note" },
  render: (args) => (
    <p className="max-w-md text-body text-foreground">
      <MatchHighlight {...args} />
    </p>
  ),
};

/** A search-result title inside a paragraph — the canonical omnisearch use. */
export const InParagraph: Story = {
  render: () => (
    <p className="max-w-md text-body text-foreground">
      The <MatchHighlight text="quarterly revenue report" query="revenue" /> was updated after the{" "}
      <MatchHighlight text="board meeting" query="board" /> concluded.
    </p>
  ),
};

/** Multiple needles (e.g. every token of a multi-word query). */
export const MultipleNeedles: Story = {
  args: { text: "red green blue amber", query: ["red", "blue"] },
  render: (args) => (
    <p className="text-body text-foreground">
      <MatchHighlight {...args} />
    </p>
  ),
};

/** Precomputed ranges from a fuzzy matcher (overlapping/adjacent are merged). */
export const PrecomputedRanges: Story = {
  render: () => (
    <p className="text-body text-foreground">
      <MatchHighlight
        text="src/features/document/backlinks-panel.tsx"
        ranges={[
          [4, 12],
          [13, 21],
        ]}
      />
    </p>
  ),
};

/** No match → the string renders normally (never broken markup). */
export const NoMatch: Story = {
  args: { text: "nothing to highlight here", query: "zzz" },
  render: (args) => (
    <p className="text-body text-foreground">
      <MatchHighlight {...args} />
    </p>
  ),
};

/**
 * Long content truncates cleanly. The flex child needs `min-w-0` for `truncate`
 * to engage (the interaction-guidelines "silent culprit").
 */
export const LongStringTruncation: Story = {
  render: () => (
    <div className="flex w-64 items-center gap-2 rounded-md border border-border bg-card p-2">
      <span className="min-w-0 flex-1 truncate text-body text-foreground">
        <MatchHighlight
          text="A very long document title that will definitely overflow its container and must ellipsis"
          query="document"
        />
      </span>
    </div>
  ),
};
