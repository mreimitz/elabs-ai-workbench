/**
 * StatusBadge — the canonical execution-status vocabulary (#189, research 10 §B.1).
 *
 * One CLOSED 7-state enum unifies the five status idioms across the agent
 * trace components (`@brand/ai` Tool / ChainOfThought / Confirmation /
 * TestResults / Sandbox), so one agent run reads as one author and an agent
 * picks a status by MEANING — it cannot emit a color or a freeform string.
 *
 * Hybrid visual (research 08 "green deliberate / status sparingly"): the calm
 * states — including `complete` — render the quiet `bg-<status>/10` alpha-wash
 * or a neutral fill; ONLY the two attention states (`awaiting-approval`,
 * `failed`) get the solid status fill, so a settled transcript stays calm and
 * the states that need a human grab the eye.
 *
 * Builds ON the existing Badge cva (badge.tsx) — same pill geometry and
 * typography; status colors are semantic tokens only.
 */
import { forwardRef, type HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import {
  AlertCircle,
  CheckCircle2,
  Circle,
  Clock,
  Loader2,
  MinusCircle,
  XCircle,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";
import { badgeVariants } from "../badge/badge";
import { cn } from "../../lib/cn";

/** The canonical, closed 7-state status enum (research 10 §B.1). */
export const STATUSES = [
  "pending",
  "running",
  "complete",
  "awaiting-approval",
  "denied",
  "failed",
  "skipped",
] as const;

export type Status = (typeof STATUSES)[number];

/** Default human-readable label per status (override via `children`). */
export const STATUS_LABELS: Record<Status, string> = {
  pending: "Pending",
  running: "Running",
  complete: "Complete",
  "awaiting-approval": "Awaiting approval",
  denied: "Denied",
  failed: "Failed",
  skipped: "Skipped",
};

const STATUS_ICONS: Record<Status, LucideIcon> = {
  pending: Circle,
  running: Loader2,
  complete: CheckCircle2,
  "awaiting-approval": Clock,
  denied: XCircle,
  failed: AlertCircle,
  skipped: MinusCircle,
};

/**
 * On-surface icon color per status for the standalone `StatusIcon` atom.
 * (Inside `StatusBadge` the icon inherits the badge foreground instead, so it
 * stays legible on the solid attention fills.)
 */
const STATUS_ICON_CLASSES: Record<Status, string> = {
  pending: "text-muted-foreground",
  running: "text-info-text",
  complete: "text-success-text",
  "awaiting-approval": "text-warning-text",
  denied: "text-muted-foreground",
  failed: "text-destructive-text",
  skipped: "text-muted-foreground",
};

/** `animate-spin` is a continuous loop (ease-linear is the allowed loop ease). */
const RUNNING_SPIN_CLASSES = "animate-spin motion-reduce:animate-none";

export interface StatusIconProps extends Omit<LucideProps, "ref"> {
  /** The canonical execution status (closed enum). */
  status: Status;
}

/**
 * The icon + status-color atom `StatusBadge` itself composes — for tight rows
 * (test-result rows, timeline/rail nodes) where a full badge is too heavy.
 * Decorative by default (`aria-hidden`); the adjacent row text must carry the
 * status name for AT users.
 */
export const StatusIcon = forwardRef<SVGSVGElement, StatusIconProps>(function StatusIcon(
  { status, className, ...props },
  ref,
) {
  const Icon = STATUS_ICONS[status];
  return (
    <Icon
      ref={ref}
      aria-hidden="true"
      data-status={status}
      className={cn(
        "size-4 shrink-0",
        STATUS_ICON_CLASSES[status],
        status === "running" && RUNNING_SPIN_CLASSES,
        className,
      )}
      {...props}
    />
  );
});

export const statusBadgeVariants = cva(
  // Builds on the Badge pill (geometry + typography from badge.tsx). The
  // `outline` variant carries no fill, so each status sets its own
  // border/bg/text — conflicts resolve via cn() (later utilities win).
  cn(badgeVariants({ variant: "outline" }), "[&_svg]:shrink-0"),
  {
    variants: {
      status: {
        // calm: neutral fill
        pending: "border-transparent bg-secondary text-secondary-foreground",
        // calm: status alpha-wash (escapes the decoration drawn-not-filled rule)
        running: "border-info/40 bg-info/10 text-info-text",
        complete: "border-success/40 bg-success/10 text-success-text",
        // ATTENTION: solid fill — must grab the eye
        "awaiting-approval": "border-transparent bg-warning text-warning-foreground",
        // calm: de-emphasized neutrals
        denied: "border-transparent bg-muted text-muted-foreground",
        // ATTENTION: solid fill — must grab the eye
        failed: "border-transparent bg-destructive text-destructive-foreground",
        skipped: "border-transparent bg-secondary text-muted-foreground",
      },
      /** `md` for inline use; `sm` for rail nodes / dense rows. */
      size: {
        sm: "px-2 [&_svg]:size-3",
        md: "[&_svg]:size-3.5",
      },
    },
    defaultVariants: { size: "md" },
  },
);

export interface StatusBadgeProps
  extends
    HTMLAttributes<HTMLSpanElement>,
    Omit<VariantProps<typeof statusBadgeVariants>, "status"> {
  /** The canonical execution status (closed enum). */
  status: Status;
  /** Render label-only (no status icon). */
  hideIcon?: boolean;
}

export const StatusBadge = forwardRef<HTMLSpanElement, StatusBadgeProps>(function StatusBadge(
  { status, size, hideIcon = false, className, children, ...props },
  ref,
) {
  const Icon = STATUS_ICONS[status];
  return (
    <span
      ref={ref}
      data-status={status}
      className={cn(statusBadgeVariants({ status, size }), className)}
      {...props}
    >
      {hideIcon ? null : (
        <Icon
          aria-hidden="true"
          className={status === "running" ? RUNNING_SPIN_CLASSES : undefined}
        />
      )}
      {children ?? STATUS_LABELS[status]}
    </span>
  );
});

/** The editor/markdown `Timeline` 3-state vocabulary (`@brand/editor`). */
export type TimelineStatus = "done" | "active" | "pending";

const TIMELINE_STATUS_MAP: Record<TimelineStatus, Status> = {
  done: "complete",
  active: "running",
  pending: "pending",
};

/**
 * Map the Timeline `done|active|pending` vocabulary onto the canonical
 * `Status` (research 10 §B.1 mapping b — lossless; the timeline only
 * expresses 3 of the 7 states). The AI-SDK `ToolUIPart` mapper lives in
 * `@brand/ai` (`statusFromToolState`, tool.tsx) so `@brand/ui` stays free of
 * the `ai` dependency (D6).
 */
export function fromTimelineStatus(status: TimelineStatus): Status {
  return TIMELINE_STATUS_MAP[status];
}
