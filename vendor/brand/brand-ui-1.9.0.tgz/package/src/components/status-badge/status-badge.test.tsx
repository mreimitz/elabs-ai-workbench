import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import {
  STATUSES,
  STATUS_LABELS,
  StatusBadge,
  StatusIcon,
  fromTimelineStatus,
} from "./status-badge";

describe("StatusBadge", () => {
  it("renders the default label for every canonical status", () => {
    render(
      <div>
        {STATUSES.map((status) => (
          <StatusBadge key={status} status={status} />
        ))}
      </div>,
    );
    for (const status of STATUSES) {
      expect(screen.getByText(STATUS_LABELS[status])).toBeInTheDocument();
    }
  });

  it("children override the default label", () => {
    render(<StatusBadge status="complete">12 passed</StatusBadge>);
    expect(screen.getByText("12 passed")).toBeInTheDocument();
    expect(screen.queryByText("Complete")).not.toBeInTheDocument();
  });

  it("hides the decorative icon from AT and exposes data-status", () => {
    const { container } = render(<StatusBadge status="failed" />);
    const badge = container.querySelector('[data-status="failed"]');
    expect(badge).not.toBeNull();
    const icon = badge?.querySelector("svg");
    expect(icon).not.toBeNull();
    expect(icon?.getAttribute("aria-hidden")).toBe("true");
  });

  it("only the two attention states get the solid fill (hybrid visual)", () => {
    const { container } = render(
      <div>
        {STATUSES.map((status) => (
          <StatusBadge key={status} status={status} />
        ))}
      </div>,
    );
    const classesFor = (status: string) =>
      container.querySelector(`[data-status="${status}"]`)?.className ?? "";
    expect(classesFor("awaiting-approval")).toContain("bg-warning");
    expect(classesFor("failed")).toContain("bg-destructive");
    // calm states: wash or neutral, never the solid status fill
    expect(classesFor("complete")).toContain("bg-success/10");
    expect(classesFor("running")).toContain("bg-info/10");
    expect(classesFor("pending")).toContain("bg-secondary");
  });

  it("running spins with a motion-reduce neutralizer", () => {
    const { container } = render(<StatusBadge status="running" />);
    const icon = container.querySelector("svg");
    expect(icon?.getAttribute("class")).toContain("animate-spin");
    expect(icon?.getAttribute("class")).toContain("motion-reduce:animate-none");
  });

  it("merges className last and spreads props", () => {
    const { container } = render(
      <StatusBadge className="bg-muted" data-testid="badge" status="pending" />,
    );
    const badge = container.querySelector('[data-testid="badge"]');
    expect(badge?.className).toContain("bg-muted");
    expect(badge?.className).not.toContain("bg-secondary");
  });
});

describe("StatusIcon", () => {
  it("is decorative (aria-hidden) and status-colored", () => {
    const { container } = render(<StatusIcon status="complete" />);
    const icon = container.querySelector("svg");
    expect(icon?.getAttribute("aria-hidden")).toBe("true");
    expect(icon?.getAttribute("class")).toContain("text-success-text");
  });
});

describe("fromTimelineStatus", () => {
  it("maps the timeline 3-state vocabulary losslessly", () => {
    expect(fromTimelineStatus("done")).toBe("complete");
    expect(fromTimelineStatus("active")).toBe("running");
    expect(fromTimelineStatus("pending")).toBe("pending");
  });
});
