import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect } from "storybook/test";
import { Slider } from "./slider";
const meta = {
  title: "Forms/Slider",
  component: Slider,
  tags: ["autodocs"],
  argTypes: {
    defaultValue: {
      description: "Uncontrolled initial value(s) as an array.",
      control: false,
      table: { category: "State" },
    },
    value: {
      description: "Controlled value(s) as an array.",
      control: false,
      table: { category: "State" },
    },
    min: {
      description: "Minimum value of the range.",
      control: "number",
      table: { category: "Behavior" },
    },
    max: {
      description: "Maximum value of the range.",
      control: "number",
      table: { category: "Behavior" },
    },
    step: {
      description: "Increment between selectable values.",
      control: "number",
      table: { category: "Behavior" },
    },
    disabled: {
      description: "Disables the slider.",
      control: "boolean",
      table: { category: "State" },
    },
    orientation: {
      description: "Layout direction of the slider.",
      control: { type: "radio" },
      options: ["horizontal", "vertical"],
      table: { category: "Appearance" },
    },
    onValueChange: {
      description: "Called when the slider value changes.",
      control: false,
      table: { category: "Behavior" },
    },
    className: {
      description: "Additional CSS classes applied to the root element.",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Slider>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => <Slider defaultValue={[50]} max={100} step={1} className="w-64" />,
  // Confirms the slider thumb is present and has the expected value attribute.
  play: async ({ canvas }) => {
    const thumb = canvas.getByRole("slider");
    await expect(thumb).toBeInTheDocument();
    await expect(thumb).toHaveAttribute("aria-valuenow", "50");
  },
};
