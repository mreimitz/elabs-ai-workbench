import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect } from "storybook/test";
import { THEMES, ThemeProvider } from "@brand/tokens";

import { ThemeSwitcher } from "./theme-switcher";

const meta = {
  title: "Core/ThemeSwitcher",
  component: ThemeSwitcher,
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <ThemeProvider>
        <div className="flex min-h-32 items-center justify-center">
          <Story />
        </div>
      </ThemeProvider>
    ),
  ],
  argTypes: {
    mode: {
      description: "Force presentation mode; `auto` picks toggle vs dropdown by theme count.",
      control: "inline-radio",
      options: ["auto", "toggle", "dropdown"],
      table: { category: "Behavior" },
    },
    effect: {
      description: "Whole-screen reveal animation used when switching themes.",
      control: { type: "select" },
      options: ["polygon", "circle", "circle-blur", "triangle"],
      table: { category: "Appearance" },
    },
    size: {
      description: "Button size of the trigger.",
      control: "inline-radio",
      options: ["sm", "default", "lg"],
      table: { category: "Appearance" },
    },
    showSystem: {
      description: 'Whether to offer a "System" option that follows the OS color scheme.',
      control: "boolean",
      table: { category: "Behavior" },
    },
    themes: {
      description: "Theme names to offer. ≤2 → toggle; >2 → dropdown.",
      control: false,
      table: { category: "Behavior" },
    },
  },
} satisfies Meta<typeof ThemeSwitcher>;
export default meta;

type Story = StoryObj<typeof meta>;

/** Default: the Qlik light/dark pair → a cycling light / dark / system toggle. */
export const Toggle: Story = {
  play: async ({ canvas }) => {
    // The toggle button is present and has an accessible label describing the cycle action.
    const btn = canvas.getByRole("button", { name: /theme/i });
    await expect(btn).toBeInTheDocument();
    await expect(btn).toHaveAttribute("aria-label");
  },
};

/** More than two themes → auto-upgrades to a dropdown over all of them. */
export const Dropdown: Story = { args: { themes: [...THEMES] } };

/** Toggle without the System option (light / dark only). */
export const ToggleNoSystem: Story = { args: { showSystem: false } };

/** A custom (non-default) theme pair — here Qlik Bright + Blueprint. ≤2 themes still toggle. */
export const CustomPair: Story = { args: { themes: ["qlik-bright", "blueprint"] } };
