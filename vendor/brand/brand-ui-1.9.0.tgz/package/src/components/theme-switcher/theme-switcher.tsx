"use client";

import { forwardRef, useCallback, useEffect, useState, type HTMLAttributes } from "react";
import { Check, Monitor, Moon, Sun } from "lucide-react";
import { THEME_META, useTheme, type ThemeName } from "@brand/tokens";

import { Button } from "../button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../tooltip";
import { useThemeTransition, type ThemeTransitionEffect } from "./use-theme-transition";

const SYSTEM_STORAGE_KEY = "brand-ui-theme-system";
const DARK_QUERY = "(prefers-color-scheme: dark)";

/** Default light/dark pair used when an app doesn't pass its own `themes`. */
export const DEFAULT_THEME_PAIR: ThemeName[] = ["qlik-bright", "qlik-dark"];

type ButtonSize = "sm" | "default" | "lg";
const ICON_SIZE: Record<ButtonSize, "icon-sm" | "icon" | "icon-lg"> = {
  sm: "icon-sm",
  default: "icon",
  lg: "icon-lg",
};

export interface ThemeSwitcherProps extends Omit<HTMLAttributes<HTMLButtonElement>, "onChange"> {
  /** Themes to offer. ≤2 → toggle; >2 → dropdown. Defaults to the Qlik light/dark pair. */
  themes?: ThemeName[];
  /** Force presentation; "auto" (default) picks toggle vs dropdown by theme count. */
  mode?: "auto" | "toggle" | "dropdown";
  /** Offer a "System" option that follows the OS color scheme. Default true. */
  showSystem?: boolean;
  /** Whole-screen reveal effect for the animated switch. Default "polygon". */
  effect?: ThemeTransitionEffect;
  /** Control size. Default "default". */
  size?: ButtonSize;
}

function prefersDark(): boolean {
  return typeof window !== "undefined" && window.matchMedia(DARK_QUERY).matches;
}

/**
 * Adaptive theme control. With ≤2 themes it renders a light/dark/system toggle
 * (a single icon button that cycles); with >2 it auto-upgrades to a dropdown
 * over the offered themes. Every switch animates the whole screen via
 * `useThemeTransition` (respecting reduced motion). Icons follow each theme's
 * `dark` flag, so it works for any of the six brand themes — not just light/dark.
 */
export const ThemeSwitcher = forwardRef<HTMLButtonElement, ThemeSwitcherProps>(
  function ThemeSwitcher(
    {
      themes = DEFAULT_THEME_PAIR,
      mode = "auto",
      showSystem = true,
      effect = "polygon",
      size = "default",
      className,
      ...props
    },
    ref,
  ) {
    const { theme, setTheme } = useTheme();
    const switchTheme = useThemeTransition(effect);
    const [isSystem, setIsSystem] = useState(false);

    // Drop any unknown theme name (e.g. a stale prop) so a bad value degrades
    // to the default pair instead of crashing the whole render on THEME_META[t].
    const offered = themes.filter((t) => THEME_META[t]);
    const safeThemes: ThemeName[] = offered.length > 0 ? offered : DEFAULT_THEME_PAIR;

    const lightTheme: ThemeName = safeThemes.find((t) => !THEME_META[t].dark) ?? "qlik-bright";
    const darkTheme: ThemeName = safeThemes.find((t) => THEME_META[t].dark) ?? "qlik-dark";

    // Hydrate the "system" choice and keep it tracking the OS while active.
    useEffect(() => {
      if (typeof window === "undefined") return;
      const active = window.localStorage.getItem(SYSTEM_STORAGE_KEY) === "1";
      setIsSystem(active);
      if (active) setTheme(prefersDark() ? darkTheme : lightTheme);
      const mql = window.matchMedia(DARK_QUERY);
      const onChange = () => {
        if (window.localStorage.getItem(SYSTEM_STORAGE_KEY) === "1") {
          setTheme(prefersDark() ? darkTheme : lightTheme);
        }
      };
      mql.addEventListener("change", onChange);
      return () => mql.removeEventListener("change", onChange);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const pickTheme = useCallback(
      (next: ThemeName) => {
        setIsSystem(false);
        if (typeof window !== "undefined") window.localStorage.setItem(SYSTEM_STORAGE_KEY, "0");
        switchTheme(next);
      },
      [switchTheme],
    );

    const pickSystem = useCallback(() => {
      setIsSystem(true);
      if (typeof window !== "undefined") window.localStorage.setItem(SYSTEM_STORAGE_KEY, "1");
      switchTheme(prefersDark() ? darkTheme : lightTheme);
    }, [switchTheme, darkTheme, lightTheme]);

    const TriggerIcon = isSystem ? Monitor : THEME_META[theme].dark ? Moon : Sun;
    const useDropdown = mode === "dropdown" || (mode === "auto" && safeThemes.length > 2);

    // ---- Dropdown mode (>2 themes) ----
    if (useDropdown) {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              ref={ref}
              variant="outline"
              size={ICON_SIZE[size]}
              aria-label="Theme"
              className={className}
              {...props}
            >
              <TriggerIcon />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {showSystem ? (
              <DropdownMenuItem onSelect={() => pickSystem()}>
                <Monitor />
                <span>System</span>
                {isSystem ? <Check className="ml-auto" /> : null}
              </DropdownMenuItem>
            ) : null}
            {safeThemes.map((t) => (
              <DropdownMenuItem key={t} onSelect={() => pickTheme(t)}>
                {THEME_META[t].dark ? <Moon /> : <Sun />}
                <span>{THEME_META[t].label}</span>
                {!isSystem && theme === t ? <Check className="ml-auto" /> : null}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }

    // ---- Toggle mode (≤2 themes): cycle light → dark → (system) ----
    const order: Array<"light" | "dark" | "system"> = showSystem
      ? ["light", "dark", "system"]
      : ["light", "dark"];
    const current: "light" | "dark" | "system" = isSystem
      ? "system"
      : theme === darkTheme
        ? "dark"
        : "light";
    const next = order[(order.indexOf(current) + 1) % order.length];
    const apply = () => {
      if (next === "system") pickSystem();
      else pickTheme(next === "dark" ? darkTheme : lightTheme);
    };

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              ref={ref}
              variant="ghost"
              size={ICON_SIZE[size]}
              aria-label={`Theme: ${current}. Activate to switch to ${next}.`}
              onClick={apply}
              className={className}
              {...props}
            >
              <TriggerIcon />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="capitalize">{current}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  },
);
