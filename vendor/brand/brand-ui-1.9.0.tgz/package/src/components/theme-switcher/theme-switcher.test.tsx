import type { ReactElement } from "react";
import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { THEMES, ThemeProvider } from "@brand/tokens";

import { ThemeSwitcher } from "./theme-switcher";

function setup(ui: ReactElement) {
  return render(<ThemeProvider>{ui}</ThemeProvider>);
}

describe("ThemeSwitcher", () => {
  it("renders a toggle button for a 2-theme pair", () => {
    setup(<ThemeSwitcher themes={["qlik-bright", "qlik-dark"]} />);
    expect(screen.getByRole("button", { name: /theme:/i })).toBeInTheDocument();
  });

  it("cycles the theme on click (jsdom has no startViewTransition → instant setTheme)", async () => {
    setup(<ThemeSwitcher themes={["qlik-bright", "qlik-dark"]} showSystem={false} />);
    await userEvent.click(screen.getByRole("button", { name: /theme:/i }));
    expect(document.documentElement.getAttribute("data-theme")).toBe("qlik-dark");
  });

  it("renders a dropdown trigger when more than two themes are offered", () => {
    setup(<ThemeSwitcher themes={[...THEMES]} />);
    expect(screen.getByRole("button", { name: "Theme" })).toBeInTheDocument();
  });
});
