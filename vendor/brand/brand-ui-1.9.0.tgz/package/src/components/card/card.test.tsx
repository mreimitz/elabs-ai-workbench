import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { Card, CardTitle } from "./card";

describe("Card", () => {
  it("renders a nested title", () => {
    render(
      <Card>
        <CardTitle>Hello</CardTitle>
      </Card>,
    );
    expect(screen.getByText("Hello")).toBeInTheDocument();
  });

  it("uses the shared container radius rung (rounded-lg, not the ambiguous rounded-xl) (#19)", () => {
    render(<Card data-testid="card">x</Card>);
    const card = screen.getByTestId("card");
    expect(card).toHaveClass("rounded-lg");
    expect(card).not.toHaveClass("rounded-xl");
  });

  // --- optional detail panel (#117) ---
  it("without `detail`, renders a plain card — no grid, no panel (backwards compatible)", () => {
    render(<Card data-testid="card">body</Card>);
    const card = screen.getByTestId("card");
    expect(card).not.toHaveClass("grid");
    expect(card.textContent).toBe("body");
  });

  it("with `detail` (fixed, the default), renders the panel beside the main content", () => {
    render(
      <Card data-testid="card" detail={<span>DETAIL</span>}>
        <span>MAIN</span>
      </Card>,
    );
    const card = screen.getByTestId("card");
    expect(card).toHaveClass("grid");
    expect(screen.getByText("MAIN")).toBeInTheDocument();
    expect(screen.getByText("DETAIL")).toBeInTheDocument();
    expect(card.className).toContain("grid-cols-[minmax(0,1fr)_var(--card-detail-size)]");
  });

  it("with `detail` + hover, keeps the panel in the DOM but hides it from AT when collapsed", () => {
    render(
      <Card data-testid="card" detailReveal="hover" detail={<button>More</button>}>
        main
      </Card>,
    );
    const card = screen.getByTestId("card");
    // collapsed at rest; revealed on hover AND keyboard focus-within
    expect(card.className).toContain("grid-cols-[minmax(0,1fr)_0px]");
    expect(card.className).toContain(
      "focus-within:grid-cols-[minmax(0,1fr)_var(--card-detail-size)]",
    );
    // detail panel is in the DOM but hidden from AT at rest (aria-hidden=true, #141)
    const region = card.querySelector("[role='region']");
    expect(region).not.toBeNull();
    expect(region).toHaveAttribute("aria-hidden", "true");
  });

  it("with `detail` + hover, detail region is labelled (landmark navigation, #141)", () => {
    render(
      <Card detailReveal="hover" detail={<span>info</span>} detailLabel="Card details">
        main
      </Card>,
    );
    const region = document.querySelector("[role='region']");
    expect(region).toHaveAttribute("aria-label", "Card details");
  });

  it("with `detail` (fixed), detail region is labelled and always visible to AT", () => {
    render(
      <Card data-testid="card" detail={<span>D</span>} detailLabel="More info">
        main
      </Card>,
    );
    // getByRole respects aria-hidden; fixed panel should NOT be aria-hidden
    const region = screen.getByRole("region", { name: "More info" });
    expect(region).toBeInTheDocument();
    expect(region).not.toHaveAttribute("aria-hidden");
  });

  it("supports bottom placement (a row grid track instead of a column)", () => {
    render(
      <Card data-testid="card" detailPlacement="bottom" detail={<span>D</span>}>
        m
      </Card>,
    );
    expect(screen.getByTestId("card").className).toContain(
      "grid-rows-[minmax(0,1fr)_var(--card-detail-size)]",
    );
  });

  it("drives the panel track from the --card-detail-size custom property (default + override)", () => {
    const { rerender } = render(
      <Card data-testid="card" detail="d">
        m
      </Card>,
    );
    expect(screen.getByTestId("card").style.getPropertyValue("--card-detail-size")).toBe("16rem");
    rerender(
      <Card data-testid="card" detail="d" detailSize="20rem">
        m
      </Card>,
    );
    expect(screen.getByTestId("card").style.getPropertyValue("--card-detail-size")).toBe("20rem");
  });
});
