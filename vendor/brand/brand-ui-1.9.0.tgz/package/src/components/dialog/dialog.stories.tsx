import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, waitFor, within } from "storybook/test";
import { Button } from "../button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./dialog";

const meta = { title: "Overlays/Dialog", component: Dialog, tags: ["autodocs"] } satisfies Meta<
  typeof Dialog
>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button>Open dialog</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete project</DialogTitle>
          <DialogDescription>This action cannot be undone.</DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button variant="destructive">Delete</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
  // Proves the trigger opens the Radix dialog into its portal (mounted on
  // document.body, outside the story canvas) with the right title.
  play: async ({ canvas, canvasElement, userEvent }) => {
    await userEvent.click(canvas.getByRole("button", { name: /open dialog/i }));
    const body = within(canvasElement.ownerDocument.body);
    const dialog = await body.findByRole("dialog");
    // waitFor rides out the entrance animation (opacity starts at 0).
    await waitFor(() => expect(within(dialog).getByText("Delete project")).toBeVisible());
  },
};

/**
 * Overflow guard (regression): a `max-w-md` dialog holding a long, unbreakable
 * path inside a `truncate` row. The `minmax(0,1fr)` grid column lets the row
 * shrink and truncate, so the dialog must stay at `max-w-md` and never scroll
 * horizontally. Before the fix the implicit `auto` column blew past `max-w-md`.
 */
export const OverflowGuard: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button>Open settings</Button>
      </DialogTrigger>
      <DialogContent size="sm" className="max-w-md">
        <DialogHeader>
          <DialogTitle>Repository path</DialogTitle>
          <DialogDescription>The dialog must not widen to fit this path.</DialogDescription>
        </DialogHeader>
        <div className="truncate rounded-md border border-border bg-surface-muted px-3 py-2 font-mono text-caption">
          ~/Developer/workspaces/monorepo/packages/very-long-package-name/src/features/extremely-deeply-nested/configuration/settings.local.json
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
  // Real-surface proof: open the dialog, then assert it never overflows
  // horizontally (scrollWidth must not exceed clientWidth). This is the check
  // jsdom can't do — it needs a real layout engine.
  play: async ({ canvas, canvasElement, userEvent }) => {
    await userEvent.click(canvas.getByRole("button", { name: /open settings/i }));
    const body = within(canvasElement.ownerDocument.body);
    const dialog = await body.findByRole("dialog");
    await waitFor(() => expect(within(dialog).getByText("Repository path")).toBeVisible());
    // No horizontal overflow: the long path truncated instead of widening it.
    expect(dialog.scrollWidth).toBeLessThanOrEqual(dialog.clientWidth + 1);
  },
};
