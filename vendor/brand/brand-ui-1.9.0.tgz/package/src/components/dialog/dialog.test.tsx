import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./dialog";

function Wrapper({ size }: { size?: "sm" | "lg" | "xl" | "full" }) {
  return (
    <Dialog open>
      <DialogContent size={size}>
        <DialogTitle>Test dialog</DialogTitle>
        <DialogDescription>Test description</DialogDescription>
        Content
      </DialogContent>
    </Dialog>
  );
}

describe("DialogContent size variants", () => {
  it("default (no size prop) renders max-w-lg — regression lock", () => {
    render(<Wrapper />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-lg");
  });

  it("size='lg' renders max-w-lg", () => {
    render(<Wrapper size="lg" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-lg");
  });

  it("size='sm' renders max-w-sm", () => {
    render(<Wrapper size="sm" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-sm");
  });

  it("size='xl' renders max-w-3xl", () => {
    render(<Wrapper size="xl" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-3xl");
  });

  it("size='full' renders max-w-[95vw] and h-[90vh]", () => {
    render(<Wrapper size="full" />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("max-w-[95vw]");
    expect(content.className).toContain("h-[90vh]");
  });
});

describe("DialogContent grid overflow guard (regression)", () => {
  // The grid that lays out DialogContent's children must use a
  // `minmax(0,1fr)` column, not the implicit `auto` column. Without the floor,
  // a grid item's default `min-width:auto` lets a `truncate`/`nowrap` child or a
  // long unbreakable token set the column's min-content size and push the dialog
  // past its `max-w-*`. jsdom can't measure layout, so this locks the class that
  // prevents it; the visual proof is the `OverflowGuard` Storybook story.
  it("renders a minmax(0,1fr) grid column so truncate children can shrink", () => {
    render(<Wrapper />);
    const content = screen.getByRole("dialog");
    expect(content.className).toContain("grid-cols-[minmax(0,1fr)]");
    expect(content.className).toContain("grid");
  });

  it("keeps the minmax column on every size variant", () => {
    for (const size of ["sm", "lg", "xl", "full"] as const) {
      const { unmount } = render(<Wrapper size={size} />);
      expect(screen.getByRole("dialog").className).toContain("grid-cols-[minmax(0,1fr)]");
      unmount();
    }
  });
});
