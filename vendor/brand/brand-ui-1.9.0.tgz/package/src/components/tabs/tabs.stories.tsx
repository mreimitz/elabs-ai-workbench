import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, waitFor } from "storybook/test";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";

const meta = {
  title: "Core/Tabs",
  component: Tabs,
  tags: ["autodocs"],
  argTypes: {
    defaultValue: {
      description: "Uncontrolled: the tab value active on first render.",
      control: "text",
      table: { category: "State" },
    },
    value: {
      description: "Controlled active tab value.",
      control: "text",
      table: { category: "State" },
    },
    onValueChange: {
      description: "Callback fired when the active tab changes.",
      control: false,
      table: { category: "Behavior" },
    },
    orientation: {
      description: "Layout orientation of the tab list.",
      control: { type: "radio" },
      options: ["horizontal", "vertical"],
      table: { category: "Appearance" },
    },
    activationMode: {
      description: "`automatic` activates on focus; `manual` requires an explicit click/Enter.",
      control: { type: "radio" },
      options: ["automatic", "manual"],
      table: { category: "Behavior" },
    },
    className: {
      description: "Extra Tailwind classes merged via cn().",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Tabs>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <Tabs defaultValue="overview" className="w-80">
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="activity">Activity</TabsTrigger>
        <TabsTrigger value="settings">Settings</TabsTrigger>
      </TabsList>
      <TabsContent value="overview" className="text-body text-muted-foreground">
        Overview panel.
      </TabsContent>
      <TabsContent value="activity" className="text-body text-muted-foreground">
        Activity panel.
      </TabsContent>
      <TabsContent value="settings" className="text-body text-muted-foreground">
        Settings panel.
      </TabsContent>
    </Tabs>
  ),
  // Selecting a tab reveals its panel and marks the trigger aria-selected — the
  // panel content is unmounted until its tab is active, so this proves the
  // switch actually happened.
  play: async ({ canvas, userEvent }) => {
    const activity = canvas.getByRole("tab", { name: "Activity" });
    await userEvent.click(activity);
    await expect(activity).toHaveAttribute("aria-selected", "true");
    // The panel mounts on switch and fades in (gated entrance) — wait for it to settle.
    const panel = await canvas.findByText("Activity panel.");
    await waitFor(() => expect(panel).toBeVisible());
  },
};
