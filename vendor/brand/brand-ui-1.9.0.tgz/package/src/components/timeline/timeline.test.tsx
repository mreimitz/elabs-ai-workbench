import { afterEach, describe, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

import { Timeline, TimelineItem, TimelineRoot } from "./timeline";

afterEach(cleanup);

describe("Timeline (array API — the editor-facing surface, #190)", () => {
  it("renders one list item per timeline step", () => {
    render(
      <Timeline
        items={[
          { title: "Draft", status: "done" },
          { title: "Review", status: "active", description: "in progress" },
          { title: "Publish", status: "pending" },
        ]}
      />,
    );
    expect(screen.getAllByRole("listitem")).toHaveLength(3);
    expect(screen.getByText("Review")).toBeInTheDocument();
    expect(screen.getByText("in progress")).toBeInTheDocument();
  });

  it("maps the editor 3-state vocabulary onto the canonical Status", () => {
    render(
      <Timeline
        items={[
          { title: "Draft", status: "done" },
          { title: "Review", status: "active" },
          { title: "Publish" }, // status omitted → pending
        ]}
      />,
    );
    const [done, active, pending] = screen.getAllByRole("listitem");
    expect(done).toHaveAttribute("data-status", "complete");
    expect(active).toHaveAttribute("data-status", "running");
    expect(pending).toHaveAttribute("data-status", "pending");
  });
});

describe("TimelineRoot/TimelineItem (compound API)", () => {
  it("composes items with canonical statuses and rich children", () => {
    render(
      <TimelineRoot data-testid="rail">
        <TimelineItem status="complete" timestamp="Jun 4">
          Searched filings
        </TimelineItem>
        <TimelineItem status="failed" description={<em>quota exceeded</em>}>
          Queried finance.revenue
        </TimelineItem>
      </TimelineRoot>,
    );
    expect(screen.getByTestId("rail").tagName).toBe("OL");
    const items = screen.getAllByRole("listitem");
    expect(items).toHaveLength(2);
    expect(items[0]).toHaveAttribute("data-status", "complete");
    expect(items[1]).toHaveAttribute("data-status", "failed");
    expect(screen.getByText("Jun 4")).toBeInTheDocument();
    expect(screen.getByText("quota exceeded")).toBeInTheDocument();
  });

  it("renders the block detail slot under the node (#192 AgentStep host)", () => {
    render(
      <TimelineRoot>
        <TimelineItem
          status="complete"
          detail={<div data-testid="detail">8 rows · 0 variances</div>}
        >
          Queried finance.revenue
        </TimelineItem>
      </TimelineRoot>,
    );
    expect(screen.getByTestId("detail")).toBeInTheDocument();
  });

  it("merges className and spreads props on the li", () => {
    render(
      <TimelineRoot>
        <TimelineItem className="custom-item" aria-label="step">
          Step
        </TimelineItem>
      </TimelineRoot>,
    );
    const li = screen.getByRole("listitem");
    expect(li).toHaveClass("custom-item");
    expect(li).toHaveAttribute("aria-label", "step");
  });
});
