"use client";

/**
 * Shipped English (en-US) default microcopy bundle.
 *
 * Keys are intentionally terse, semantic, and framework-agnostic so they
 * translate cleanly into any target locale. Keep this list small and real —
 * only add a key here when a component actually needs it.
 */
export const DEFAULT_MESSAGES: Record<string, string> = {
  close: "Close",
  previous: "Previous",
  next: "Next",
  previousSlide: "Previous slide",
  nextSlide: "Next slide",
  noResults: "No results.",
  noRows: "No rows.",
  loading: "Loading…",
  more: "More",
  selectAll: "Select all",
};
