import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { Alert, AlertTitle } from "./alert";
describe("Alert", () => {
  it("renders with role=alert and a title", () => {
    render(
      <Alert>
        <AlertTitle>Heads up</AlertTitle>
      </Alert>,
    );
    expect(screen.getByRole("alert")).toBeInTheDocument();
    expect(screen.getByText("Heads up")).toBeInTheDocument();
  });

  // role override seam (#191, research 11 §B.3): a pending decision with
  // focusable controls must be a labelled region, not an assertive live region.
  it("accepts a role override (default stays alert)", () => {
    render(
      <Alert aria-label="Pending decision" role="group">
        <AlertTitle>Approve this?</AlertTitle>
      </Alert>,
    );
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(screen.getByRole("group", { name: "Pending decision" })).toBeInTheDocument();
  });
});
