import type { Meta, StoryObj } from "@storybook/react-vite";
import { AlertTriangle, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "./alert";
const meta = {
  title: "States/Alert",
  component: Alert,
  tags: ["autodocs"],
  argTypes: {
    variant: {
      description: "Visual tone of the alert banner.",
      control: { type: "select" },
      options: ["default", "info", "success", "warning", "destructive"],
      table: { category: "Appearance" },
    },
    role: {
      description:
        'ARIA role. Use "alert" for assertive announcements or "group" for panels with focusable controls.',
      control: { type: "select" },
      options: ["alert", "group", "status"],
      table: { category: "Accessibility" },
    },
    className: {
      description: "Additional CSS classes applied to the alert container.",
      control: "text",
      table: { category: "Styling" },
    },
    children: {
      description: "Compose AlertTitle and AlertDescription inside.",
      control: false,
      table: { category: "Content" },
    },
  },
} satisfies Meta<typeof Alert>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Info_: Story = {
  name: "Info",
  render: () => (
    <Alert variant="info" className="max-w-md">
      <Info />
      <AlertTitle>Heads up</AlertTitle>
      <AlertDescription>This deploy includes a schema migration.</AlertDescription>
    </Alert>
  ),
};
export const Destructive: Story = {
  render: () => (
    <Alert variant="destructive" className="max-w-md">
      <AlertTriangle />
      <AlertTitle>Error</AlertTitle>
      <AlertDescription>Your session has expired.</AlertDescription>
    </Alert>
  ),
};
