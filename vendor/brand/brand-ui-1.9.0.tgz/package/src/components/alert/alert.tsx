import { forwardRef, type HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/cn";

export const alertVariants = cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm [&>svg]:absolute [&>svg]:start-4 [&>svg]:top-4 [&>svg]:size-4 [&>svg]:text-current [&>svg~*]:ps-7",
  {
    variants: {
      variant: {
        default: "bg-card text-card-foreground",
        info: "border-info/40 bg-info/10 text-foreground",
        success: "border-success/40 bg-success/10 text-foreground",
        warning: "border-warning/50 bg-warning/10 text-foreground",
        destructive:
          "border-destructive/40 bg-destructive/10 text-destructive [&>svg]:text-destructive",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export const Alert = forwardRef<
  HTMLDivElement,
  HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(function Alert(
  // `role` is an explicit override seam (default "alert"): a PENDING decision
  // containing focusable controls (e.g. @brand/ai ApprovalCard) must be a
  // labelled region (`role="group"` + aria-labelledby), not an assertive live
  // region (research/structural-design/11 §B.3).
  { className, variant, role = "alert", ...props },
  ref,
) {
  return (
    <div ref={ref} role={role} className={cn(alertVariants({ variant }), className)} {...props} />
  );
});

export const AlertTitle = forwardRef<HTMLParagraphElement, HTMLAttributes<HTMLHeadingElement>>(
  function AlertTitle({ className, ...props }, ref) {
    return (
      <h5
        ref={ref}
        className={cn("mb-1 font-medium leading-none tracking-tight", className)}
        {...props}
      />
    );
  },
);

export const AlertDescription = forwardRef<
  HTMLParagraphElement,
  HTMLAttributes<HTMLParagraphElement>
>(function AlertDescription({ className, ...props }, ref) {
  return (
    <div
      ref={ref}
      className={cn("text-sm [&_p]:leading-relaxed text-muted-foreground", className)}
      {...props}
    />
  );
});
