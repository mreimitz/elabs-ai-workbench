import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { Combobox } from "./combobox";
describe("Combobox", () => {
  it("renders the placeholder on the trigger", () => {
    render(<Combobox options={[{ label: "A", value: "a" }]} placeholder="Pick one" />);
    // The trigger uses role="combobox"; that ARIA role does not take its
    // accessible name from text content, so assert the visible placeholder text.
    expect(screen.getByText("Pick one")).toBeInTheDocument();
  });
});
