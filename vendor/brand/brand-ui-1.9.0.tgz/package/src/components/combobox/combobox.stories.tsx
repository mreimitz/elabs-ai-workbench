import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, within } from "storybook/test";
import { Combobox } from "./combobox";
const meta = {
  title: "Forms/Combobox",
  component: Combobox,
  tags: ["autodocs"],
  argTypes: {
    options: {
      description: "Array of `{ label, value }` options.",
      control: false,
      table: { category: "Content" },
    },
    value: {
      description: "Controlled selected value.",
      control: "text",
      table: { category: "State" },
    },
    placeholder: {
      description: "Text shown in the trigger when no option is selected.",
      control: "text",
      table: { category: "Content" },
    },
    searchPlaceholder: {
      description: "Placeholder inside the search input.",
      control: "text",
      table: { category: "Content" },
    },
    emptyText: {
      description: "Message shown when the search yields no results.",
      control: "text",
      table: { category: "Content" },
    },
    onValueChange: {
      description: "Called when the selected value changes.",
      control: false,
      table: { category: "Behavior" },
    },
    className: {
      description: "Additional CSS classes applied to the trigger button.",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Combobox>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  args: {
    options: [
      { label: "Production", value: "prod" },
      { label: "Staging", value: "staging" },
      { label: "Development", value: "dev" },
    ],
    placeholder: "Select environment…",
  },
  // Opens the popover, confirms options appear, then picks "Staging".
  play: async ({ canvas, canvasElement, userEvent }) => {
    const trigger = canvas.getByRole("combobox");
    await userEvent.click(trigger);
    const body = within(canvasElement.ownerDocument.body);
    const option = await body.findByRole("option", { name: "Staging" });
    await expect(option).toBeInTheDocument();
    await userEvent.click(option);
    await expect(trigger).toHaveTextContent("Staging");
  },
};
