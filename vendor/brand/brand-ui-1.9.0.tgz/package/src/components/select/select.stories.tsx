import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, within } from "storybook/test";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
const meta = { title: "Forms/Select", component: Select, tags: ["autodocs"] } satisfies Meta<
  typeof Select
>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Select defaultValue="prod">
      <SelectTrigger className="w-56">
        <SelectValue placeholder="Environment" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="prod">Production</SelectItem>
        <SelectItem value="staging">Staging</SelectItem>
        <SelectItem value="dev">Dev</SelectItem>
      </SelectContent>
    </Select>
  ),
  // Opens the listbox (Radix portal), picks a different option, and confirms the
  // trigger now reflects the new selection.
  play: async ({ canvas, canvasElement, userEvent }) => {
    const trigger = canvas.getByRole("combobox");
    await expect(trigger).toHaveTextContent("Production");
    await userEvent.click(trigger);
    const body = within(canvasElement.ownerDocument.body);
    await userEvent.click(await body.findByRole("option", { name: "Staging" }));
    await expect(trigger).toHaveTextContent("Staging");
  },
};
