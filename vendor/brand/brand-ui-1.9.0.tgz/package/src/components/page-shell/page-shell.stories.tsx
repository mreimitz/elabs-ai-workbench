import type { Meta, StoryObj } from "@storybook/react-vite";
import { PageShell } from "./page-shell";
import { SectionHeader } from "../section-header";

const meta = {
  title: "Layout/PageShell",
  component: PageShell,
  parameters: { layout: "fullscreen" },
} satisfies Meta<typeof PageShell>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <PageShell header={<SectionHeader title="Settings" description="Manage your workspace." />}>
      <div className="rounded-xl border bg-card p-6 text-body text-muted-foreground">Content</div>
    </PageShell>
  ),
};
