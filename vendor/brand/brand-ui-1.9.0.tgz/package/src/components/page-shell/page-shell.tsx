import { type ReactNode } from "react";
import { cn } from "../../lib/cn";

export interface PageShellProps {
  children: ReactNode;
  /** Optional header row (often a <SectionHeader />). */
  header?: ReactNode;
  /** Constrain content width. Defaults to "xl". */
  width?: "md" | "lg" | "xl" | "full";
  className?: string;
  contentClassName?: string;
}

const widthMap = {
  md: "max-w-3xl",
  lg: "max-w-5xl",
  xl: "max-w-7xl",
  full: "max-w-none",
} as const;

/** Page-level content container with consistent padding and max width. */
export function PageShell({
  children,
  header,
  width = "xl",
  className,
  contentClassName,
}: PageShellProps) {
  return (
    <div className={cn("w-full px-4 py-6 sm:px-6 lg:px-8", className)}>
      <div className={cn("mx-auto w-full space-y-6", widthMap[width], contentClassName)}>
        {header}
        {children}
      </div>
    </div>
  );
}
