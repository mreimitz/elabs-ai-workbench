import type { Meta, StoryObj } from "@storybook/react-vite";
import { Progress } from "./progress";
const meta = {
  title: "Display/Progress",
  component: Progress,
  tags: ["autodocs"],
  argTypes: {
    value: {
      description: "Current progress value (0–100). `null` / undefined = indeterminate.",
      control: "number",
      table: { category: "State" },
    },
    max: {
      description: "Maximum value; defaults to 100.",
      control: "number",
      table: { category: "Behavior" },
    },
    className: {
      description: "Extra Tailwind classes merged via cn() on the track.",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Progress>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = { render: () => <Progress value={62} className="w-64" /> };
export const Full: Story = { render: () => <Progress value={100} className="w-64" /> };
export const Empty: Story = { render: () => <Progress value={0} className="w-64" /> };
