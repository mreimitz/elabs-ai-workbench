import { useEffect, useState } from "react";
import { Toaster as SonnerToaster, toast } from "sonner";
import { THEME_META, type ThemeName } from "@brand/tokens";

export type ToasterProps = React.ComponentProps<typeof SonnerToaster>;

/** Reads the active theme from the document `data-theme` attribute. */
function useDocumentThemeMode(): "light" | "dark" {
  const [mode, setMode] = useState<"light" | "dark">("light");
  useEffect(() => {
    if (typeof document === "undefined") return;
    const el = document.documentElement;
    const read = () => {
      const t = el.getAttribute("data-theme") as ThemeName | null;
      setMode(t && THEME_META[t]?.dark ? "dark" : "light");
    };
    read();
    const obs = new MutationObserver(read);
    obs.observe(el, { attributes: true, attributeFilter: ["data-theme"] });
    return () => obs.disconnect();
  }, []);
  return mode;
}

/**
 * Toast host. Mount once near the app root. Trigger toasts with the exported
 * `toast()`. Theme follows the active brand theme (via `data-theme`), so it
 * works with or without <ThemeProvider>.
 */
export function Toaster(props: ToasterProps) {
  const mode = useDocumentThemeMode();
  return (
    <SonnerToaster
      theme={mode}
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-card group-[.toaster]:text-card-foreground group-[.toaster]:border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
}

export { toast };
