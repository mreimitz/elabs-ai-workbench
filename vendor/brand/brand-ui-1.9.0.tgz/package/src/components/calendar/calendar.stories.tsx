import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect } from "storybook/test";
import { Calendar } from "./calendar";
const meta = {
  title: "Forms/Calendar",
  component: Calendar,
  tags: ["autodocs"],
  argTypes: {
    mode: {
      description: "Selection mode: single date, multiple dates, or a range.",
      control: { type: "select" },
      options: ["single", "multiple", "range"],
      table: { category: "Behavior" },
    },
    showOutsideDays: {
      description: "Show days from adjacent months in the current month grid.",
      control: "boolean",
      table: { category: "Appearance" },
    },
    numberOfMonths: {
      description: "Number of months to display side by side.",
      control: "number",
      table: { category: "Appearance" },
    },
    disabled: {
      description: "Disables specific dates (Matcher or boolean).",
      control: false,
      table: { category: "State" },
    },
    selected: {
      description: "Controlled selected date(s).",
      control: false,
      table: { category: "State" },
    },
    onSelect: {
      description: "Called when the user picks a date.",
      control: false,
      table: { category: "Behavior" },
    },
    className: {
      description: "Additional CSS classes applied to the root element.",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Calendar>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [date, setDate] = useState<Date | undefined>(new Date());
    return (
      <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
    );
  },
  // Confirms the calendar grid renders and a day cell is present.
  play: async ({ canvas }) => {
    const grid = canvas.getByRole("grid");
    await expect(grid).toBeInTheDocument();
    const dayCells = canvas.getAllByRole("gridcell");
    await expect(dayCells.length).toBeGreaterThan(0);
  },
};
