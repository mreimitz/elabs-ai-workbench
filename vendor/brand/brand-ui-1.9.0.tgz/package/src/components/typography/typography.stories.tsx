import type { Meta, StoryObj } from "@storybook/react-vite";
import { Heading, Text } from "./typography";
import {
  ProseBlockquote,
  ProseHeading,
  ProseInlineCode,
  ProseLink,
  ProseList,
  ProseListItem,
  ProseText,
} from "./prose";

const meta = {
  title: "Foundations/Typography",
  component: Text,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "The semantic type-role API (#187/#188): `Heading` maps a level to the " +
          "display/title/subtitle rungs; `Text` maps intent (lead/body/caption/meta/kpi/code) " +
          "to a role. Roles bundle size + leading + weight + tracking and stay composable. " +
          "`Prose*` primitives carry the reading-column scale the markdown preview maps onto.",
      },
    },
  },
} satisfies Meta<typeof Text>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { children: "Body text — the default role (text-body == text-sm by design)." },
};

export const TextVariants: Story = {
  render: () => (
    <div className="max-w-2xl space-y-3">
      <Text variant="lead">Lead — a lead paragraph: the subtitle rung at body weight.</Text>
      <Text variant="body">Body — default reading text for app surfaces.</Text>
      <Text variant="caption">Caption — secondary / supporting body.</Text>
      <Text variant="meta">Meta — metadata, eyebrows, timestamps.</Text>
      <Text variant="kpi">12,480</Text>
      <Text variant="code">pnpm --filter @brand/ui test</Text>
    </div>
  ),
};

export const Tones: Story = {
  render: () => (
    <div className="space-y-2">
      <Text tone="default">Default tone — foreground.</Text>
      <Text tone="muted">Muted tone — secondary information.</Text>
      <Text tone="primary">Primary tone — brand emphasis.</Text>
    </div>
  ),
};

export const Headings: Story = {
  render: () => (
    <div className="space-y-3">
      <Heading level={1}>Level 1 — display</Heading>
      <Heading level={2}>Level 2 — title</Heading>
      <Heading level={3}>Level 3 — title</Heading>
      <Heading level={4}>Level 4 — subtitle</Heading>
      <Heading level={5}>Level 5 — subtitle</Heading>
      <Heading level={6}>Level 6 — subtitle</Heading>
    </div>
  ),
};

export const HeadingSizeOverride: Story = {
  render: () => (
    <div className="space-y-3">
      <Heading level={2} size="display">
        An h2 that reads as display
      </Heading>
      <Heading level={2} size="subtitle">
        An h2 that reads as subtitle — the tag keeps the document outline
      </Heading>
    </div>
  ),
};

export const AsAndAsChild: Story = {
  render: () => (
    <div className="space-y-3">
      <Text as="span" variant="meta" tone="muted">
        Rendered as a span
      </Text>
      <Heading level={2} asChild>
        <a href="#typography">A heading that is a link (asChild)</a>
      </Heading>
    </div>
  ),
};

export const Prose: Story = {
  render: () => (
    <div className="max-w-2xl space-y-3">
      <ProseHeading level={1}>Prose heading level 1</ProseHeading>
      <ProseHeading level={2}>Prose heading level 2</ProseHeading>
      <ProseHeading level={3}>Prose heading level 3</ProseHeading>
      <ProseText>
        Body text with an <ProseLink href="https://example.com">external link</ProseLink> and some{" "}
        <ProseInlineCode>inline code</ProseInlineCode>.
      </ProseText>
      <ProseText variant="muted">Muted helper text.</ProseText>
      <ProseBlockquote>A blockquote rendered through the branded primitive.</ProseBlockquote>
      <ProseList>
        <ProseListItem>First bullet</ProseListItem>
        <ProseListItem>Second bullet</ProseListItem>
      </ProseList>
      <ProseList ordered>
        <ProseListItem>First step</ProseListItem>
        <ProseListItem>Second step</ProseListItem>
      </ProseList>
    </div>
  ),
};
