import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Checkbox } from "./checkbox";
describe("Checkbox", () => {
  it("toggles checked state", async () => {
    render(<Checkbox aria-label="c" />);
    const box = screen.getByRole("checkbox", { name: "c" });
    expect(box).toHaveAttribute("data-state", "unchecked");
    await userEvent.click(box);
    expect(box).toHaveAttribute("data-state", "checked");
  });
});
