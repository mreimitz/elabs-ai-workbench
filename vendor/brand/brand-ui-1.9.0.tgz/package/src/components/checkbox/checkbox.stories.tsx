import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect } from "storybook/test";
import { Checkbox } from "./checkbox";
import { Label } from "../label";
const meta = {
  title: "Forms/Checkbox",
  component: Checkbox,
  tags: ["autodocs"],
  argTypes: {
    checked: {
      description: 'Controlled checked state. Use `"indeterminate"` for mixed state.',
      control: { type: "select" },
      options: [true, false, "indeterminate"],
      table: { category: "State" },
    },
    defaultChecked: {
      description: "Uncontrolled initial checked state.",
      control: "boolean",
      table: { category: "State" },
    },
    disabled: {
      description: "Disables the checkbox.",
      control: "boolean",
      table: { category: "State" },
    },
    required: {
      description: "Marks the checkbox as required in a form context.",
      control: "boolean",
      table: { category: "Behavior" },
    },
    onCheckedChange: {
      description: "Called when the checked state changes.",
      control: false,
      table: { category: "Behavior" },
    },
    className: {
      description: "Additional CSS classes applied to the root element.",
      control: "text",
      table: { category: "Appearance" },
    },
  },
} satisfies Meta<typeof Checkbox>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <div className="flex items-center gap-2">
      <Checkbox id="terms" defaultChecked />
      <Label htmlFor="terms">Accept terms</Label>
    </div>
  ),
  // Starts checked (defaultChecked); clicking toggles the reflected aria-checked state.
  play: async ({ canvas, userEvent }) => {
    const box = canvas.getByRole("checkbox");
    await expect(box).toHaveAttribute("aria-checked", "true");
    await userEvent.click(box);
    await expect(box).toHaveAttribute("aria-checked", "false");
  },
};
