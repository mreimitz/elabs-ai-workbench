"use client";

import type { ReactNode } from "react";
import { useChartFormatters } from "../chart-formatters";

export interface TooltipRow {
  color: string;
  label: string;
  value: string | number;
}

export interface ChartTooltipContentProps {
  title?: string;
  rows: TooltipRow[];
  /** Optional additional content (e.g., markers) */
  children?: ReactNode;
}

export function ChartTooltipContent({ title, rows, children }: ChartTooltipContentProps) {
  // Locale-aware number formatting (ADR-0014): honors a `LocaleProvider` locale,
  // falling back to the host default when no provider is mounted.
  const { intFmt } = useChartFormatters();
  return (
    <div className="overflow-hidden">
      <div className="px-3 py-2.5">
        {title && (
          <div className="mb-2 font-medium text-chart-tooltip-foreground text-xs">{title}</div>
        )}
        <div className="space-y-1.5">
          {rows.map((row) => (
            <div
              className="flex items-center justify-between gap-4"
              key={`${row.label}-${row.color}`}
            >
              <div className="flex items-center gap-2">
                <span
                  className="h-2.5 w-2.5 shrink-0 rounded-full"
                  style={{ backgroundColor: row.color }}
                />
                <span className="text-chart-tooltip-muted text-sm">{row.label}</span>
              </div>
              <span className="font-medium text-chart-tooltip-foreground text-sm tabular-nums">
                {typeof row.value === "number" ? intFmt(row.value) : row.value}
              </span>
            </div>
          ))}
        </div>

        {children && (
          <div className="mt-2 transition-opacity duration-base ease-standard motion-reduce:transition-none">
            {children}
          </div>
        )}
      </div>
    </div>
  );
}

ChartTooltipContent.displayName = "ChartTooltipContent";

export default ChartTooltipContent;
