import { cleanup, render } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

// @visx/responsive uses ResizeObserver + real DOM measurement which jsdom lacks.
// Mock ParentSize to supply a fixed 560×288 viewport so ChartInner renders.
// Real render/interaction/a11y is covered by the Storybook build (Charts/BarChart story).
vi.mock("@visx/responsive", () => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports -- vi.mock factory is hoisted; lazy require avoids TDZ
  const React = require("react");
  return {
    ParentSize: ({
      children,
    }: {
      children: (size: { width: number; height: number }) => React.ReactNode;
    }) =>
      React.createElement(
        "div",
        { "data-testid": "parent-size" },
        children({ width: 560, height: 288 }),
      ),
  };
});

import { Bar } from "./bar";
import { BarChart } from "./bar-chart";
import { Grid } from "./grid";

const minimalData = [
  { month: "Jan", value: 100 },
  { month: "Feb", value: 200 },
  { month: "Mar", value: 150 },
];

afterEach(cleanup);

describe("BarChart", () => {
  it("is exported as a function (forwardRef wrapper)", () => {
    expect(typeof BarChart).toBe("object"); // forwardRef returns an exotic object, not a plain function
    expect(BarChart.displayName).toBe("BarChart");
  });

  it("mounts without throwing and attaches a container div to the document", () => {
    const { container } = render(
      <BarChart data={minimalData} xDataKey="month">
        <Bar dataKey="value" fill="var(--chart-1)" />
      </BarChart>,
    );
    // The root element rendered by BarChart is a div
    const root = container.firstChild as HTMLElement;
    expect(root).toBeInTheDocument();
    expect(root.tagName).toBe("DIV");
  });

  it("applies a custom className to the container", () => {
    const { container } = render(
      <BarChart data={minimalData} xDataKey="month" className="my-bar-chart">
        <Bar dataKey="value" fill="var(--chart-1)" />
      </BarChart>,
    );
    const root = container.firstChild as HTMLElement;
    expect(root).toHaveClass("my-bar-chart");
  });

  it("forwards a ref to the container div", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(
      <BarChart data={minimalData} xDataKey="month" ref={ref}>
        <Bar dataKey="value" fill="var(--chart-1)" />
      </BarChart>,
    );
    expect(ref.current).not.toBeNull();
    expect(ref.current?.tagName).toBe("DIV");
  });

  it("renders a Grid child without throwing", () => {
    expect(() =>
      render(
        <BarChart data={minimalData} xDataKey="month">
          <Grid horizontal />
          <Bar dataKey="value" fill="var(--chart-1)" />
        </BarChart>,
      ),
    ).not.toThrow();
  });
});
