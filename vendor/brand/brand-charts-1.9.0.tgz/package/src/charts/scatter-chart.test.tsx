import { cleanup, render } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

// react-use-measure uses ResizeObserver for layout measurement, which jsdom
// does not implement. Mock it to return a fixed size so the chart's inner
// render gate (width > 0 && height > 0) is satisfied.
// Real render + a11y are covered by the Storybook interaction tests.
vi.mock("react-use-measure", () => ({
  default: () => [() => undefined, { width: 560, height: 288 }],
}));

import { ScatterChart, Scatter } from "./scatter-chart";

afterEach(cleanup);

const chartData = [
  { date: new Date("2024-01-01"), sessions: 420, conversions: 28 },
  { date: new Date("2024-02-01"), sessions: 510, conversions: 34 },
  { date: new Date("2024-03-01"), sessions: 390, conversions: 22 },
];

describe("ScatterChart", () => {
  it("is exported as a function / forwardRef component", () => {
    expect(typeof ScatterChart).toBe("object"); // forwardRef returns an object
    expect(ScatterChart.displayName).toBe("ScatterChart");
  });

  it("mounts without throwing and attaches to the document", () => {
    const { container } = render(
      <ScatterChart data={chartData}>
        <Scatter dataKey="sessions" />
      </ScatterChart>,
    );
    expect(container.firstChild).toBeInTheDocument();
  });

  it("applies a custom className to the container", () => {
    const { container } = render(
      <ScatterChart data={chartData} className="my-chart">
        <Scatter dataKey="sessions" />
      </ScatterChart>,
    );
    expect(container.firstChild).toHaveClass("my-chart");
  });

  it("forwards a ref to the container div", () => {
    let capturedRef: HTMLDivElement | null = null;
    render(
      <ScatterChart
        data={chartData}
        ref={(el) => {
          capturedRef = el;
        }}
      >
        <Scatter dataKey="sessions" />
      </ScatterChart>,
    );
    expect(capturedRef).toBeInstanceOf(HTMLDivElement);
  });

  it("adds role/aria-label/tabIndex when accessibleLabel is provided", () => {
    const { container } = render(
      <ScatterChart
        data={chartData}
        accessibleLabel="Sessions vs conversions scatter chart"
        accessibleDescription="Series: Sessions (390–510), Conversions (22–34)."
      >
        <Scatter dataKey="sessions" />
      </ScatterChart>,
    );
    const root = container.firstChild as HTMLElement;
    expect(root.getAttribute("role")).toBe("figure");
    expect(root.getAttribute("aria-label")).toBe("Sessions vs conversions scatter chart");
    expect(root.getAttribute("tabindex")).toBe("0");
    const descSpan = root.querySelector("span.sr-only");
    expect(descSpan).toBeInTheDocument();
  });

  it("does NOT add role/aria-label when accessibleLabel is absent", () => {
    const { container } = render(
      <ScatterChart data={chartData}>
        <Scatter dataKey="sessions" />
      </ScatterChart>,
    );
    const root = container.firstChild as HTMLElement;
    expect(root.getAttribute("role")).toBeNull();
    expect(root.getAttribute("aria-label")).toBeNull();
  });
});
