import type { Meta, StoryObj } from "@storybook/react-vite";
import { curveNatural } from "@visx/curve";
import { ChartTooltip } from "./tooltip";
import { Grid } from "./grid";
import { XAxis } from "./x-axis";
import { Line } from "./line";
import { LineChart } from "./line-chart";

const meta = {
  title: "Charts/LineChart",
  component: LineChart,
  tags: ["autodocs"],
} satisfies Meta<typeof LineChart>;

export default meta;
type Story = StoryObj<typeof meta>;

const chartData = [
  { date: new Date("2024-01-01"), users: 1200, sessions: 3400 },
  { date: new Date("2024-02-01"), users: 1350, sessions: 3800 },
  { date: new Date("2024-03-01"), users: 1100, sessions: 3100 },
  { date: new Date("2024-04-01"), users: 1450, sessions: 4100 },
  { date: new Date("2024-05-01"), users: 1380, sessions: 3900 },
  { date: new Date("2024-06-01"), users: 1520, sessions: 4300 },
];

export const Default: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <LineChart data={chartData} aspectRatio={undefined}>
        <Grid horizontal />
        <Line dataKey="users" curve={curveNatural} stroke="var(--chart-1)" />
        <XAxis />
        <ChartTooltip />
      </LineChart>
    </div>
  ),
};

export const MultiSeries: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <LineChart data={chartData} aspectRatio={undefined}>
        <Grid horizontal />
        <Line dataKey="users" curve={curveNatural} stroke="var(--chart-1)" />
        <Line dataKey="sessions" curve={curveNatural} stroke="var(--chart-2)" />
        <XAxis />
        <ChartTooltip />
      </LineChart>
    </div>
  ),
};

export const Loading: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <LineChart
        data={chartData}
        status="loading"
        loadingLabel="Loading data…"
        aspectRatio={undefined}
      >
        <Grid horizontal />
        <Line dataKey="users" curve={curveNatural} stroke="var(--chart-1)" />
        <XAxis />
        <ChartTooltip />
      </LineChart>
    </div>
  ),
};
