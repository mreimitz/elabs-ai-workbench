import type { Meta, StoryObj } from "@storybook/react-vite";
import { Bar } from "./bar";
import { BarChart } from "./bar-chart";
import { BarXAxis } from "./bar-x-axis";
import { ChartTooltip } from "./tooltip";
import { Grid } from "./grid";

const meta = {
  title: "Charts/BarChart",
  component: BarChart,
  tags: ["autodocs"],
} satisfies Meta<typeof BarChart>;

export default meta;
type Story = StoryObj<typeof meta>;

// Realistic monthly revenue / profit data (adapted from the bklit example)
const monthlyData = [
  { month: "Jan", revenue: 12000, profit: 4500 },
  { month: "Feb", revenue: 15500, profit: 5200 },
  { month: "Mar", revenue: 11000, profit: 3800 },
  { month: "Apr", revenue: 18500, profit: 7100 },
  { month: "May", revenue: 16800, profit: 5400 },
  { month: "Jun", revenue: 21200, profit: 8800 },
];

/** Default grouped bar chart with two series and a tooltip. */
export const Default: Story = {
  render: () => (
    // Charts require a concrete height; w-[560px] h-72 gives a comfortable 560×288 canvas.
    <div className="h-72 w-[560px]">
      <BarChart data={monthlyData} xDataKey="month">
        <Grid horizontal />
        <Bar dataKey="revenue" fill="var(--chart-1)" lineCap="round" />
        <Bar dataKey="profit" fill="var(--chart-2)" lineCap="round" />
        <BarXAxis />
        <ChartTooltip />
      </BarChart>
    </div>
  ),
};

/** Single-series bar chart — simplest usage. */
export const SingleSeries: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <BarChart data={monthlyData} xDataKey="month">
        <Grid horizontal />
        <Bar dataKey="revenue" fill="var(--chart-1)" lineCap="round" />
        <BarXAxis />
        <ChartTooltip />
      </BarChart>
    </div>
  ),
};

/** Stacked bar chart — segments are stacked on the same bar. */
export const Stacked: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <BarChart data={monthlyData} xDataKey="month" stacked>
        <Grid horizontal />
        <Bar dataKey="revenue" fill="var(--chart-1)" lineCap="round" />
        <Bar dataKey="profit" fill="var(--chart-2)" lineCap="round" />
        <BarXAxis />
        <ChartTooltip />
      </BarChart>
    </div>
  ),
};

/** Horizontal orientation — bars grow left-to-right. */
export const Horizontal: Story = {
  render: () => (
    <div className="h-72 w-[560px]">
      <BarChart data={monthlyData} xDataKey="month" orientation="horizontal">
        <Grid vertical />
        <Bar dataKey="revenue" fill="var(--chart-3)" lineCap="round" />
        <Bar dataKey="profit" fill="var(--chart-4)" lineCap="round" />
        <ChartTooltip />
      </BarChart>
    </div>
  ),
};
