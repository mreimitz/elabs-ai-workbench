import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { MetricGrid } from "./metric-grid";

describe("MetricGrid", () => {
  it("renders children", () => {
    render(
      <MetricGrid>
        <div>Tile A</div>
        <div>Tile B</div>
      </MetricGrid>,
    );
    expect(screen.getByText("Tile A")).toBeInTheDocument();
    expect(screen.getByText("Tile B")).toBeInTheDocument();
  });

  it("defaults to a grid wrapper (no reveal)", () => {
    render(
      <MetricGrid>
        <div data-testid="child">child</div>
      </MetricGrid>,
    );
    const child = screen.getByTestId("child");
    // The grid div is the direct parent of children when reveal=false
    expect(child.parentElement?.tagName).toBe("DIV");
  });

  it("applies custom className", () => {
    render(
      <MetricGrid className="custom-class">
        <div>item</div>
      </MetricGrid>,
    );
    expect(screen.getByText("item").parentElement).toHaveClass("custom-class");
  });

  // featured axis (#191, research 11 §B.5 KPI-2): one tile spans wider, no
  // wrapper element — the span class lands on the tile itself.
  it("spans the featured tile without adding a wrapper element", () => {
    render(
      <MetricGrid featured={0}>
        <div data-testid="first">Tile A</div>
        <div data-testid="second">Tile B</div>
      </MetricGrid>,
    );
    expect(screen.getByTestId("first")).toHaveClass("sm:col-span-2");
    expect(screen.getByTestId("second")).not.toHaveClass("sm:col-span-2");
    expect(screen.getByTestId("first").parentElement).toHaveClass("grid");
  });

  it("caps the featured span at the grid's column count", () => {
    render(
      <MetricGrid columns={2} featured={1} featuredSpan={3}>
        <div>Tile A</div>
        <div data-testid="featured">Tile B</div>
      </MetricGrid>,
    );
    const featured = screen.getByTestId("featured");
    expect(featured).toHaveClass("sm:col-span-2");
    expect(featured.className).not.toContain("lg:col-span-3");
  });
});
