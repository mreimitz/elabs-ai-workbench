import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react";
import { RevealGroup } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";

export interface MetricGridProps {
  children: ReactNode;
  /** Target columns at the largest breakpoint. Defaults to 4. */
  columns?: 2 | 3 | 4;
  /** Stagger the tiles in on mount. Motion-gated. Defaults to false (dashboards opt in). */
  reveal?: boolean;
  /**
   * Index of the tile that spans wider (research 11 §B.5 KPI-2) — pairs with
   * `<MetricCard emphasis="headline">` so the headline KPI out-ranks the band.
   */
  featured?: number;
  /** Columns the featured tile spans at the larger breakpoints. Defaults to 2. */
  featuredSpan?: 2 | 3;
  className?: string;
}

const colsMap = {
  2: "sm:grid-cols-2",
  3: "sm:grid-cols-2 lg:grid-cols-3",
  4: "sm:grid-cols-2 lg:grid-cols-4",
} as const;

// `sm` caps at 2 tracks (colsMap), so a span of 3 only widens further at `lg`.
const spanMap = {
  2: "sm:col-span-2",
  3: "sm:col-span-2 lg:col-span-3",
} as const;

type SpannableChild = ReactElement<{ className?: string }>;

/** Responsive grid for a row of <MetricCard />s. */
export function MetricGrid({
  children,
  columns = 4,
  reveal = false,
  featured,
  featuredSpan = 2,
  className,
}: MetricGridProps) {
  const gridClassName = cn("grid grid-cols-1 gap-4", colsMap[columns], className);

  // Clone (no wrapper element — same approach as RevealGroup) so the featured
  // tile stays a direct grid child and the span class lands on the tile itself.
  const items =
    featured === undefined
      ? children
      : Children.map(children, (child, index) => {
          if (index !== featured || !isValidElement<{ className?: string }>(child)) {
            return child;
          }
          const el = child as SpannableChild;
          return cloneElement(el, {
            className: cn(el.props.className, spanMap[Math.min(featuredSpan, columns) as 2 | 3]),
          });
        });

  if (reveal) {
    return (
      <RevealGroup appear="up" speed="base" staggerMs={60} className={gridClassName}>
        {items}
      </RevealGroup>
    );
  }

  return <div className={gridClassName}>{items}</div>;
}
