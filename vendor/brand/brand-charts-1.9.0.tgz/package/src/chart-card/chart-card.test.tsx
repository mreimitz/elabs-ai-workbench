import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { ChartCard } from "./chart-card";

describe("ChartCard", () => {
  it("renders the title and child chart", () => {
    render(
      <ChartCard title="Monthly Revenue">
        <div>chart</div>
      </ChartCard>,
    );
    expect(screen.getByText("Monthly Revenue")).toBeInTheDocument();
    expect(screen.getByText("chart")).toBeInTheDocument();
  });

  it("renders an optional description", () => {
    render(
      <ChartCard title="Sessions" description="Last 30 days">
        <div>chart</div>
      </ChartCard>,
    );
    expect(screen.getByText("Last 30 days")).toBeInTheDocument();
  });

  it("renders optional actions", () => {
    render(
      <ChartCard title="Conversions" actions={<button>Filter</button>}>
        <div>chart</div>
      </ChartCard>,
    );
    expect(screen.getByRole("button", { name: "Filter" })).toBeInTheDocument();
  });

  it("renders children inside a sized container", () => {
    render(
      <ChartCard title="KPI" height={320}>
        <div data-testid="chart-content">chart</div>
      </ChartCard>,
    );
    const content = screen.getByTestId("chart-content");
    // The sizing wrapper is the direct parent
    const wrapper = content.parentElement;
    expect(wrapper).toBeTruthy();
    expect(wrapper?.style.height).toBe("320px");
  });
});
