"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  DEFAULT_DENSITY,
  DEFAULT_MOTION_PREFERENCE,
  DEFAULT_THEME,
  isDecorationLevel,
  isDensity,
  isMotionPreference,
  isThemeName,
  THEME_META,
  THEMES,
  type DecorationLevel,
  type DensityMode,
  type MotionPreference,
  type ThemeName,
} from "./theme-types";

interface ThemeContextValue {
  /** The active theme. */
  theme: ThemeName;
  /** All available theme names. */
  themes: readonly ThemeName[];
  /** Set the active theme. */
  setTheme: (theme: ThemeName) => void;
  /** The user's motion preference (over the OS setting and theme default). */
  motionPreference: MotionPreference;
  /** Set the motion preference. */
  setMotionPreference: (preference: MotionPreference) => void;
  /** Whether the OS currently requests reduced motion (live, via matchMedia). */
  prefersReducedMotion: boolean;
  /** Decoration dial override (0–10), or null = follow the active theme's default. */
  decoration: DecorationLevel | null;
  /** The EFFECTIVE decoration level in effect (override ?? theme default ?? 0). */
  effectiveDecoration: DecorationLevel;
  /** Set the decoration override (null = follow the theme default). */
  setDecoration: (level: DecorationLevel | null) => void;
  /** Active density mode. "comfortable" is the identity (Tailwind default). */
  density: DensityMode;
  /** Set the density mode. */
  setDensity: (mode: DensityMode) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

export interface ThemeProviderProps {
  children: ReactNode;
  /** Initial theme when nothing is persisted. Defaults to "qlik-bright". */
  defaultTheme?: ThemeName;
  /** localStorage key used to persist the theme. Set `null` to disable. */
  storageKey?: string | null;
  /**
   * Initial motion preference when nothing is persisted. Defaults to "system".
   * Keep this "system" for zero-flash SSR: "system" writes no attribute, so the
   * first paint is governed purely by the OS `prefers-reduced-motion` media query.
   */
  defaultMotionPreference?: MotionPreference;
  /** localStorage key used to persist the motion preference. Set `null` to disable. */
  motionStorageKey?: string | null;
  /**
   * Initial decoration override when nothing is persisted. `null` (default) =
   * follow the active theme's own level (blueprint = 10, others = 0), writing no
   * attribute for zero-flash SSR.
   */
  defaultDecoration?: DecorationLevel | null;
  /** localStorage key used to persist the decoration override. Set `null` to disable. */
  decorationStorageKey?: string | null;
  /**
   * Initial density when nothing is persisted. Defaults to "comfortable"
   * (identity — the attribute is omitted so the first paint is unchanged).
   */
  defaultDensity?: DensityMode;
  /** localStorage key used to persist the density mode. Set `null` to disable. */
  densityStorageKey?: string | null;
  /**
   * Element that receives the `data-theme` and `data-motion-pref` attributes.
   * Defaults to the document root (`<html>`). Pass a ref'd element for scoped
   * theming. NOTE: the OS-reduce backstop in themes.css is keyed off `:root`, so
   * a scoped target still honors per-instance theme/motion but the document-level
   * backstop continues to track the document root.
   */
  attributeTarget?: HTMLElement | null;
}

function applyTheme(theme: ThemeName, target: HTMLElement | null) {
  const el = target ?? (typeof document !== "undefined" ? document.documentElement : null);
  if (el) el.setAttribute("data-theme", theme);
}

function applyMotionPreference(preference: MotionPreference, target: HTMLElement | null) {
  const el = target ?? (typeof document !== "undefined" ? document.documentElement : null);
  if (!el) return;
  // "system" defers to the OS media query — remove the attribute entirely.
  if (preference === "system") el.removeAttribute("data-motion-pref");
  else el.setAttribute("data-motion-pref", preference);
}

function applyDecoration(level: DecorationLevel | null, target: HTMLElement | null) {
  const el = target ?? (typeof document !== "undefined" ? document.documentElement : null);
  if (!el) return;
  // null = follow the theme's own --decoration (remove the attribute) — zero-flash.
  if (level === null) el.removeAttribute("data-decoration");
  else el.setAttribute("data-decoration", String(level));
}

function applyDensity(mode: DensityMode, target: HTMLElement | null) {
  const el = target ?? (typeof document !== "undefined" ? document.documentElement : null);
  if (!el) return;
  // "comfortable" is the identity — omit the attribute so the first paint is
  // pixel-identical to a pre-density build (zero-flash, mirrors decoration's null).
  if (mode === "comfortable") el.removeAttribute("data-density");
  else el.setAttribute("data-density", mode);
}

/**
 * Applies a theme by writing `data-theme` onto the target element (the document
 * root by default) and a motion preference via `data-motion-pref`. Persists both
 * choices to localStorage (separate keys, so changing one never clobbers the
 * other) and tracks the OS `prefers-reduced-motion` setting live. Safe to render
 * on the server (no-ops until mounted; the "system" default writes no attribute
 * so the first paint defers to the OS media query — no hydration flash).
 */
export function ThemeProvider({
  children,
  defaultTheme = DEFAULT_THEME,
  storageKey = "brand-ui-theme",
  defaultMotionPreference = DEFAULT_MOTION_PREFERENCE,
  motionStorageKey = "brand-ui-motion-pref",
  defaultDecoration = null,
  decorationStorageKey = "brand-ui-decoration",
  defaultDensity = DEFAULT_DENSITY,
  densityStorageKey = "brand-ui-density",
  attributeTarget = null,
}: ThemeProviderProps) {
  const [theme, setThemeState] = useState<ThemeName>(defaultTheme);
  const [motionPreference, setMotionState] = useState<MotionPreference>(defaultMotionPreference);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const [decoration, setDecorationState] = useState<DecorationLevel | null>(defaultDecoration);
  const [density, setDensityState] = useState<DensityMode>(defaultDensity);

  // Hydrate the theme from storage on mount, then apply.
  useEffect(() => {
    let initial = defaultTheme;
    if (storageKey && typeof window !== "undefined") {
      const stored = window.localStorage.getItem(storageKey);
      if (isThemeName(stored)) initial = stored;
    }
    setThemeState(initial);
    applyTheme(initial, attributeTarget);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Hydrate the motion preference from storage, apply it, and track the OS
  // reduced-motion setting live (so "system" and useReducedMotion stay correct).
  useEffect(() => {
    let initial = defaultMotionPreference;
    if (motionStorageKey && typeof window !== "undefined") {
      const stored = window.localStorage.getItem(motionStorageKey);
      if (isMotionPreference(stored)) initial = stored;
    }
    setMotionState(initial);
    applyMotionPreference(initial, attributeTarget);

    if (typeof window === "undefined") return;
    const mql = window.matchMedia(REDUCED_MOTION_QUERY);
    const onChange = () => setPrefersReducedMotion(mql.matches);
    onChange();
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Hydrate the decoration override from storage, then apply (null follows theme).
  useEffect(() => {
    let initial = defaultDecoration;
    if (decorationStorageKey && typeof window !== "undefined") {
      const stored = window.localStorage.getItem(decorationStorageKey);
      const n = stored === null ? null : Number(stored);
      if (n !== null && isDecorationLevel(n)) initial = n;
    }
    setDecorationState(initial);
    applyDecoration(initial, attributeTarget);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Hydrate the density mode from storage, then apply ("comfortable" omits attr).
  useEffect(() => {
    let initial = defaultDensity;
    if (densityStorageKey && typeof window !== "undefined") {
      const stored = window.localStorage.getItem(densityStorageKey);
      if (isDensity(stored)) initial = stored;
    }
    setDensityState(initial);
    applyDensity(initial, attributeTarget);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setTheme = useCallback(
    (next: ThemeName) => {
      setThemeState(next);
      applyTheme(next, attributeTarget);
      if (storageKey && typeof window !== "undefined") {
        window.localStorage.setItem(storageKey, next);
      }
    },
    [storageKey, attributeTarget],
  );

  const setMotionPreference = useCallback(
    (next: MotionPreference) => {
      setMotionState(next);
      applyMotionPreference(next, attributeTarget);
      if (motionStorageKey && typeof window !== "undefined") {
        window.localStorage.setItem(motionStorageKey, next);
      }
    },
    [motionStorageKey, attributeTarget],
  );

  const setDecoration = useCallback(
    (next: DecorationLevel | null) => {
      setDecorationState(next);
      applyDecoration(next, attributeTarget);
      if (decorationStorageKey && typeof window !== "undefined") {
        if (next === null) window.localStorage.removeItem(decorationStorageKey);
        else window.localStorage.setItem(decorationStorageKey, String(next));
      }
    },
    [decorationStorageKey, attributeTarget],
  );

  const setDensity = useCallback(
    (next: DensityMode) => {
      setDensityState(next);
      applyDensity(next, attributeTarget);
      if (densityStorageKey && typeof window !== "undefined") {
        if (next === "comfortable") window.localStorage.removeItem(densityStorageKey);
        else window.localStorage.setItem(densityStorageKey, next);
      }
    },
    [densityStorageKey, attributeTarget],
  );

  const value = useMemo<ThemeContextValue>(
    () => ({
      theme,
      themes: THEMES,
      setTheme,
      motionPreference,
      setMotionPreference,
      prefersReducedMotion,
      decoration,
      effectiveDecoration: decoration ?? THEME_META[theme].decorationLevel ?? 0,
      setDecoration,
      density,
      setDensity,
    }),
    [
      theme,
      setTheme,
      motionPreference,
      setMotionPreference,
      prefersReducedMotion,
      decoration,
      setDecoration,
      density,
      setDensity,
    ],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

/** Access the active theme and a setter. Must be used inside <ThemeProvider>. */
export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useTheme must be used within a <ThemeProvider>.");
  }
  return ctx;
}

/**
 * Access the motion preference, its setter, and the live OS reduced-motion flag.
 * A thin alias over the theme context for settings UIs (mirrors `useTheme`).
 */
export function useMotionPreference() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useMotionPreference must be used within a <ThemeProvider>.");
  }
  return {
    motionPreference: ctx.motionPreference,
    setMotionPreference: ctx.setMotionPreference,
    prefersReducedMotion: ctx.prefersReducedMotion,
  };
}

/**
 * Access the decoration dial (override, effective level, setter). A thin alias
 * over the theme context for settings UIs (mirrors `useMotionPreference`).
 */
export function useDecoration() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useDecoration must be used within a <ThemeProvider>.");
  }
  return {
    decoration: ctx.decoration,
    effectiveDecoration: ctx.effectiveDecoration,
    setDecoration: ctx.setDecoration,
  };
}

/**
 * Access the density mode and its setter. A thin alias over the theme context
 * for settings UIs (mirrors `useDecoration`). "comfortable" is the identity
 * (Tailwind default spacing — no visual change from pre-density builds).
 */
export function useDensity() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useDensity must be used within a <ThemeProvider>.");
  }
  return {
    density: ctx.density,
    setDensity: ctx.setDensity,
  };
}

/**
 * Resolve the EFFECTIVE reduced-motion boolean for JS-driven animation (the CSS
 * `--motion-factor` gate cannot reach a JS timeline, e.g. Motion/Framer). Same
 * precedence as the CSS gate: user-explicit beats the OS setting.
 *
 * - `reduced` → true   (user forces reduced)
 * - `full`    → false  (user forces full motion)
 * - `system`  → the OS `prefers-reduced-motion` value
 *
 * Use for JS animations and to feed `<MotionConfig reducedMotion>`. CSS
 * transitions/animations do NOT need this — they gate via `--motion-factor`.
 *
 * Provider-OPTIONAL: unlike `useMotionPreference`, this does not throw outside a
 * `<ThemeProvider>`. Without one it degrades to OS-only detection (preference
 * "system"), so it is safe to call from any library component (e.g. Shimmer).
 */
export function useReducedMotion(): boolean {
  const ctx = useContext(ThemeContext);
  const [osReducedMotion, setOsReducedMotion] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mql = window.matchMedia(REDUCED_MOTION_QUERY);
    const onChange = () => setOsReducedMotion(mql.matches);
    onChange();
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  const preference = ctx?.motionPreference ?? "system";
  if (preference === "reduced") return true;
  if (preference === "full") return false;
  return osReducedMotion;
}
