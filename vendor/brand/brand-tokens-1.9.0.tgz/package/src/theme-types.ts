/**
 * @brand/tokens — theme types
 *
 * The set of themes shipped with the design system. Each has a matching
 * `[data-theme="..."]` block in `themes.css`. `:root` holds a neutral light
 * BASE/fallback (not a selectable theme); the default is `qlik-bright`.
 * Adding a theme = add a value here + a block in themes.css.
 */

export const THEMES = ["qlik-bright", "qlik-dark", "blueprint"] as const;

export type ThemeName = (typeof THEMES)[number];

export interface ThemeMeta {
  /** The value written to `data-theme`. */
  value: ThemeName;
  /** Human-readable label for theme switchers. */
  label: string;
  /** Whether the theme is predominantly dark (useful for image/asset swaps). */
  dark: boolean;
  /** One-line description for docs/UX. */
  description: string;
  /** Default decoration dial (0–10) for this theme. blueprint = 10; others 0. */
  decorationLevel?: DecorationLevel;
}

export const THEME_META: Record<ThemeName, ThemeMeta> = {
  "qlik-bright": {
    value: "qlik-bright",
    label: "Qlik Bright",
    dark: false,
    description:
      "Qlik Cloud light theme — Qlik Green primary on near-white neutral surfaces; neutral grey text, 4px radius, blue focus ring, Qlik chart palette, Source Sans Pro.",
  },
  "qlik-dark": {
    value: "qlik-dark",
    label: "Qlik Dark",
    dark: true,
    description:
      "Qlik Cloud dark theme on warm charcoal surfaces with off-white ivory text — bright Qlik Green, blue focus ring, Qlik chart palette, Source Sans Pro, 4px radius.",
  },
  blueprint: {
    value: "blueprint",
    label: "Blueprint",
    dark: true,
    description: "Navy cyanotype palette at full decoration — reprographic, white-on-blue.",
    decorationLevel: 2,
  },
};

/** Default theme applied when nothing is persisted. */
export const DEFAULT_THEME: ThemeName = "qlik-bright";

/** Runtime guard for narrowing unknown strings (e.g. persisted values). */
export function isThemeName(value: unknown): value is ThemeName {
  return typeof value === "string" && (THEMES as readonly string[]).includes(value);
}

/* ==========================================================================
   MOTION PREFERENCE
   A user-facing override for micro-interaction motion, layered over the OS
   `prefers-reduced-motion` setting and the per-theme default. Mirrors the
   THEMES / ThemeName / isThemeName surface above. The ThemeProvider persists
   the choice and writes `data-motion-pref` (see themes.css "MOTION GATE").
   ========================================================================== */

/**
 * The three motion settings a user can choose, in precedence-neutral order:
 * - `system`  — follow the OS `prefers-reduced-motion` setting (no attribute).
 * - `reduced` — minimize motion regardless of the OS.
 * - `full`    — always animate, even if the OS asks to reduce (informed consent).
 */
export const MOTION_PREFERENCES = ["system", "reduced", "full"] as const;

export type MotionPreference = (typeof MOTION_PREFERENCES)[number];

export interface MotionPreferenceMeta {
  /** The value written to `data-motion-pref` (`system` writes no attribute). */
  value: MotionPreference;
  /** Human-readable label for settings UIs. */
  label: string;
  /** One-line description for docs/UX. */
  description: string;
}

export const MOTION_PREFERENCE_META: Record<MotionPreference, MotionPreferenceMeta> = {
  system: {
    value: "system",
    label: "System",
    description: "Follow the operating system's reduce-motion setting.",
  },
  reduced: {
    value: "reduced",
    label: "Reduce motion",
    description: "Minimize animation regardless of the system setting.",
  },
  full: {
    value: "full",
    label: "Full motion",
    description: "Always animate, even when the system requests reduced motion.",
  },
};

/** Default motion preference when nothing is persisted. */
export const DEFAULT_MOTION_PREFERENCE: MotionPreference = "system";

/** Runtime guard for narrowing unknown strings (e.g. persisted values). */
export function isMotionPreference(value: unknown): value is MotionPreference {
  return typeof value === "string" && (MOTION_PREFERENCES as readonly string[]).includes(value);
}

/* ==========================================================================
   DECORATION LEVEL
   The "blueprint-ness" dial (0–10), ORTHOGONAL to color: 0 = plain themed UI,
   10 = full reprographic drafting (grid, hatch, drawn-not-filled, squared). Set
   it on any theme/region/document to add gentle blueprint texture in ANY color.
   Mirrors the MOTION surface above; the ThemeProvider persists the choice and
   writes `data-decoration`, defaulting to THEME_META[theme].decorationLevel
   (blueprint = 10). See themes.css "DECORATION DIAL" + .claude/rules/blueprint-decoration.md.
   ========================================================================== */

export const DECORATION_LEVELS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10] as const;

export type DecorationLevel = (typeof DECORATION_LEVELS)[number];

/** Default decoration when nothing is persisted (the theme's own default wins). */
export const DEFAULT_DECORATION_LEVEL: DecorationLevel = 0;

/** Runtime guard for narrowing unknown values (e.g. persisted strings/numbers). */
export function isDecorationLevel(value: unknown): value is DecorationLevel {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 10;
}

/* ==========================================================================
   DENSITY MODE
   The spacing-density dial, ORTHOGONAL to color and decoration: overrides
   Tailwind v4's global `--spacing` variable so every height/padding/gap/
   margin/space utility rescales uniformly with zero component edits.
   `comfortable` is the identity value (0.25rem = Tailwind's default) so the
   default render is pixel-identical to pre-density builds.
   Mirrors the DECORATION surface above; the ThemeProvider persists the choice
   and writes `data-density` (omitting it for `comfortable` to avoid flash).
   See density.css and @.claude/rules/styling-and-tokens.md.
   ========================================================================== */

export const DENSITIES = ["compact", "comfortable", "spacious"] as const;

export type DensityMode = (typeof DENSITIES)[number];

export interface DensityMeta {
  /** The value written to `data-density`. */
  value: DensityMode;
  /** Human-readable label for density switchers. */
  label: string;
  /** One-line description for docs/UX. */
  description: string;
}

export const DENSITY_META: Record<DensityMode, DensityMeta> = {
  compact: {
    value: "compact",
    label: "Compact",
    description: "Tighter spacing (~11%) — denser tables, sidebars and toolbars.",
  },
  comfortable: {
    value: "comfortable",
    label: "Comfortable",
    description: "Default spacing (identity — no change from Tailwind baseline).",
  },
  spacious: {
    value: "spacious",
    label: "Spacious",
    description: "Roomier spacing (~12%) — touch-friendly and low-density dashboards.",
  },
};

/** Default density when nothing is persisted. Identity: comfortable = no change. */
export const DEFAULT_DENSITY: DensityMode = "comfortable";

/** Runtime guard for narrowing unknown strings (e.g. persisted values). */
export function isDensity(value: unknown): value is DensityMode {
  return typeof value === "string" && (DENSITIES as readonly string[]).includes(value);
}
