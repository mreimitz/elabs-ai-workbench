/**
 * themes-contrast.test.ts — deterministic, browser-free WCAG AA gate on the
 * design-system color tokens.
 *
 * Parses themes.css, extracts each theme block's raw oklch() token literals,
 * converts oklch → sRGB → WCAG relative luminance, and asserts the text/surface
 * pairings that consumers actually render clear the AA 4.5:1 body-text threshold
 * in EVERY theme. A theme that forgets a token (falling back to :root) or
 * under-tunes one fails here, before it ships. Locks issues #20 and #23.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { describe, expect, it } from "vitest";
import { contrast, parseOklch } from "./color-contrast";

const __dirname = dirname(fileURLToPath(import.meta.url));
const css = readFileSync(join(__dirname, "themes.css"), "utf8");

const AA = 4.5;
/** WCAG 1.4.11 — non-text UI components (borders/outlines) need ≥3:1. */
const AA_NONTEXT = 3;

/** Theme display name → CSS selector body extractor. `light` is `:root`. */
const THEME_BLOCKS: Record<string, string> = {
  light: extractBlock(/:root\s*\{([\s\S]*?)\n\}/),
  blueprint: extractThemeBlock("blueprint"),
  "qlik-bright": extractThemeBlock("qlik-bright"),
  "qlik-dark": extractThemeBlock("qlik-dark"),
};

function extractBlock(re: RegExp): string {
  const m = css.match(re);
  const body = m?.[1];
  if (body == null) throw new Error(`Block not found for ${re}`);
  return body;
}

/** First `[data-theme="name"] { … }` block (blueprint has a 2nd, non-color one). */
function extractThemeBlock(name: string): string {
  const re = new RegExp(`\\[data-theme="${name}"\\]\\s*\\{([\\s\\S]*?)\\n\\}`);
  return extractBlock(re);
}

/** All `--token: oklch(...)` declarations in a block body → map. */
function tokenMap(body: string): Record<string, string> {
  const map: Record<string, string> = {};
  for (const m of body.matchAll(/(--[\w-]+):\s*(oklch\([^;]+\))\s*;/g)) {
    const name = m[1];
    const value = m[2];
    if (name != null && value != null) map[name] = value.trim();
  }
  return map;
}

const TOKENS: Record<string, Record<string, string>> = Object.fromEntries(
  Object.entries(THEME_BLOCKS).map(([name, body]) => [name, tokenMap(body)]),
);

const THEMES = Object.keys(THEME_BLOCKS);
/** The surfaces colored TEXT is rendered on (issue #20). */
const TEXT_SURFACES = ["--background", "--card", "--surface-muted"] as const;
/**
 * Canonical content surfaces a load-bearing divider/outline is drawn against
 * (issue #172). 1.4.11 is pair-relative — `--border-strong`/`--input` are
 * guaranteed only against `--card`/`--background`, not the mid-tone surfaces.
 */
const NONTEXT_SURFACES = ["--card", "--background"] as const;

/**
 * #221 — calc syntax-highlight TEXT tokens. Rendered as colored code text on the
 * calc sheet (`bg-card`) and inline in prose (`bg-background`), so each must clear
 * AA on both. Hue is never the SOLE cue (weight/underline carry roles in
 * low-chroma themes like blueprint), but the colors still have to be legible.
 */
const CALC_TEXT_TOKENS = [
  "--calc-foreground",
  "--calc-number",
  "--calc-unit",
  "--calc-currency",
  "--calc-variable",
  "--calc-reference",
  "--calc-function",
  "--calc-operator",
  "--calc-result",
  "--calc-comment",
  "--calc-warning",
] as const;

function token(theme: string, name: string): string {
  const v = TOKENS[theme]?.[name];
  if (!v) throw new Error(`${theme} is missing ${name} (would fall back to :root)`);
  return v;
}

describe("themes.css — WCAG AA token contrast (all themes)", () => {
  describe.each(THEMES)("%s", (theme) => {
    // Issue #20 — on-surface status TEXT tokens.
    it.each(TEXT_SURFACES)("success-text ≥ 4.5:1 on %s", (surface) => {
      const ratio = contrast(token(theme, "--success-text"), token(theme, surface));
      expect(
        ratio,
        `success-text vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    it.each(TEXT_SURFACES)("destructive-text ≥ 4.5:1 on %s", (surface) => {
      const ratio = contrast(token(theme, "--destructive-text"), token(theme, surface));
      expect(
        ratio,
        `destructive-text vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    // On-surface status TEXT tokens, siblings of success/destructive-text. The
    // fill tokens (`--warning`/`--info`) are tuned for *-foreground ink on a
    // colored plate and are often too light for bare colored TEXT on a surface,
    // so the `-text` variants carry the AA-cleared on-surface color.
    it.each(TEXT_SURFACES)("warning-text ≥ 4.5:1 on %s", (surface) => {
      const ratio = contrast(token(theme, "--warning-text"), token(theme, surface));
      expect(
        ratio,
        `warning-text vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    it.each(TEXT_SURFACES)("info-text ≥ 4.5:1 on %s", (surface) => {
      const ratio = contrast(token(theme, "--info-text"), token(theme, surface));
      expect(
        ratio,
        `info-text vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    // Search / find-in-page match highlight — the ink on the `<mark>` plate must
    // clear AA body text in every theme (the dedicated pair that replaces the
    // sub-AA `bg-warning/40` improvisation, 3.48:1 in qlik-dark). Consumed by
    // `MatchHighlight` (@brand/ui). See #284 + the highlight-token issue.
    it("highlight-foreground ≥ 4.5:1 on --highlight", () => {
      const ratio = contrast(token(theme, "--highlight-foreground"), token(theme, "--highlight"));
      expect(
        ratio,
        `highlight-foreground vs --highlight in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    // Issue #20 — muted text on muted surfaces (light was the regression).
    it.each(["--muted", "--surface-muted"] as const)(
      "muted-foreground ≥ 4.5:1 on %s",
      (surface) => {
        const ratio = contrast(token(theme, "--muted-foreground"), token(theme, surface));
        expect(
          ratio,
          `muted-foreground vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
        ).toBeGreaterThanOrEqual(AA);
      },
    );

    // Issue #23 — sidebar muted nav foreground on the sidebar ground.
    it("sidebar-muted-foreground ≥ 4.5:1 on --sidebar", () => {
      const ratio = contrast(token(theme, "--sidebar-muted-foreground"), token(theme, "--sidebar"));
      expect(
        ratio,
        `sidebar-muted-foreground vs --sidebar in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA);
    });

    // Issue #172 — WCAG 1.4.11: the load-bearing divider/outline rung ≥ 3:1 on
    // the canonical content surfaces. `--border` stays subtle by design (it's a
    // redundant boundary, 1.4.11-exempt); `--border-strong` carries the structural
    // cue and must clear non-text contrast. This is the ADR 0010 rung and STANDS.
    it.each(NONTEXT_SURFACES)("border-strong ≥ 3:1 on %s", (surface) => {
      const ratio = contrast(token(theme, "--border-strong"), token(theme, surface));
      expect(
        ratio,
        `border-strong vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
      ).toBeGreaterThanOrEqual(AA_NONTEXT);
    });

    // NOTE: there is intentionally NO `--input ≥ 3:1` assertion here.
    // ADR 0010 Amendment (2026-06-20) returned `--input` to the SUBTLE hairline
    // rung (== --border on qlik-bright/light/blueprint; a perceptible-but-quiet
    // 0.42 mid-value on qlik-dark) so form controls read on-theme rather than
    // carrying a dark strong-rung outline. This relaxes ADR 0010's `--input → strong
    // rung` sub-decision by maintainer direction: <3:1 resting contrast is an
    // accepted aesthetic-over-strict-1.4.11 tradeoff for an internal system — field
    // identity rests on the recessed fill + focus-visible ring + control glyphs +
    // hover, with the resting border as a redundant hairline. Do NOT re-add a 3:1
    // gate on `--input`; the `--border-strong` rung above is the load-bearing one.

    // #221 — calc syntax tokens as colored TEXT on the surfaces calc renders on.
    it.each(CALC_TEXT_TOKENS)("%s ≥ 4.5:1 on calc surfaces", (tokenName) => {
      for (const surface of NONTEXT_SURFACES) {
        const ratio = contrast(token(theme, tokenName), token(theme, surface));
        expect(
          ratio,
          `${tokenName} vs ${surface} in ${theme} = ${ratio.toFixed(2)}`,
        ).toBeGreaterThanOrEqual(AA);
      }
    });
  });
});

// Issue #162 — in the monochrome blueprint theme, success vs destructive delta
// text cannot separate by hue, so the -text variants must hold a perceptible
// lightness gap (the visual REINFORCEMENT of the non-color polarity glyph). The
// other themes separate by hue, so this is blueprint-scoped only.
const BLUEPRINT_STATUS_DELTA_L = 0.15;
describe("themes.css — blueprint status -text lightness separation (#162)", () => {
  it(`success-text vs destructive-text |ΔL| ≥ ${BLUEPRINT_STATUS_DELTA_L}`, () => {
    const success = parseOklch(token("blueprint", "--success-text")).l;
    const destructive = parseOklch(token("blueprint", "--destructive-text")).l;
    const deltaL = Math.abs(success - destructive);
    expect(
      deltaL,
      `blueprint success-text(${success}) vs destructive-text(${destructive})`,
    ).toBeGreaterThanOrEqual(BLUEPRINT_STATUS_DELTA_L);
  });
});
