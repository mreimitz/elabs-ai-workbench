"use client";

import type { ComponentProps, ReactNode } from "react";
import { ArrowUp, ChevronDown, Globe, Mic, Paperclip, Sparkles } from "lucide-react";
import { cn } from "@brand/ui";

import {
  PromptInput,
  PromptInputBody,
  PromptInputButton,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
  type PromptInputProps,
} from "./prompt-input";
import { Suggestion, Suggestions } from "./suggestion";

export interface ComposerProps {
  /** Submit handler — receives the assembled message (text + attachments). */
  onSubmit?: PromptInputProps["onSubmit"];
  /** Textarea placeholder. Default `"Ask me anything…"`. */
  placeholder?: string;
  /**
   * Muted status line shown above the input well. Default `"Awaiting your
   * input"`. Drive it from chat state ("Thinking…", "Generating…") or pass
   * `null` to hide the strip entirely.
   */
  status?: ReactNode;
  /** Model-selector pill label. Default `"Claude Opus 4"`; pass `null` to hide it. */
  model?: ReactNode;
  /**
   * Override the left-hand tool cluster (attach + model pill) — e.g. to add a
   * web-search or connect-data control. Render `PromptInputButton`s /
   * `PromptInputActionMenu` here; when set, `showAttach`/`model` are ignored.
   */
  tools?: ReactNode;
  /** Send-button state, forwarded to `PromptInputSubmit` (ready/submitted/streaming/error). */
  sendStatus?: ComponentProps<typeof PromptInputSubmit>["status"];
  /** Stop handler used while the send button shows the generating state. */
  onStop?: ComponentProps<typeof PromptInputSubmit>["onStop"];
  /** Optional suggestion chips rendered beneath the composer. */
  suggestions?: string[];
  /** Click handler for a suggestion chip. */
  onSuggestionClick?: (suggestion: string) => void;
  /** Show the voice button. Default `true`. */
  showVoice?: boolean;
  /** Show the attach button. Default `true`. */
  showAttach?: boolean;
  /** Extra classes for the outer card frame. */
  className?: string;
}

/**
 * Composer — the standard brand-ui AI chat input.
 *
 * A rounded two-tone "double card": an outer `bg-card` frame with a muted status
 * strip wrapping a recessed `PromptInput` well (sharp top, theme-rounded bottom),
 * a model pill, voice, and a circular send. Built on the real `PromptInput`, so
 * it drops into a `ChatShell` footer or stands alone as an empty-state composer.
 * Semantic tokens only; theme-aware radii (`rounded-xl` frame / `rounded-b-lg`
 * well); reads in every theme.
 *
 * This is the canonical chat input — reach for it instead of hand-rolling a
 * `PromptInput` footer.
 */
export function Composer({
  onSubmit,
  placeholder = "Ask me anything…",
  status = "Awaiting your input",
  model = "Claude Opus 4",
  tools,
  sendStatus,
  onStop,
  suggestions,
  onSuggestionClick,
  showVoice = true,
  showAttach = true,
  className,
}: ComposerProps) {
  return (
    <div className="w-full">
      <div className={cn("rounded-xl border bg-card p-1.5 shadow-sm", className)}>
        {/* Muted status strip — sits in the outer frame above the input well. */}
        {status != null ? (
          <div className="flex items-center gap-1.5 px-3 py-1.5 text-meta text-muted-foreground">
            <Sparkles className="size-3.5" aria-hidden="true" />
            <span>{status}</span>
          </div>
        ) : null}

        {/* Inner well — sharp top (nests under the strip), theme-rounded bottom. */}
        <PromptInput
          onSubmit={onSubmit ?? (() => undefined)}
          surfaceClassName="rounded-t-none rounded-b-lg"
        >
          <PromptInputBody>
            <PromptInputTextarea placeholder={placeholder} />
          </PromptInputBody>
          <PromptInputFooter>
            <PromptInputTools>
              {tools ?? (
                <>
                  {showAttach ? (
                    <PromptInputButton tooltip="Attach files">
                      <Paperclip className="size-4" />
                    </PromptInputButton>
                  ) : null}
                  {model != null ? (
                    <PromptInputButton variant="ghost" className="gap-1.5 rounded-full">
                      <Globe className="size-4" />
                      <span>{model}</span>
                      <ChevronDown className="size-4 opacity-60" />
                    </PromptInputButton>
                  ) : null}
                </>
              )}
            </PromptInputTools>
            <div className="flex items-center gap-1">
              {showVoice ? (
                <PromptInputButton tooltip="Voice">
                  <Mic className="size-4" />
                </PromptInputButton>
              ) : null}
              <PromptInputSubmit status={sendStatus} onStop={onStop} className="rounded-full">
                <ArrowUp className="size-4" />
              </PromptInputSubmit>
            </div>
          </PromptInputFooter>
        </PromptInput>
      </div>

      {suggestions && suggestions.length > 0 ? (
        <Suggestions className="mt-4 justify-center">
          {suggestions.map((s) => (
            <Suggestion key={s} suggestion={s} onClick={() => onSuggestionClick?.(s)} />
          ))}
        </Suggestions>
      ) : null}
    </div>
  );
}
