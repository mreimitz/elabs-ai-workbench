import type { Meta, StoryObj } from "@storybook/react-vite";
import { ToolDetails, ToolInput } from "./tool";
import { ToolResultCard } from "./tool-result-card";

const meta = {
  title: "AI/ToolResultCard",
  component: ToolResultCard,
  parameters: { layout: "padded" },
  tags: ["autodocs"],
} satisfies Meta<typeof ToolResultCard>;
export default meta;
type Story = StoryObj<typeof meta>;

// The elevation channel (#192, research 10 §B.4): the produced artifact IS
// the headline. The host is presentational — pass any node (an AutoChart,
// DataTable, file preview, …) as children; here a plain token-styled table.
export const Default: Story = {
  render: () => (
    <ToolResultCard
      className="max-w-prose"
      title="Revenue by region — Q3 vs Q2"
      summary="Total $48.2M · +12.4% QoQ"
      status="complete"
      details={
        <ToolDetails>
          <ToolInput input={{ chart: "bar", x: "region", series: ["q2", "q3"] }} />
        </ToolDetails>
      }
    >
      <table className="w-full text-body tabular-nums">
        <thead>
          <tr className="border-b border-border-strong text-start text-meta text-muted-foreground">
            <th className="py-1.5 text-start">Region</th>
            <th className="py-1.5 text-end">Q2</th>
            <th className="py-1.5 text-end">Q3</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="py-1.5">EMEA</td>
            <td className="py-1.5 text-end">$16.1M</td>
            <td className="py-1.5 text-end">$18.4M</td>
          </tr>
          <tr>
            <td className="py-1.5">Americas</td>
            <td className="py-1.5 text-end">$19.6M</td>
            <td className="py-1.5 text-end">$21.2M</td>
          </tr>
          <tr>
            <td className="py-1.5">APAC</td>
            <td className="py-1.5 text-end">$7.2M</td>
            <td className="py-1.5 text-end">$8.6M</td>
          </tr>
        </tbody>
      </table>
    </ToolResultCard>
  ),
};
