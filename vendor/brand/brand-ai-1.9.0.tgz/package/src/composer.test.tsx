import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Composer } from "./composer";

describe("Composer", () => {
  it("renders the default status line, placeholder, and model pill", () => {
    render(<Composer />);

    expect(screen.getByText("Awaiting your input")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("Ask me anything…")).toBeInTheDocument();
    expect(screen.getByText("Claude Opus 4")).toBeInTheDocument();
  });

  it("accepts a custom status and placeholder, and hides the model pill when model is null", () => {
    render(<Composer status="Thinking…" placeholder="Ask the agent…" model={null} />);

    expect(screen.getByText("Thinking…")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("Ask the agent…")).toBeInTheDocument();
    expect(screen.queryByText("Claude Opus 4")).not.toBeInTheDocument();
  });

  it("renders suggestion chips and fires onSuggestionClick with the chosen suggestion", async () => {
    const onSuggestionClick = vi.fn();
    render(<Composer suggestions={["Summary", "Code"]} onSuggestionClick={onSuggestionClick} />);

    const chip = screen.getByRole("button", { name: "Summary" });
    await userEvent.click(chip);
    expect(onSuggestionClick).toHaveBeenCalledWith("Summary");
  });
});
