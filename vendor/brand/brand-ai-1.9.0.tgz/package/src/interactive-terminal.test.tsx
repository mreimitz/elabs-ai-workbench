import { createRef } from "react";
import { act, cleanup, render } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// xterm.js needs a real canvas + layout to render, so it cannot mount in
// jsdom — mock the engine and assert the wrapper's lifecycle + theming
// contract. Real rendering + a11y come from the Storybook interaction tests.
// Mirrors the Monaco mocking pattern in @brand/editor's code-editor.test.tsx.
const h = vi.hoisted(() => {
  const state = {
    dataHandler: undefined as undefined | ((data: string) => void),
    resizeHandler: undefined as undefined | ((size: { cols: number; rows: number }) => void),
  };
  const textarea = { setAttribute: vi.fn(), getAttribute: vi.fn() };

  function makeInstance() {
    return {
      options: { fontSize: 13, disableStdin: false } as Record<string, unknown>,
      textarea,
      loadAddon: vi.fn(),
      open: vi.fn(),
      write: vi.fn(),
      clear: vi.fn(),
      focus: vi.fn(),
      dispose: vi.fn(),
      attachCustomKeyEventHandler: vi.fn(),
      onData: vi.fn((cb: (data: string) => void) => {
        state.dataHandler = cb;
        return { dispose: vi.fn() };
      }),
      onResize: vi.fn((cb: (size: { cols: number; rows: number }) => void) => {
        state.resizeHandler = cb;
        return { dispose: vi.fn() };
      }),
    };
  }

  const instances: Array<ReturnType<typeof makeInstance>> = [];
  const Terminal = vi.fn(() => {
    const instance = makeInstance();
    instances.push(instance);
    return instance;
  });
  const FitAddon = vi.fn(() => ({ fit: vi.fn(), dispose: vi.fn() }));

  return { state, textarea, instances, Terminal, FitAddon };
});

vi.mock("@xterm/xterm", () => ({
  Terminal: h.Terminal,
}));
vi.mock("@xterm/addon-fit", () => ({
  FitAddon: h.FitAddon,
}));
// The real stylesheet import is a side-effect-only CSS import (already a
// no-op under this package's `css: false` vitest config); mock it explicitly
// so the module graph doesn't need to touch the filesystem in this test.
vi.mock("@xterm/xterm/css/xterm.css", () => ({}));

import {
  buildInteractiveTerminalTheme,
  InteractiveTerminal,
  type InteractiveTerminalHandle,
} from "./interactive-terminal";

beforeEach(() => {
  h.state.dataHandler = undefined;
  h.state.resizeHandler = undefined;
  h.instances.length = 0;
  vi.clearAllMocks();
});
afterEach(cleanup);

describe("InteractiveTerminal", () => {
  it("creates an xterm instance and opens it into the container on mount", () => {
    render(<InteractiveTerminal aria-label="Agent shell" />);
    expect(h.Terminal).toHaveBeenCalledTimes(1);
    expect(h.instances[0]?.open).toHaveBeenCalledTimes(1);
  });

  it("forwards the aria-label onto xterm's real (focusable) textarea", () => {
    render(<InteractiveTerminal aria-label="Agent shell" />);
    expect(h.textarea.setAttribute).toHaveBeenCalledWith("aria-label", "Agent shell");
  });

  it("handle.write() delegates to the xterm instance", () => {
    const ref = createRef<InteractiveTerminalHandle>();
    render(<InteractiveTerminal ref={ref} aria-label="Agent shell" />);
    act(() => ref.current?.write("hello\r\n"));
    expect(h.instances[0]?.write).toHaveBeenCalledWith("hello\r\n");
  });

  it("handle.clear() / handle.focus() delegate to the xterm instance", () => {
    const ref = createRef<InteractiveTerminalHandle>();
    render(<InteractiveTerminal ref={ref} aria-label="Agent shell" />);
    act(() => ref.current?.clear());
    act(() => ref.current?.focus());
    expect(h.instances[0]?.clear).toHaveBeenCalledTimes(1);
    expect(h.instances[0]?.focus).toHaveBeenCalledTimes(1);
  });

  it("handle.fit() delegates to the FitAddon instance", () => {
    const ref = createRef<InteractiveTerminalHandle>();
    render(<InteractiveTerminal ref={ref} aria-label="Agent shell" />);
    const fitAddon = h.FitAddon.mock.results[0]?.value as { fit: ReturnType<typeof vi.fn> };
    act(() => ref.current?.fit());
    expect(fitAddon.fit).toHaveBeenCalled();
  });

  it("wires onData to the onData prop (keystrokes + paste)", () => {
    const onData = vi.fn();
    render(<InteractiveTerminal aria-label="Agent shell" onData={onData} />);
    expect(h.instances[0]?.onData).toHaveBeenCalledTimes(1);
    act(() => h.state.dataHandler?.("ls\n"));
    expect(onData).toHaveBeenCalledWith("ls\n");
  });

  it("reports container resize as cols/rows via onResize", () => {
    const onResize = vi.fn();
    render(<InteractiveTerminal aria-label="Agent shell" onResize={onResize} />);
    expect(h.instances[0]?.onResize).toHaveBeenCalledTimes(1);
    act(() => h.state.resizeHandler?.({ cols: 80, rows: 24 }));
    expect(onResize).toHaveBeenCalledWith({ cols: 80, rows: 24 });
  });

  describe("readOnly", () => {
    it("constructs xterm with disableStdin: true", () => {
      render(<InteractiveTerminal aria-label="Agent log" readOnly />);
      expect(h.instances[0]?.options.disableStdin).toBe(true);
    });

    it("does not wire onData", () => {
      const onData = vi.fn();
      render(<InteractiveTerminal aria-label="Agent log" onData={onData} readOnly />);
      expect(h.instances[0]?.onData).not.toHaveBeenCalled();
    });

    it("still exposes write() so consumers can render output", () => {
      const ref = createRef<InteractiveTerminalHandle>();
      render(<InteractiveTerminal ref={ref} aria-label="Agent log" readOnly />);
      act(() => ref.current?.write("log line\r\n"));
      expect(h.instances[0]?.write).toHaveBeenCalledWith("log line\r\n");
    });
  });

  it("disposes the xterm instance on unmount", () => {
    const { unmount } = render(<InteractiveTerminal aria-label="Agent shell" />);
    unmount();
    expect(h.instances[0]?.dispose).toHaveBeenCalledTimes(1);
  });
});

describe("buildInteractiveTerminalTheme", () => {
  afterEach(() => {
    document.documentElement.removeAttribute("style");
  });

  it("maps ANSI red to the resolved --destructive-text token", () => {
    document.documentElement.style.setProperty("--destructive-text", "#dc2626");
    expect(buildInteractiveTerminalTheme().red).toBe("#dc2626");
  });

  it("maps ANSI green/yellow/blue to their -text tokens", () => {
    document.documentElement.style.setProperty("--success-text", "#16a34a");
    document.documentElement.style.setProperty("--warning-text", "#ca8a04");
    document.documentElement.style.setProperty("--info-text", "#2563eb");
    const theme = buildInteractiveTerminalTheme();
    expect(theme.green).toBe("#16a34a");
    expect(theme.yellow).toBe("#ca8a04");
    expect(theme.blue).toBe("#2563eb");
  });

  it("resolves an oklch() token value to hex, not passed through raw", () => {
    document.documentElement.style.setProperty("--destructive-text", "oklch(0.5 0.2 27)");
    expect(buildInteractiveTerminalTheme().red).toMatch(/^#[0-9a-f]{6}$/);
  });

  it("derives background/foreground/cursor from --card/--foreground/--primary", () => {
    document.documentElement.style.setProperty("--card", "#111827");
    document.documentElement.style.setProperty("--foreground", "#f9fafb");
    document.documentElement.style.setProperty("--primary", "#6366f1");
    const theme = buildInteractiveTerminalTheme();
    expect(theme.background).toBe("#111827");
    expect(theme.foreground).toBe("#f9fafb");
    expect(theme.cursor).toBe("#6366f1");
    // cursorAccent tracks the background so glyphs stay legible under a block cursor.
    expect(theme.cursorAccent).toBe("#111827");
  });

  it("keeps black/white as background/foreground rungs, not the same value", () => {
    document.documentElement.style.setProperty("--card", "#0b1220");
    document.documentElement.style.setProperty("--foreground", "#e5e7eb");
    const theme = buildInteractiveTerminalTheme();
    expect(theme.black).toBe("#0b1220");
    expect(theme.brightWhite).toBe("#e5e7eb");
    expect(theme.black).not.toBe(theme.brightWhite);
  });
});
