import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import {
  AgentMessage,
  Message,
  MessageAvatar,
  MessageContent,
  MessageHeader,
  UserMessage,
} from "./message";

describe("Message chat-user channel (#191, research 11 §B.1)", () => {
  it("gives the user bubble the chat-user fill + foreground", () => {
    render(
      <Message from="user">
        <MessageContent data-testid="content">Hi</MessageContent>
      </Message>,
    );
    const content = screen.getByTestId("content");
    expect(content.className).toContain("group-[.is-user]:bg-chat-user");
    expect(content.className).toContain("group-[.is-user]:text-chat-user-foreground");
    expect(content.className).not.toContain("bg-secondary");
  });

  it("drops the dead is-user:dark vendored class and uses the body role", () => {
    render(
      <Message from="assistant">
        <MessageContent data-testid="content">Hello</MessageContent>
      </Message>,
    );
    const content = screen.getByTestId("content");
    expect(content.className).not.toContain("is-user:dark");
    expect(content.className).toContain("text-body");
    expect(content.className).not.toContain("text-sm");
  });
});

describe("UserMessage / AgentMessage presets (#191, research 11 §B.2)", () => {
  it("UserMessage is a Message from=user preset", () => {
    render(
      <UserMessage data-testid="msg">
        <MessageContent>Hi</MessageContent>
      </UserMessage>,
    );
    expect(screen.getByTestId("msg").className).toContain("is-user");
  });

  it("AgentMessage defaults to no rail", () => {
    render(
      <AgentMessage data-testid="msg">
        <MessageContent>Working on it.</MessageContent>
      </AgentMessage>,
    );
    const msg = screen.getByTestId("msg");
    expect(msg.className).toContain("is-assistant");
    expect(msg.className).not.toContain("border-s-primary");
  });

  it("AgentMessage emphasis=answer applies the green rail on the wrapper (not the clipped content)", () => {
    render(
      <AgentMessage data-testid="msg" emphasis="answer">
        <MessageContent data-testid="content">Done.</MessageContent>
      </AgentMessage>,
    );
    const msg = screen.getByTestId("msg");
    expect(msg.className).toContain("border-s-4");
    expect(msg.className).toContain("border-s-primary");
    expect(screen.getByTestId("content").className).not.toContain("border-s-primary");
  });
});

describe("MessageHeader / MessageAvatar slot (#191, research 11 §B.1 MSG-2)", () => {
  it("renders the identity row with the meta role", () => {
    render(
      <AgentMessage>
        <MessageHeader data-testid="header">
          <MessageAvatar name="Atlas" role="user" />
          <span>Atlas</span>
        </MessageHeader>
        <MessageContent>Hi</MessageContent>
      </AgentMessage>,
    );
    expect(screen.getByTestId("header").className).toContain("text-meta");
    // user avatar shows the text initial
    expect(screen.getByText("A")).toBeInTheDocument();
    expect(screen.getByText("Atlas")).toBeInTheDocument();
  });
});

describe("MessageAvatar role=agent — branded Bot icon, not a text initial", () => {
  it("renders a Bot icon (svg) instead of a text initial for role=agent", () => {
    const { container } = render(
      <AgentMessage>
        <MessageHeader>
          <MessageAvatar data-testid="agent-avatar" name="Atlas" role="agent" />
        </MessageHeader>
        <MessageContent>Working.</MessageContent>
      </AgentMessage>,
    );
    const avatar = container.querySelector("[data-testid='agent-avatar']");
    expect(avatar).not.toBeNull();
    // Must NOT show the bare letter initial "A"
    expect(screen.queryByText("A")).toBeNull();
    // Must have an accessible label
    expect(avatar?.getAttribute("aria-label")).toBe("Atlas (agent)");
    // Must contain an SVG icon (the BotIcon) that is aria-hidden
    const svg = avatar?.querySelector("svg[aria-hidden='true']");
    expect(svg).not.toBeNull();
  });

  it("renders branded primary-green classes on the agent avatar", () => {
    const { container } = render(
      <MessageAvatar data-testid="agent-avatar" name="Atlas" role="agent" />,
    );
    const avatar = container.querySelector("[data-testid='agent-avatar']");
    expect(avatar?.className).toContain("bg-primary");
    expect(avatar?.className).toContain("text-primary-foreground");
  });

  it("uses a fallback accessible label when no name is given", () => {
    const { container } = render(<MessageAvatar data-testid="agent-avatar" role="agent" />);
    const avatar = container.querySelector("[data-testid='agent-avatar']");
    expect(avatar?.getAttribute("aria-label")).toBe("Agent");
  });
});
