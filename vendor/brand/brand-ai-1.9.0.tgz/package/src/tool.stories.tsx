import type { Meta, StoryObj } from "@storybook/react-vite";
import { Tool, ToolContent, ToolDetails, ToolHeader, ToolInput, ToolOutput } from "./tool";
const meta = { title: "AI/Tool", component: Tool, parameters: { layout: "padded" } } satisfies Meta<
  typeof Tool
>;
export default meta;
type Story = StoryObj<typeof meta>;
// JSON-behind-disclosure is the package default (#192, research 10 §B.5): the
// header carries the business summary; the raw payload sits inside the
// default-COLLAPSED ToolDetails, one expand away.
export const Default: Story = {
  render: () => (
    <Tool defaultOpen className="max-w-prose">
      <ToolHeader type="tool-search_web" state="output-available" summary="3 results found" />
      <ToolContent>
        <ToolDetails>
          <ToolInput input={{ query: "qlik cloud status" }} />
          <ToolOutput
            output={{ hits: 3, sources: ["status.qlik.com", "community", "docs"] }}
            errorText={undefined}
          />
        </ToolDetails>
      </ToolContent>
    </Tool>
  ),
};
