import type { Meta, StoryObj } from "@storybook/react-vite";
import { Reasoning, ReasoningContent, ReasoningTrigger } from "./reasoning";
const meta = {
  title: "AI/Reasoning",
  component: Reasoning,
  parameters: { layout: "padded" },
} satisfies Meta<typeof Reasoning>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <Reasoning defaultOpen className="max-w-prose">
      <ReasoningTrigger />
      <ReasoningContent>
        {"I checked CI for the last 7 days, grouped by service, then summarized the failures."}
      </ReasoningContent>
    </Reasoning>
  ),
};
