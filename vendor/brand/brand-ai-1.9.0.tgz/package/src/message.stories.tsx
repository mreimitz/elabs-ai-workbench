import type { Meta, StoryObj } from "@storybook/react-vite";
import {
  AgentMessage,
  Message,
  MessageAvatar,
  MessageContent,
  MessageHeader,
  MessageResponse,
  UserMessage,
} from "./message";
import { SourceList } from "./sources";
const meta = {
  title: "AI/Message",
  component: Message,
  parameters: { layout: "padded" },
} satisfies Meta<typeof Message>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Conversation_: Story = {
  name: "User + Assistant",
  render: () => (
    <div className="space-y-4">
      <Message from="user">
        <MessageContent>Summarize last week's deploys.</MessageContent>
      </Message>
      <Message from="assistant">
        <MessageContent>Three services shipped; billing is degraded.</MessageContent>
      </Message>
    </div>
  ),
};
// The named preset wrappers (#191, research 11 §B.2): UserMessage / AgentMessage
// with the MessageHeader identity slot.
export const Presets: Story = {
  name: "UserMessage + AgentMessage",
  render: () => (
    <div className="space-y-4">
      <UserMessage>
        <MessageContent>How did churn develop this quarter?</MessageContent>
      </UserMessage>
      <AgentMessage>
        <MessageHeader>
          <MessageAvatar name="Atlas" role="agent" />
          <span>Atlas</span>
        </MessageHeader>
        <MessageContent>Pulling the retention cohorts now…</MessageContent>
      </AgentMessage>
    </div>
  ),
};
// emphasis="answer" = the green left rail on the wrapper; prose + grounding
// footer are COMPOSED children, not baked-in layout.
export const FinalAnswer: Story = {
  name: "AgentMessage emphasis=answer",
  render: () => (
    <AgentMessage emphasis="answer">
      <MessageHeader>
        <MessageAvatar name="Atlas" role="agent" />
        <span>Atlas</span>
      </MessageHeader>
      <MessageContent>
        <MessageResponse>{`## Churn improved this quarter

Enterprise churn fell **0.4pp** to 1.8%, driven by the renewal-desk rollout:

- 12 at-risk accounts recovered
- \`auto-renew\` adoption up 9pp`}</MessageResponse>
        <SourceList
          sources={[
            { href: "https://warehouse.acme.com/q3-retention", title: "Q3 retention cohort" },
            { href: "https://crm.acme.com/renewals", title: "Renewal desk log" },
          ]}
        />
      </MessageContent>
    </AgentMessage>
  ),
};
