import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it } from "vitest";
import { AssetPreview } from "./asset-preview";
import type { ContextAsset } from "./context-panel";

afterEach(cleanup);

const MARKDOWN_ASSET: ContextAsset = {
  id: "board-note",
  name: "board-note.md",
  type: "markdown",
  content: "# Quarterly summary\n\nRevenue grew.",
};

const CSV_ASSET: ContextAsset = {
  id: "revenue",
  name: "revenue.csv",
  type: "csv",
  content: "region,total\nEMEA,16.1\nAmericas,19.6",
};

describe("AssetPreview (#193, research 04 §5 ASSET-4)", () => {
  it("renders markdown as a document (the ASSET-2 fix), with a Preview/Raw toggle", async () => {
    const user = userEvent.setup();
    render(<AssetPreview asset={MARKDOWN_ASSET} />);

    // Artifact chrome: the asset name headline.
    expect(screen.getByText("board-note.md")).toBeInTheDocument();
    // Preview = a real heading, not Shiki source.
    expect(screen.getByRole("heading", { name: "Quarterly summary" })).toBeInTheDocument();
    // Constrained rung: never an h1 inside the rail (research 09 §G.2).
    expect(screen.queryByRole("heading", { level: 1 })).not.toBeInTheDocument();

    // Raw shows the markdown source instead.
    await user.click(screen.getByRole("button", { name: "Raw" }));
    expect(screen.queryByRole("heading", { name: "Quarterly summary" })).not.toBeInTheDocument();
    expect(screen.getByText(/# Quarterly summary/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Raw" })).toHaveAttribute("aria-pressed", "true");
  });

  it("renders csv as a small table with a row-count summary", () => {
    render(<AssetPreview asset={CSV_ASSET} />);
    expect(screen.getByRole("table")).toBeInTheDocument();
    expect(screen.getByText("EMEA")).toBeInTheDocument();
    expect(screen.getByText("2 rows")).toBeInTheDocument();
  });

  it("renders an empty state for missing content, never broken UI", () => {
    render(<AssetPreview asset={{ id: "x", name: "empty.md", type: "markdown" }} />);
    expect(screen.getByText("No preview available…")).toBeInTheDocument();
    // No Raw toggle without raw source.
    expect(screen.queryByRole("button", { name: "Raw" })).not.toBeInTheDocument();
  });
});
