"use client";

/**
 * ToolResultCard — an artifact the agent PRODUCED, presented as the headline
 * (#192, research 10 §B.4).
 *
 * The elevation channel of the surface-separation system (research 08 §H):
 * raised fill + shadow, NO border (elevation is the separation gesture — a
 * border here would be the redundant-border anti-pattern). A separate
 * component from `Tool` by design: `Tool` owns the rail/inspect idiom (a step
 * that ran, JSON behind disclosure); `ToolResultCard` hosts the produced
 * chart/table/file as `children` — so an agent picks the channel by NAME,
 * not by a behavioural mode flag.
 *
 * Presentational and dependency-light: it does NOT import `@brand/charts` or
 * `@brand/data` (one-way dep graph) — the consumer passes the artifact (an
 * `<AutoChart>`, `<DataTable>`, file preview, …) as children, and maps an
 * AI-SDK tool state to `status` via `statusFromToolState` (tool.tsx).
 */
import { StatusBadge, type Status } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { forwardRef, type HTMLAttributes, type ReactNode } from "react";

export interface ToolResultCardProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  /** Headline of the produced artifact (`text-subtitle`). */
  title?: ReactNode;
  /** The business summary line under the title (`text-meta`), not JSON. */
  summary?: ReactNode;
  /** Canonical execution status (closed enum); renders a `StatusBadge`. */
  status?: Status;
  /**
   * The technical view, kept behind disclosure — pass a default-collapsed
   * `<ToolDetails>` holding `ToolInput`/`ToolOutput` (research 10 §B.5).
   */
  details?: ReactNode;
}

/** The produced artifact IS the headline; pass it as `children`. */
export const ToolResultCard = forwardRef<HTMLDivElement, ToolResultCardProps>(
  function ToolResultCard({ title, summary, status, details, className, children, ...props }, ref) {
    const hasHeader = title != null || summary != null || status != null;
    return (
      <div
        ref={ref}
        className={cn(
          "not-prose w-full space-y-3 rounded-lg bg-surface-elevated p-4 shadow-sm",
          className,
        )}
        {...props}
      >
        {hasHeader ? (
          <div className="space-y-0.5">
            <div className="flex items-center justify-between gap-3">
              {title ? <h3 className="min-w-0 truncate text-subtitle">{title}</h3> : null}
              {status ? <StatusBadge className="shrink-0" size="sm" status={status} /> : null}
            </div>
            {summary ? <p className="text-meta text-muted-foreground">{summary}</p> : null}
          </div>
        ) : null}
        {children}
        {details}
      </div>
    );
  },
);
