/**
 * Composer — the standard brand-ui AI chat input.
 *
 * The canonical two-tone "double card": an outer `bg-card` frame with a muted
 * status strip wrapping a recessed `PromptInput` well (sharp top, theme-rounded
 * bottom), a model pill, voice, and a circular send. This is THE chat input —
 * reach for `<Composer />` instead of hand-rolling a `PromptInput` footer, in a
 * `ChatShell` footer or as a standalone empty-state composer. Semantic tokens
 * only; theme-aware radii; reads in every theme.
 */
import type { Meta, StoryObj } from "@storybook/react-vite";

import { Composer } from "./composer";

const SUGGESTIONS = ["Summary", "Code", "Design", "Research"];

const meta = {
  title: "AI/Composer",
  component: Composer,
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "The standard brand-ui AI chat input: a rounded two-tone double card (outer bg-card frame + muted status strip around a recessed PromptInput well with a sharp top and theme-rounded bottom), a model pill, voice, and a circular send. Built on the real @brand/ai PromptInput. Use it as the chat input everywhere — a ChatShell footer or a standalone empty-state composer. Semantic tokens only; reads in all themes.",
      },
    },
  },
  args: {
    onSubmit: () => undefined,
  },
  tags: ["autodocs"],
} satisfies Meta<typeof Composer>;

export default meta;
type Story = StoryObj<typeof meta>;

/** The standalone composer with its defaults. */
export const Default: Story = {
  render: (args) => (
    <div className="mx-auto max-w-2xl">
      <Composer {...args} />
    </div>
  ),
};

/** The empty/first-run chat state: a centered greeting + composer + suggestion chips. */
export const EmptyStateScene: Story = {
  parameters: { layout: "fullscreen" },
  render: (args) => (
    <div className="grid min-h-[28rem] place-items-center bg-background px-4 py-10 text-foreground">
      <div className="w-full max-w-2xl">
        <div className="relative mb-10 text-center">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute start-1/2 top-0 -z-10 size-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/15 blur-3xl"
          />
          <h1 className="text-balance text-display text-foreground">
            Good morning, Avery
            <br />
            How can I <span className="text-primary">assist you today?</span>
          </h1>
        </div>
        <Composer {...args} suggestions={SUGGESTIONS} />
      </div>
    </div>
  ),
};

/** While the agent is generating: a status line + the streaming send (stop) state. */
export const Streaming: Story = {
  args: { status: "Generating…", sendStatus: "streaming", onStop: () => undefined },
  render: (args) => (
    <div className="mx-auto max-w-2xl">
      <Composer {...args} />
    </div>
  ),
};

/** Trimmed: no model pill, no voice — just attach + send. */
export const Minimal: Story = {
  args: { model: null, showVoice: false, status: null },
  render: (args) => (
    <div className="mx-auto max-w-2xl">
      <Composer {...args} />
    </div>
  ),
};
