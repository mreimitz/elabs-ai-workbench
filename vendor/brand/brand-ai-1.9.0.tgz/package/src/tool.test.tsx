import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tool, ToolContent, ToolDetails, ToolHeader, ToolInput } from "./tool";

const renderTool = () =>
  render(
    <Tool defaultOpen>
      <ToolHeader type="tool-search_web" state="output-available" summary="3 results found" />
      <ToolContent>
        <ToolDetails>
          <ToolInput input={{ query: "qlik cloud status" }} />
        </ToolDetails>
      </ToolContent>
    </Tool>,
  );

describe("Tool JSON-behind-disclosure (#192, research 10 §B.5)", () => {
  it("shows the business summary in the header and keeps ToolDetails COLLAPSED by default", () => {
    renderTool();
    expect(screen.getByText("3 results found")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /show technical details/i })).toBeInTheDocument();
    // The JSON payload is NOT the headline — hidden until opted in.
    expect(screen.queryByText("Parameters")).not.toBeInTheDocument();
  });

  it("reveals the technical view on demand", async () => {
    const user = userEvent.setup();
    renderTool();
    await user.click(screen.getByRole("button", { name: /show technical details/i }));
    expect(screen.getByText("Parameters")).toBeInTheDocument();
  });
});
