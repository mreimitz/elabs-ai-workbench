"use client";

/**
 * InteractiveTerminal — a token-themed wrapper around xterm.js (issue #285).
 *
 * `Terminal` (terminal.tsx) is a presentational, READ-ONLY ANSI log (no stdin,
 * no cursor, no resize protocol). This is a SEPARATE component for a real
 * interactive terminal surface: run a command, see live ANSI output, type into
 * the process. The PTY/process itself is consumer-owned (D5) — this component
 * only renders and emits input/resize events; it never spawns anything.
 *
 * Theming: xterm can't read CSS custom properties, so its `ITheme` (background/
 * foreground/cursor/selection + the 16 ANSI colors) is derived from semantic
 * tokens at runtime via `oklchToHex`/`resolveTokenColor` (`@brand/tokens`, ADR
 * 0015) — the same "wrap an engine, theme it from tokens" pattern as
 * `@brand/editor`'s Monaco bridge and `@brand/maps`' `useTokenColor`. It
 * re-resolves whenever `data-theme` changes (a local MutationObserver, mirroring
 * `persona.tsx`'s theme watcher — `@brand/ai` can't import `@brand/editor`'s
 * shared `useDataTheme` hook per the one-way package graph).
 */

import "@xterm/xterm/css/xterm.css";

import { resolveTokenColor } from "@brand/tokens";
import { cn } from "@brand/ui/lib/cn";
import { FitAddon } from "@xterm/addon-fit";
import { Terminal as XTerm, type ITheme } from "@xterm/xterm";
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  type HTMLAttributes,
} from "react";

export interface InteractiveTerminalHandle {
  /** Process → screen. ANSI passthrough (colors, cursor movement, clears, …). */
  write(data: string): void;
  /** Clears the viewport + scrollback. */
  clear(): void;
  /** Re-fits cols/rows to the current container size. */
  fit(): void;
  /** Focuses the terminal's input surface. */
  focus(): void;
}

export interface InteractiveTerminalProps extends Omit<HTMLAttributes<HTMLDivElement>, "onResize"> {
  /** Keystrokes + paste → process. The PTY/process stays consumer-owned. */
  onData?: (data: string) => void;
  /** Fires whenever the container resizes and cols/rows are refit. */
  onResize?: (size: { cols: number; rows: number }) => void;
  /** Degrades to a read-only log: writes still render, stdin is disabled. */
  readOnly?: boolean;
  /** Terminal font size in px. Defaults to `13` (matches `CodeEditor`). */
  fontSize?: number;
  /** Accessible name for the terminal's real focusable surface. Required. */
  "aria-label": string;
}

// --- Runtime color helpers -------------------------------------------------
// `resolveTokenColor` (@brand/tokens, ADR 0015) is the shared "read a semantic
// token off an element, oklch → hex" resolver — the same one `@brand/maps`'
// `useTokenColor` wraps. `withAlpha`/`lighten` below are the same "math on the
// resolved hex" idiom as `monaco-theme-bridge.ts` (@brand/editor) — never a
// hardcoded literal color.

/** Mix `alpha` (0..1) into a `#rrggbb` color, returning `#rrggbbaa`. */
function withAlpha(hex: string, alpha: number): string {
  const base = hex.slice(0, 7);
  const byte = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
    .toString(16)
    .padStart(2, "0");
  return `${base}${byte}`;
}

/** Lighten a `#rrggbb` color toward white by `amount` (0..1) — used for the
 * "bright" ANSI variants of chart-derived hues (chart-2/chart-4) that don't
 * have a dedicated lighter sibling token. */
function lighten(hex: string, amount: number): string {
  const base = hex.slice(0, 7);
  const channel = (i: number) => parseInt(base.slice(1 + i * 2, 3 + i * 2), 16) || 0;
  const toHex = (n: number) =>
    Math.min(255, Math.max(0, Math.round(n)))
      .toString(16)
      .padStart(2, "0");
  const mix = (c: number) => c + (255 - c) * amount;
  return `#${toHex(mix(channel(0)))}${toHex(mix(channel(1)))}${toHex(mix(channel(2)))}`;
}

/**
 * Builds xterm's `ITheme` from the active theme's semantic tokens, resolved
 * off `rootEl` (defaults to `<html>`, where `data-theme` lives).
 *
 * ANSI mapping (documented so the intent is auditable, not guessed at):
 *  - background/foreground → `--card`/`--foreground` (the terminal reads as a
 *    raised panel, matching the existing `Terminal` log's bordered-box look).
 *  - cursor → `--primary`; cursorAccent → the background, so glyphs stay
 *    legible under a solid block cursor.
 *  - selectionBackground → a low-alpha `--primary` wash.
 *  - red/green/yellow/blue → the AA-tuned `-text` variants (`--destructive-text`,
 *    `--success-text`, `--warning-text`, `--info-text`) — these are the ones
 *    tuned to read as TEXT on a surface, which is exactly what ANSI color codes
 *    paint. `bright*` variants use the more saturated fill tokens
 *    (`--destructive`, `--success`, `--warning`, `--info`).
 *  - magenta/cyan → `--chart-4`/`--chart-2` (no dedicated fill/text pair, so the
 *    `bright*` siblings are a runtime-lightened variant of the same hue).
 *  - black/white are `background`/`foreground` RUNGS, not the tokens
 *    themselves: `black` = the terminal's own background (the common "ANSI
 *    black" convention — invisible ink), `brightBlack` = `--border-strong`
 *    (guaranteed ≥3:1 vs background — legible dim text, e.g. comments/hashes),
 *    `white` = `--muted-foreground` (a dimmer ink), `brightWhite` =
 *    `--foreground` (full ink).
 */
export function buildInteractiveTerminalTheme(rootEl?: Element | null): ITheme {
  const el = rootEl ?? (typeof document !== "undefined" ? document.documentElement : null);
  const read = (name: string, fallback: string) => resolveTokenColor(name, { el, fallback });

  const background = read("--card", "#ffffff");
  const foreground = read("--foreground", "#111111");
  const primary = read("--primary", foreground);
  const mutedForeground = read("--muted-foreground", foreground);
  const borderStrong = read("--border-strong", mutedForeground);

  const destructiveText = read("--destructive-text", "#b91c1c");
  const destructive = read("--destructive", destructiveText);
  const successText = read("--success-text", "#15803d");
  const success = read("--success", successText);
  const warningText = read("--warning-text", "#a16207");
  const warning = read("--warning", warningText);
  const infoText = read("--info-text", primary);
  const info = read("--info", primary);
  const chart2 = read("--chart-2", infoText);
  const chart4 = read("--chart-4", destructiveText);

  return {
    background,
    foreground,
    cursor: primary,
    cursorAccent: background,
    selectionBackground: withAlpha(primary, 0.28),

    black: background,
    red: destructiveText,
    green: successText,
    yellow: warningText,
    blue: infoText,
    magenta: chart4,
    cyan: chart2,
    white: mutedForeground,

    brightBlack: borderStrong,
    brightRed: destructive,
    brightGreen: success,
    brightYellow: warning,
    brightBlue: info,
    brightMagenta: lighten(chart4, 0.3),
    brightCyan: lighten(chart2, 0.3),
    brightWhite: foreground,
  };
}

/** Reads the theme's mono font stack (the `--font-mono` seam — blueprint
 * overrides it to IBM Plex Mono) so the terminal's glyphs track it too. */
function readTerminalFontFamily(rootEl?: Element | null): string {
  const el = rootEl ?? (typeof document !== "undefined" ? document.documentElement : null);
  if (!el || typeof getComputedStyle === "undefined") return "monospace";
  const raw = getComputedStyle(el).getPropertyValue("--font-mono").trim();
  return raw || "monospace";
}

const DEFAULT_FONT_SIZE = 13;

/**
 * A token-themed, PTY-ready terminal emulator wrapped as a brand-ui component.
 * Wraps xterm.js + `FitAddon`; the process itself is consumer-owned — this
 * component only renders ANSI output and emits `onData`/`onResize`.
 *
 * Keyboard: the terminal's real focusable surface is xterm's own input
 * textarea (reachable by Tab like any control). Tab/Shift-Tab and Escape are
 * explicitly let through (`attachCustomKeyEventHandler`) so focus can always
 * leave the terminal — there is no keyboard trap.
 */
export const InteractiveTerminal = forwardRef<InteractiveTerminalHandle, InteractiveTerminalProps>(
  function InteractiveTerminal(
    {
      onData,
      onResize,
      readOnly = false,
      fontSize = DEFAULT_FONT_SIZE,
      className,
      "aria-label": ariaLabel,
      ...props
    },
    ref,
  ) {
    const containerRef = useRef<HTMLDivElement>(null);
    const fitAddonRef = useRef<FitAddon | null>(null);
    const [term, setTerm] = useState<XTerm | null>(null);
    const [themeRevision, setThemeRevision] = useState(0);

    const onDataRef = useRef(onData);
    onDataRef.current = onData;
    const onResizeRef = useRef(onResize);
    onResizeRef.current = onResize;

    useImperativeHandle<InteractiveTerminalHandle, InteractiveTerminalHandle>(
      ref,
      () => ({
        write: (data: string) => term?.write(data),
        clear: () => term?.clear(),
        fit: () => fitAddonRef.current?.fit(),
        focus: () => term?.focus(),
      }),
      [term],
    );

    // Mount once: create the xterm instance + FitAddon, open into the
    // container, wire the resize observer + no-keyboard-trap handler.
    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      const instance = new XTerm({
        fontSize,
        fontFamily: readTerminalFontFamily(),
        convertEol: true,
        cursorBlink: true,
        scrollback: 2000,
        disableStdin: readOnly,
        theme: buildInteractiveTerminalTheme(),
      });
      const fitAddon = new FitAddon();
      instance.loadAddon(fitAddon);
      instance.open(container);
      if (ariaLabel && instance.textarea) {
        instance.textarea.setAttribute("aria-label", ariaLabel);
      }

      // No keyboard trap (#285 acceptance criterion): let Tab/Shift-Tab and
      // Escape bubble to the browser's normal focus handling instead of being
      // consumed as terminal input, so focus can always leave the terminal.
      instance.attachCustomKeyEventHandler((event) => {
        if (event.key === "Tab" || event.key === "Escape") return false;
        return true;
      });

      fitAddonRef.current = fitAddon;
      setTerm(instance);

      const resizeObserver = new ResizeObserver(() => {
        try {
          fitAddon.fit();
        } catch {
          // Container not laid out yet (e.g. display:none) — ignore, the next
          // resize observation will retry.
        }
      });
      resizeObserver.observe(container);

      return () => {
        resizeObserver.disconnect();
        fitAddon.dispose();
        instance.dispose();
        fitAddonRef.current = null;
        setTerm(null);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Keystrokes + paste → consumer, only while interactive.
    useEffect(() => {
      if (!term || readOnly) return;
      const sub = term.onData((data) => onDataRef.current?.(data));
      return () => sub.dispose();
    }, [term, readOnly]);

    // Container resize → refit → report the new cols/rows.
    useEffect(() => {
      if (!term) return;
      const sub = term.onResize((size) => onResizeRef.current?.(size));
      return () => sub.dispose();
    }, [term]);

    // `readOnly` toggles xterm's own stdin gate at runtime too (not just at
    // construction), so it can be flipped on a live instance.
    useEffect(() => {
      if (!term) return;
      term.options.disableStdin = readOnly;
    }, [term, readOnly]);

    useEffect(() => {
      if (!term || fontSize === term.options.fontSize) return;
      term.options.fontSize = fontSize;
      fitAddonRef.current?.fit();
    }, [term, fontSize]);

    useEffect(() => {
      if (!term || !term.textarea || !ariaLabel) return;
      term.textarea.setAttribute("aria-label", ariaLabel);
    }, [term, ariaLabel]);

    // Track `data-theme` (ThemeProvider or Storybook's theme decorator both
    // just set the attribute) and re-apply the derived xterm theme + font.
    useEffect(() => {
      if (typeof document === "undefined") return;
      const observer = new MutationObserver(() => setThemeRevision((r) => r + 1));
      observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-theme"],
      });
      return () => observer.disconnect();
    }, []);

    useEffect(() => {
      if (!term) return;
      term.options.theme = buildInteractiveTerminalTheme();
      term.options.fontFamily = readTerminalFontFamily();
      fitAddonRef.current?.fit();
      // `themeRevision` is the trigger; the values themselves are re-read live.
    }, [term, themeRevision]);

    return (
      <div
        ref={containerRef}
        className={cn(
          "overflow-hidden rounded-lg border bg-card p-2 outline-none",
          "focus-within:ring-2 focus-within:ring-ring",
          className,
        )}
        {...props}
      />
    );
  },
);
