import { describe, expect, it } from "vitest";
import { render } from "@testing-library/react";
import { CodeBlock } from "./code-block";

describe("CodeBlock", () => {
  it("renders the code content", () => {
    const { container } = render(<CodeBlock code="const a = 1;" language="tsx" />);
    expect(container.textContent).toContain("const a = 1;");
  });

  it("soft-wraps long lines when `wrap` is set (#5)", () => {
    const { container } = render(
      <CodeBlock code="a very long single line of code" language="tsx" wrap />,
    );
    const pre = container.querySelector("pre");
    expect(pre?.className).toContain("whitespace-pre-wrap");
    expect(pre?.className).toContain("break-words");
    // No horizontal-scroll affordance when wrapping (there's nothing to scroll).
    const scroller = container.querySelector(".overflow-auto");
    expect(scroller?.className ?? "").not.toContain("scrollbar-width:thin");
  });

  it("does not wrap by default, and shows a scroll affordance (#5)", () => {
    const { container } = render(
      <CodeBlock code="a very long single line of code" language="tsx" />,
    );
    const pre = container.querySelector("pre");
    expect(pre?.className).not.toContain("whitespace-pre-wrap");
    // Default mode keeps horizontal scroll with a discoverable thin scrollbar.
    const scroller = container.querySelector(".overflow-auto");
    expect(scroller).not.toBeNull();
    expect(scroller?.className).toContain("scrollbar-width:thin");
  });
});
