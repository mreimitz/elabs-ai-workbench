import type { Meta, StoryObj } from "@storybook/react-vite";
import { CodeBlock } from "./code-block";
const meta = {
  title: "AI/CodeBlock",
  component: CodeBlock,
  parameters: { layout: "padded" },
} satisfies Meta<typeof CodeBlock>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  render: () => (
    <div className="max-w-lg">
      <CodeBlock
        code={"export function add(a: number, b: number) {\n  return a + b;\n}"}
        language="tsx"
      />
    </div>
  ),
};
