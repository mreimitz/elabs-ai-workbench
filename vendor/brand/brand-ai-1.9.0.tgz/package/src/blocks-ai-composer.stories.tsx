/**
 * AI Composer — the standard chat-input block.
 *
 * This block is now a thin showcase of the real `<Composer />` component (the
 * canonical brand-ui AI chat input). The double-card chrome — outer `bg-card`
 * frame, muted status strip, recessed `PromptInput` well (sharp top, theme-
 * rounded bottom), model pill, voice, circular send, suggestion chips — lives in
 * `composer.tsx`, not here, so every surface gets the same input by importing it.
 * Semantic tokens only; theme-aware radii; reads in all themes.
 */
import type { Meta, StoryObj } from "@storybook/react-vite";

import { Composer } from "./composer";

const SUGGESTIONS = ["Summary", "Code", "Design", "Research"];

/** Empty/first-run chat state: greeting + composer + suggestion chips. */
function AiComposerScene() {
  return (
    <div className="grid min-h-[28rem] place-items-center bg-background px-4 py-10 text-foreground">
      <div className="w-full max-w-2xl">
        <div className="relative mb-10 text-center">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute start-1/2 top-0 -z-10 size-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/15 blur-3xl"
          />
          <h1 className="text-balance text-display text-foreground">
            Good morning, Avery
            <br />
            How can I <span className="text-primary">assist you today?</span>
          </h1>
        </div>

        <Composer onSubmit={() => undefined} suggestions={SUGGESTIONS} />
      </div>
    </div>
  );
}

const meta = {
  title: "Patterns/Blocks/AI Composer",
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "The standard AI chat-input block — a thin showcase of the real <Composer /> component: a rounded two-tone double card (outer bg-card frame + muted status strip around a recessed PromptInput well with a sharp top and theme-rounded bottom), a model pill, a circular send, and suggestion chips under a centered greeting. Built on the real @brand/ai PromptInput; semantic tokens only; reads in all themes. Reach for <Composer /> instead of hand-rolling this.",
      },
    },
  },
  tags: ["autodocs"],
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/** The full empty-state scene (greeting + composer + chips). */
export const Default: Story = { render: () => <AiComposerScene /> };

/** Just the double-card composer, to drop into a ChatShell footer. */
export const ComposerOnly: Story = {
  render: () => (
    <div className="bg-background p-6">
      <div className="mx-auto max-w-2xl">
        <Composer onSubmit={() => undefined} />
      </div>
    </div>
  ),
};
