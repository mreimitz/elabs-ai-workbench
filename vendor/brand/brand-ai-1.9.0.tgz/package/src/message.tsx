"use client";

import { Avatar, AvatarFallback, AvatarImage, Button } from "@brand/ui";
import { ButtonGroup, ButtonGroupText } from "@brand/ui";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@brand/ui";
import { cn } from "@brand/ui/lib/cn";
import { cva, type VariantProps } from "class-variance-authority";
import { cjk } from "@streamdown/cjk";
import { code } from "@streamdown/code";
import { math } from "@streamdown/math";
import { mermaid } from "@streamdown/mermaid";
import type { UIMessage } from "ai";
import { BotIcon, ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import type { ComponentProps, HTMLAttributes, ReactElement } from "react";
import { createContext, memo, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Streamdown } from "streamdown";

export type MessageProps = HTMLAttributes<HTMLDivElement> & {
  from: UIMessage["role"];
};

export const Message = ({ className, from, ...props }: MessageProps) => (
  <div
    className={cn(
      "group flex w-full max-w-[95%] flex-col gap-2",
      from === "user" ? "is-user ms-auto justify-end" : "is-assistant",
      className,
    )}
    {...props}
  />
);

export type MessageContentProps = HTMLAttributes<HTMLDivElement>;

export const MessageContent = ({ children, className, ...props }: MessageContentProps) => (
  <div
    className={cn(
      "flex w-fit min-w-0 max-w-full flex-col gap-2 overflow-hidden text-body",
      // The user turn is the 08 fill channel: the revalued `--chat-user` tint +
      // its AA-validated foreground (research 11 §B.1 MSG-1). The assistant
      // branch stays bare — its separation is the AgentMessage rail.
      "group-[.is-user]:ms-auto group-[.is-user]:rounded-lg group-[.is-user]:bg-chat-user group-[.is-user]:px-4 group-[.is-user]:py-3 group-[.is-user]:text-chat-user-foreground",
      "group-[.is-assistant]:text-foreground",
      className,
    )}
    {...props}
  >
    {children}
  </div>
);

export type MessageHeaderProps = HTMLAttributes<HTMLDivElement>;

/**
 * Optional identity row above the bubble — avatar + name + timestamp
 * (research 11 §B.1 MSG-2). A slot, not baked structure.
 */
export const MessageHeader = ({ className, ...props }: MessageHeaderProps) => (
  <div
    className={cn("flex items-center gap-2 text-meta text-muted-foreground", className)}
    {...props}
  />
);

export type MessageAvatarProps = ComponentProps<typeof Avatar> & {
  /** Image source for the participant. */
  src?: string;
  /** Participant name — drives the image alt + the fallback initial, and the accessible label. */
  name?: string;
  /**
   * Visual identity role.
   * - `"user"` (default): shows the initial letter as a fallback.
   * - `"agent"`: shows a branded Bot icon on a primary (green) ground instead
   *   of a text initial, matching the agent identity convention.
   */
  role?: "user" | "agent";
};

/**
 * Thin preset over the `@brand/ui` Avatar sized for inline chat (NOT a new
 * avatar primitive — research 11 §B.1 MSG-2).
 *
 * When `role="agent"`, renders a filled primary-green circle with a centered
 * Bot icon (lucide-react `BotIcon`) and an accessible label derived from
 * `name`. The primary/primary-foreground token pair is the agent identity
 * colour across all three themes (green on qlik-bright/qlik-dark; theme-adapted
 * on others).
 */
export const MessageAvatar = ({
  src,
  name,
  role = "user",
  className,
  children,
  ...props
}: MessageAvatarProps) => {
  if (role === "agent") {
    return (
      <Avatar
        aria-label={name ? `${name} (agent)` : "Agent"}
        className={cn("size-6 bg-primary text-primary-foreground", className)}
        {...props}
      >
        {src ? <AvatarImage alt={name ?? ""} src={src} /> : null}
        <AvatarFallback className="bg-primary text-primary-foreground">
          <BotIcon aria-hidden="true" size={14} />
        </AvatarFallback>
      </Avatar>
    );
  }

  return (
    <Avatar className={cn("size-6", className)} {...props}>
      {src ? <AvatarImage alt={name ?? ""} src={src} /> : null}
      <AvatarFallback className="text-meta">
        {children ?? name?.slice(0, 1).toUpperCase() ?? "?"}
      </AvatarFallback>
    </Avatar>
  );
};

export type UserMessageProps = Omit<MessageProps, "from">;

/**
 * Named front door for a user turn (research 11 §B.2) — a thin preset over
 * `Message from="user"`; the chat-user fill comes from `MessageContent`.
 */
export const UserMessage = (props: UserMessageProps) => <Message from="user" {...props} />;

export const agentMessageVariants = cva("", {
  variants: {
    /**
     * "Final answer" is a VISUAL axis, not a behavioural mode (research 11
     * §B.2): `answer` applies the 08 green left rail. It sits on the message
     * wrapper — never on `MessageContent`, whose `overflow-hidden` would clip
     * it (research 11 §G.1).
     */
    emphasis: {
      default: "",
      answer: "border-s-4 border-s-primary ps-4",
    },
  },
  defaultVariants: { emphasis: "default" },
});

export type AgentMessageEmphasis = NonNullable<
  VariantProps<typeof agentMessageVariants>["emphasis"]
>;

export type AgentMessageProps = Omit<MessageProps, "from"> &
  VariantProps<typeof agentMessageVariants>;

/**
 * Named front door for an assistant turn (research 11 §B.2). KPI band / prose /
 * footer are COMPOSED children (`MetricGrid` + `MessageResponse` +
 * `SourceList`), not baked-in layout.
 */
export const AgentMessage = ({ className, emphasis, ...props }: AgentMessageProps) => (
  <Message
    from="assistant"
    className={cn(agentMessageVariants({ emphasis }), className)}
    {...props}
  />
);

export type MessageActionsProps = ComponentProps<"div">;

export const MessageActions = ({ className, children, ...props }: MessageActionsProps) => (
  <div className={cn("flex items-center gap-1", className)} {...props}>
    {children}
  </div>
);

export type MessageActionProps = ComponentProps<typeof Button> & {
  tooltip?: string;
  label?: string;
};

export const MessageAction = ({
  tooltip,
  children,
  label,
  variant = "ghost",
  size = "icon-sm",
  ...props
}: MessageActionProps) => {
  const button = (
    <Button size={size} type="button" variant={variant} {...props}>
      {children}
      <span className="sr-only">{label || tooltip}</span>
    </Button>
  );

  if (tooltip) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>{button}</TooltipTrigger>
          <TooltipContent>
            <p>{tooltip}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return button;
};

interface MessageBranchContextType {
  currentBranch: number;
  totalBranches: number;
  goToPrevious: () => void;
  goToNext: () => void;
  branches: ReactElement[];
  setBranches: (branches: ReactElement[]) => void;
}

const MessageBranchContext = createContext<MessageBranchContextType | null>(null);

const useMessageBranch = () => {
  const context = useContext(MessageBranchContext);

  if (!context) {
    throw new Error("MessageBranch components must be used within MessageBranch");
  }

  return context;
};

export type MessageBranchProps = HTMLAttributes<HTMLDivElement> & {
  defaultBranch?: number;
  onBranchChange?: (branchIndex: number) => void;
};

export const MessageBranch = ({
  defaultBranch = 0,
  onBranchChange,
  className,
  ...props
}: MessageBranchProps) => {
  const [currentBranch, setCurrentBranch] = useState(defaultBranch);
  const [branches, setBranches] = useState<ReactElement[]>([]);

  const handleBranchChange = useCallback(
    (newBranch: number) => {
      setCurrentBranch(newBranch);
      onBranchChange?.(newBranch);
    },
    [onBranchChange],
  );

  const goToPrevious = useCallback(() => {
    const newBranch = currentBranch > 0 ? currentBranch - 1 : branches.length - 1;
    handleBranchChange(newBranch);
  }, [currentBranch, branches.length, handleBranchChange]);

  const goToNext = useCallback(() => {
    const newBranch = currentBranch < branches.length - 1 ? currentBranch + 1 : 0;
    handleBranchChange(newBranch);
  }, [currentBranch, branches.length, handleBranchChange]);

  const contextValue = useMemo<MessageBranchContextType>(
    () => ({
      branches,
      currentBranch,
      goToNext,
      goToPrevious,
      setBranches,
      totalBranches: branches.length,
    }),
    [branches, currentBranch, goToNext, goToPrevious],
  );

  return (
    <MessageBranchContext.Provider value={contextValue}>
      <div className={cn("grid w-full gap-2 [&>div]:pb-0", className)} {...props} />
    </MessageBranchContext.Provider>
  );
};

export type MessageBranchContentProps = HTMLAttributes<HTMLDivElement>;

export const MessageBranchContent = ({ children, ...props }: MessageBranchContentProps) => {
  const { currentBranch, setBranches, branches } = useMessageBranch();
  const childrenArray = useMemo(
    () => (Array.isArray(children) ? children : [children]),
    [children],
  );

  // Use useEffect to update branches when they change
  useEffect(() => {
    if (branches.length !== childrenArray.length) {
      setBranches(childrenArray);
    }
  }, [childrenArray, branches, setBranches]);

  return childrenArray.map((branch, index) => (
    <div
      className={cn(
        "grid gap-2 overflow-hidden [&>div]:pb-0",
        index === currentBranch ? "block" : "hidden",
      )}
      key={branch.key}
      {...props}
    >
      {branch}
    </div>
  ));
};

export type MessageBranchSelectorProps = ComponentProps<typeof ButtonGroup>;

export const MessageBranchSelector = ({ className, ...props }: MessageBranchSelectorProps) => {
  const { totalBranches } = useMessageBranch();

  // Don't render if there's only one branch
  if (totalBranches <= 1) {
    return null;
  }

  return (
    <ButtonGroup
      className={cn(
        "[&>*:not(:first-child)]:rounded-s-md [&>*:not(:last-child)]:rounded-e-md",
        className,
      )}
      orientation="horizontal"
      {...props}
    />
  );
};

export type MessageBranchPreviousProps = ComponentProps<typeof Button>;

export const MessageBranchPrevious = ({ children, ...props }: MessageBranchPreviousProps) => {
  const { goToPrevious, totalBranches } = useMessageBranch();

  return (
    <Button
      aria-label="Previous branch"
      disabled={totalBranches <= 1}
      onClick={goToPrevious}
      size="icon-sm"
      type="button"
      variant="ghost"
      {...props}
    >
      {children ?? <ChevronLeftIcon size={14} data-rtl-flip />}
    </Button>
  );
};

export type MessageBranchNextProps = ComponentProps<typeof Button>;

export const MessageBranchNext = ({ children, ...props }: MessageBranchNextProps) => {
  const { goToNext, totalBranches } = useMessageBranch();

  return (
    <Button
      aria-label="Next branch"
      disabled={totalBranches <= 1}
      onClick={goToNext}
      size="icon-sm"
      type="button"
      variant="ghost"
      {...props}
    >
      {children ?? <ChevronRightIcon size={14} data-rtl-flip />}
    </Button>
  );
};

export type MessageBranchPageProps = HTMLAttributes<HTMLSpanElement>;

export const MessageBranchPage = ({ className, ...props }: MessageBranchPageProps) => {
  const { currentBranch, totalBranches } = useMessageBranch();

  return (
    <ButtonGroupText
      className={cn("border-none bg-transparent text-muted-foreground shadow-none", className)}
      {...props}
    >
      {currentBranch + 1} of {totalBranches}
    </ButtonGroupText>
  );
};

export type MessageResponseProps = ComponentProps<typeof Streamdown>;

const streamdownPlugins = { cjk, code, math, mermaid };

export const MessageResponse = memo(
  ({ className, ...props }: MessageResponseProps) => (
    <Streamdown
      className={cn(
        "size-full [&>*:first-child]:mt-0 [&>*:last-child]:mb-0",
        // Brand prose scale (research 11 §B.1 MSG-3): map the streamed markdown
        // element tree onto the 07 type roles. Descendant-selector className —
        // NOT a `components` map — so streaming stays cheap.
        "[&_h1]:text-title [&_h2]:text-subtitle [&_h3]:text-subtitle",
        "[&_p]:text-body [&_li]:text-body [&_code]:text-code",
        className,
      )}
      plugins={streamdownPlugins}
      {...props}
    />
  ),
  (prevProps, nextProps) =>
    prevProps.children === nextProps.children && nextProps.isAnimating === prevProps.isAnimating,
);

MessageResponse.displayName = "MessageResponse";

export type MessageToolbarProps = ComponentProps<"div">;

export const MessageToolbar = ({ className, children, ...props }: MessageToolbarProps) => (
  <div className={cn("mt-4 flex w-full items-center justify-between gap-4", className)} {...props}>
    {children}
  </div>
);
